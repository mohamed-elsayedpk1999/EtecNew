function makeAlert($status, message, title) {
    toastr[$status](message, title || "", { closeButton: true, tapToDismiss: false });
}

function showError(data) {
    $(".error").empty();
    $.each(data || {}, function (key, value) {
        $(".error-" + key).append(Array.isArray(value) ? value[0] : value);
    });
}

$(document).ready(function () {
    $(".select2").select2({ dropdownParent: $("#add-penetration-test") });

    var table = $("#penetration-testing-table").DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: URLs.list,
            type: "POST",
            data: function (d) {
                d._token = $('meta[name="csrf-token"]').attr("content");
            },
        },
        columns: [
            { data: "reference_code", name: "reference_code" },
            { data: "title", name: "title" },
            { data: "system_name", name: "system_name" },
            { data: "technical_owner", name: "technical_owner", orderable: false },
            { data: "grc_manager", name: "grc_manager", orderable: false },
            { data: "status_label", name: "status" },
            { data: "findings_count", name: "findings_count" },
            { data: "open_findings_count", name: "open_findings_count" },
            { data: "actions", name: "actions", orderable: false, searchable: false },
        ],
    });

    window.redrawDatatable = function () {
        table.ajax.reload(null, false);
    };

    $("#add-penetration-test-form").on("submit", function (e) {
        e.preventDefault();
        var formData = new FormData(this);
        $.ajax({
            url: $(this).attr("action"),
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (data) {
                if (data.status) {
                    makeAlert("success", data.message, lang.success);
                    $("#add-penetration-test").modal("hide");
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else {
                        redrawDatatable();
                    }
                } else {
                    showError(data.errors);
                }
            },
            error: function (xhr) {
                var responseData = xhr.responseJSON || {};
                makeAlert("error", responseData.message || "Error", lang.error);
                showError(responseData.errors);
            },
        });
    });

    $(document).on("click", ".delete-pt", function () {
        var id = $(this).data("id");
        Swal.fire({
            title: lang.confirm,
            icon: "warning",
            showCancelButton: true,
        }).then(function (result) {
            if (!result.isConfirmed) return;
            var url = URLs.delete.replace(":id", id);
            $.ajax({
                url: url,
                type: "DELETE",
                data: { _token: $('meta[name="csrf-token"]').attr("content") },
                success: function (data) {
                    makeAlert("success", data.message, lang.success);
                    redrawDatatable();
                },
                error: function (xhr) {
                    makeAlert("error", (xhr.responseJSON || {}).message || "Error", lang.error);
                },
            });
        });
    });
});
