function makeAlert($status, message, title) {
    toastr[$status](message, title || "", { closeButton: true, tapToDismiss: false });
}

function postJson(url, data, reloadOnSuccess) {
    return $.ajax({
        url: url,
        type: "POST",
        data: Object.assign({ _token: CSRF }, data || {}),
        success: function (res) {
            makeAlert(res.status ? "success" : "error", res.message, res.status ? lang.success : lang.error);
            if (res.status && reloadOnSuccess !== false) {
                setTimeout(function () { location.reload(); }, 600);
            }
        },
        error: function (xhr) {
            makeAlert("error", (xhr.responseJSON || {}).message || "Error", lang.error);
        },
    });
}

$(document).on("click", ".workflow-btn", function () {
    var url = $(this).data("url");
    var needNote = $(this).data("need-note");
    if (needNote) {
        Swal.fire({
            title: lang.confirm,
            input: "textarea",
            inputPlaceholder: "Note",
            showCancelButton: true,
        }).then(function (result) {
            if (!result.isConfirmed) return;
            postJson(url, { note: result.value || "" });
        });
        return;
    }
    Swal.fire({ title: lang.confirm, icon: "question", showCancelButton: true }).then(function (result) {
        if (result.isConfirmed) postJson(url, {});
    });
});

$("#add-note-form").on("submit", function (e) {
    e.preventDefault();
    postJson(PT.addNote, {
        note: $(this).find('[name="note"]').val(),
        visibility: $(this).find('[name="visibility"]').val(),
    });
});

$("#add-finding-form").on("submit", function (e) {
    e.preventDefault();
    postJson(PT.addFinding, $(this).serializeArray().reduce(function (acc, cur) {
        acc[cur.name] = cur.value;
        return acc;
    }, {}));
});

$("#owner-respond-form").on("submit", function (e) {
    e.preventDefault();
    postJson(PT.ownerRespond, { note: $(this).find('[name="note"]').val() });
});

$("#upload-report-form").on("submit", function (e) {
    e.preventDefault();
    var formData = new FormData(this);
    formData.append("_token", CSRF);
    $.ajax({
        url: PT.upload,
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (res) {
            makeAlert("success", res.message, lang.success);
            setTimeout(function () { location.reload(); }, 700);
        },
        error: function (xhr) {
            makeAlert("error", (xhr.responseJSON || {}).message || "Error", lang.error);
        },
    });
});

$(document).on("click", ".escalate-finding", function () {
    var id = $(this).data("id");
    Swal.fire({ title: lang.confirm, icon: "warning", showCancelButton: true }).then(function (result) {
        if (result.isConfirmed) postJson(PT.escalate.replace(":id", id), {});
    });
});

$(document).on("click", ".close-finding", function () {
    var id = $(this).data("id");
    Swal.fire({
        title: lang.confirm,
        input: "textarea",
        inputPlaceholder: "Note",
        showCancelButton: true,
    }).then(function (result) {
        if (result.isConfirmed) postJson(PT.closeFinding.replace(":id", id), { note: result.value || "" });
    });
});
