<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class AddRiskNumberToRisksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('risks', function (Blueprint $table) {
            if (!Schema::hasColumn('risks', 'risk_number')) {
                $table->unsignedInteger('risk_number')->nullable()->after('id')->index();
            }
        });

        // Backfill sequential numbers by creation order (id), starting from 1
        $risks = DB::table('risks')->orderBy('id')->pluck('id');
        $number = 1;
        foreach ($risks as $riskId) {
            DB::table('risks')->where('id', $riskId)->update(['risk_number' => $number++]);
        }
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('risks', function (Blueprint $table) {
            if (Schema::hasColumn('risks', 'risk_number')) {
                $table->dropColumn('risk_number');
            }
        });
    }
}
