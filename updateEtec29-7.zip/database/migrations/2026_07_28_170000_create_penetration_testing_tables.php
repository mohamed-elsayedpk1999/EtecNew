<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePenetrationTestingTables extends Migration
{
    public function up()
    {
        Schema::create('penetration_test_sla_rules', function (Blueprint $table) {
            $table->id();
            $table->string('severity'); // Critical, High, Medium, Low, Informational
            $table->unsignedTinyInteger('asset_value_id')->nullable(); // 1-5 optional (same methodology as VM)
            $table->unsignedInteger('sla_days');
            $table->unsignedInteger('reminder_days_before')->default(3);
            $table->unsignedInteger('escalation_days_no_response')->default(7);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->unique(['severity', 'asset_value_id'], 'pt_sla_severity_asset_unique');
        });

        Schema::create('penetration_tests', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('reference_code')->nullable()->unique();
            $table->text('description')->nullable();
            $table->string('system_name')->nullable();
            $table->unsignedBigInteger('asset_id')->nullable();
            $table->unsignedBigInteger('technical_owner_id')->nullable();
            $table->unsignedBigInteger('grc_manager_id')->nullable();
            $table->date('test_date')->nullable();
            $table->enum('status', [
                'draft',
                'pending_grc_approval',
                'rejected',
                'approved',
                'sent_to_owner',
                'owner_responded',
                'escalated_to_risk',
                'returned_to_pentest',
                'closed',
            ])->default('draft');
            $table->timestamp('submitted_for_approval_at')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->timestamp('sent_to_owner_at')->nullable();
            $table->timestamp('owner_responded_at')->nullable();
            $table->timestamp('escalated_at')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('asset_id')->references('id')->on('assets')->nullOnDelete();
            $table->foreign('technical_owner_id')->references('id')->on('users')->nullOnDelete();
            $table->foreign('grc_manager_id')->references('id')->on('users')->nullOnDelete();
            $table->foreign('created_by')->references('id')->on('users')->nullOnDelete();
            $table->foreign('updated_by')->references('id')->on('users')->nullOnDelete();
        });

        Schema::create('penetration_test_files', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('penetration_test_id');
            $table->string('original_name');
            $table->string('stored_name');
            $table->string('path');
            $table->string('mime_type')->nullable();
            $table->string('extension', 20)->nullable();
            $table->unsignedBigInteger('size')->nullable();
            $table->boolean('parsed')->default(false);
            $table->text('parse_notes')->nullable();
            $table->unsignedBigInteger('uploaded_by')->nullable();
            $table->timestamps();

            $table->foreign('penetration_test_id', 'pt_files_pt_fk')
                ->references('id')->on('penetration_tests')->cascadeOnDelete();
            $table->foreign('uploaded_by')->references('id')->on('users')->nullOnDelete();
        });

        Schema::create('penetration_test_findings', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('penetration_test_id');
            $table->string('title');
            $table->string('cve')->nullable();
            $table->enum('severity', ['Critical', 'High', 'Medium', 'Low', 'Informational'])->default('Medium');
            $table->longText('description')->nullable();
            $table->longText('recommendation')->nullable();
            $table->longText('evidence_text')->nullable();
            $table->enum('status', [
                'open',
                'in_progress',
                'awaiting_owner',
                'escalated',
                'under_reevaluation',
                'closed',
                'overdue',
            ])->default('open');
            $table->unsignedInteger('sla_days')->nullable();
            $table->date('sla_due_date')->nullable();
            $table->date('sla_paused_at')->nullable();
            $table->unsignedInteger('sla_remaining_days')->nullable();
            $table->timestamp('notified_owner_at')->nullable();
            $table->timestamp('last_reminder_at')->nullable();
            $table->timestamp('escalated_at')->nullable();
            $table->timestamp('owner_responded_at')->nullable();
            $table->timestamp('closed_at')->nullable();
            $table->boolean('escalated_to_risk')->default(false);
            $table->unsignedBigInteger('risk_id')->nullable();
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('penetration_test_id', 'pt_findings_pt_fk')
                ->references('id')->on('penetration_tests')->cascadeOnDelete();
            $table->foreign('risk_id')->references('id')->on('risks')->nullOnDelete();
        });

        Schema::create('penetration_test_notes', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('penetration_test_id');
            $table->unsignedBigInteger('finding_id')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->string('visibility')->default('all'); // all, pentest, grc, owner, risk
            $table->text('note');
            $table->timestamps();

            $table->foreign('penetration_test_id', 'pt_notes_pt_fk')
                ->references('id')->on('penetration_tests')->cascadeOnDelete();
            $table->foreign('finding_id', 'pt_notes_finding_fk')
                ->references('id')->on('penetration_test_findings')->cascadeOnDelete();
            $table->foreign('user_id')->references('id')->on('users')->nullOnDelete();
        });

        Schema::create('penetration_test_status_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('penetration_test_id')->nullable();
            $table->unsignedBigInteger('finding_id')->nullable();
            $table->string('from_status')->nullable();
            $table->string('to_status');
            $table->string('action')->nullable();
            $table->text('note')->nullable();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->timestamps();

            $table->foreign('penetration_test_id', 'pt_status_logs_pt_fk')
                ->references('id')->on('penetration_tests')->cascadeOnDelete();
            $table->foreign('finding_id', 'pt_status_logs_finding_fk')
                ->references('id')->on('penetration_test_findings')->nullOnDelete();
            $table->foreign('user_id')->references('id')->on('users')->nullOnDelete();
        });
    }

    public function down()
    {
        Schema::dropIfExists('penetration_test_status_logs');
        Schema::dropIfExists('penetration_test_notes');
        Schema::dropIfExists('penetration_test_findings');
        Schema::dropIfExists('penetration_test_files');
        Schema::dropIfExists('penetration_tests');
        Schema::dropIfExists('penetration_test_sla_rules');
    }
}
