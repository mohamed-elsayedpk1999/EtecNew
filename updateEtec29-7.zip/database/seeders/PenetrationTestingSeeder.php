<?php

namespace Database\Seeders;

use App\Models\Action;
use App\Models\PenetrationTestSlaRule;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PenetrationTestingSeeder extends Seeder
{
    public function run()
    {
        $riskGroupId = DB::table('permission_groups')->where('name', 'like', '%Risk%')->value('id')
            ?? DB::table('permission_groups')->orderBy('id')->value('id');

        $subgroup = Subgroup::firstOrCreate(
            ['name' => 'Penetration Testing'],
            ['permission_group_id' => $riskGroupId]
        );

        $keys = [
            'penetration_testing.list' => 'list',
            'penetration_testing.create' => 'create',
            'penetration_testing.update' => 'update',
            'penetration_testing.delete' => 'delete',
            'penetration_testing.print' => 'print',
            'penetration_testing.export' => 'export',
            'penetration_testing.all' => 'all',
            'penetration_testing.approve' => 'approve',
            'penetration_testing.sla' => 'sla',
        ];

        $permissionIds = [];
        foreach ($keys as $key => $name) {
            $permission = Permission::firstOrCreate(
                ['key' => $key],
                ['name' => $name, 'subgroup_id' => $subgroup->id]
            );
            $permissionIds[] = $permission->id;
        }

        // Attach to admin role (id 1) if exists
        $adminRole = Role::find(1);
        if ($adminRole) {
            foreach ($permissionIds as $permissionId) {
                DB::table('role_responsibilities')->updateOrInsert(
                    ['role_id' => 1, 'permission_id' => $permissionId],
                    ['role_id' => 1, 'permission_id' => $permissionId]
                );
            }
        }

        $actions = [
            163 => 'penetration_testing_submit_approval',
            164 => 'penetration_testing_approved',
            165 => 'penetration_testing_rejected',
            166 => 'penetration_testing_sent_to_owner',
            167 => 'penetration_testing_owner_responded',
            168 => 'penetration_testing_escalated',
            169 => 'penetration_testing_returned',
            170 => 'penetration_testing_reevaluate_resend',
            171 => 'penetration_testing_finding_closed',
            172 => 'penetration_testing_finding_closed_escalated',
            173 => 'penetration_testing_sla_reminder',
            174 => 'penetration_testing_sla_overdue',
        ];

        foreach ($actions as $id => $name) {
            Action::updateOrCreate(['id' => $id], ['name' => $name]);
        }

        // Default SLA rules (severity-only, asset_value null) — management methodology defaults
        $defaults = [
            ['severity' => 'Critical', 'sla_days' => 7, 'reminder_days_before' => 2, 'escalation_days_no_response' => 3],
            ['severity' => 'High', 'sla_days' => 14, 'reminder_days_before' => 3, 'escalation_days_no_response' => 5],
            ['severity' => 'Medium', 'sla_days' => 30, 'reminder_days_before' => 5, 'escalation_days_no_response' => 7],
            ['severity' => 'Low', 'sla_days' => 60, 'reminder_days_before' => 7, 'escalation_days_no_response' => 10],
            ['severity' => 'Informational', 'sla_days' => 90, 'reminder_days_before' => 10, 'escalation_days_no_response' => 14],
        ];

        foreach ($defaults as $rule) {
            PenetrationTestSlaRule::firstOrCreate(
                ['severity' => $rule['severity'], 'asset_value_id' => null],
                $rule + ['is_active' => true]
            );
        }
    }
}
