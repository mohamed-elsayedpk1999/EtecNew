@extends('admin/layouts/contentLayoutMaster')

@section('title', $test->title)

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <style>
        .pt-badge { text-transform: capitalize; }
        .finding-card { border: 1px solid #ebebeb; border-radius: 8px; padding: 1rem; margin-bottom: 1rem; }
        .sev-Critical { border-left: 4px solid #ea5455; }
        .sev-High { border-left: 4px solid #ff9f43; }
        .sev-Medium { border-left: 4px solid #ffc107; }
        .sev-Low { border-left: 4px solid #00cfe8; }
        .sev-Informational { border-left: 4px solid #82868b; }
    </style>
@endsection

@section('content')
<div class="content-header row mb-2">
    <div class="col-md-8">
        @isset($breadcrumbs)
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}">{{ __('locale.Dashboard') }}</a></li>
                @foreach ($breadcrumbs as $i => $breadcrumb)
                    @if($i === 0) @continue @endif
                    <li class="breadcrumb-item">
                        @if (!empty($breadcrumb['link']))
                            <a href="{{ url($breadcrumb['link']) }}">{{ $breadcrumb['name'] }}</a>
                        @else
                            {{ $breadcrumb['name'] }}
                        @endif
                    </li>
                @endforeach
            </ol>
        @endisset
        <h3 class="mb-0">{{ $test->title }}
            <small class="text-muted">({{ $test->reference_code }})</small>
        </h3>
        <span class="badge bg-primary pt-badge">{{ __('penetration_testing.status.' . $test->status) }}</span>
    </div>
    <div class="col-md-4 text-end">
        <a href="{{ route('admin.penetration_testing.index') }}" class="btn btn-outline-secondary btn-sm">{{ __('locale.Back') }}</a>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card mb-2">
            <div class="card-header"><h5 class="mb-0">{{ __('penetration_testing.Description') }}</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6"><strong>{{ __('penetration_testing.SystemName') }}:</strong> {{ $test->system_name ?: '-' }}</div>
                    <div class="col-md-6"><strong>{{ __('penetration_testing.Asset') }}:</strong> {{ optional($test->asset)->name ?: '-' }}</div>
                    <div class="col-md-6 mt-1"><strong>{{ __('penetration_testing.TechnicalOwner') }}:</strong> {{ optional($test->technicalOwner)->name }}</div>
                    <div class="col-md-6 mt-1"><strong>{{ __('penetration_testing.GrcManager') }}:</strong> {{ optional($test->grcManager)->name }}</div>
                    <div class="col-md-6 mt-1"><strong>{{ __('penetration_testing.TestDate') }}:</strong> {{ optional($test->test_date)->format('Y-m-d') ?: '-' }}</div>
                    <div class="col-12 mt-1">{{ $test->description }}</div>
                </div>
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">{{ __('penetration_testing.Findings') }} ({{ $test->findings->count() }})</h5>
                @if(auth()->user()->hasPermission('penetration_testing.update') && !in_array($test->status, ['closed']))
                    <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#add-finding-modal">
                        <i class="fa fa-plus"></i> {{ __('penetration_testing.AddFinding') }}
                    </button>
                @endif
            </div>
            <div class="card-body">
                @forelse($test->findings as $finding)
                    <div class="finding-card sev-{{ $finding->severity }}">
                        <div class="d-flex justify-content-between">
                            <div>
                                <h6 class="mb-50">{{ $finding->title }}
                                    @if($finding->cve)<span class="badge bg-secondary">{{ $finding->cve }}</span>@endif
                                </h6>
                                <span class="badge bg-danger">{{ $finding->severity }}</span>
                                <span class="badge bg-info">{{ __('penetration_testing.status.' . $finding->status) }}</span>
                                <span class="badge bg-warning text-dark">
                                    SLA: {{ $finding->sla_due_date ? \Carbon\Carbon::parse($finding->sla_due_date)->format('Y-m-d') : '-' }}
                                    ({{ $finding->sla_days }} {{ __('locale.Days') ?? 'days' }})
                                </span>
                                @if($finding->risk_id)
                                    <a class="badge bg-dark" href="{{ route('admin.risk_management.show', $finding->risk_id) }}" target="_blank">
                                        {{ __('penetration_testing.RiskLink') }} #{{ $finding->risk_id }}
                                    </a>
                                @endif
                            </div>
                            <div class="btn-group">
                                @if(auth()->user()->id == $test->technical_owner_id || auth()->user()->hasPermission('penetration_testing.update'))
                                    @if(!in_array($finding->status, ['closed']))
                                        <button class="btn btn-sm btn-success close-finding" data-id="{{ $finding->id }}">{{ __('penetration_testing.CloseFinding') }}</button>
                                    @endif
                                @endif
                                @if(auth()->user()->hasPermission('penetration_testing.update') && !$finding->escalated_to_risk && !in_array($finding->status, ['closed']))
                                    <button class="btn btn-sm btn-warning escalate-finding" data-id="{{ $finding->id }}">{{ __('penetration_testing.EscalateToRisk') }}</button>
                                @endif
                            </div>
                        </div>
                        @if($finding->description)
                            <p class="mt-1 mb-0 small">{{ \Illuminate\Support\Str::limit(strip_tags($finding->description), 400) }}</p>
                        @endif
                        @if($finding->recommendation)
                            <p class="mb-0 small text-muted"><strong>{{ __('penetration_testing.Recommendation') }}:</strong> {{ \Illuminate\Support\Str::limit($finding->recommendation, 250) }}</p>
                        @endif
                    </div>
                @empty
                    <p class="text-muted mb-0">{{ __('penetration_testing.NoData') }}</p>
                @endforelse
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header"><h5 class="mb-0">{{ __('penetration_testing.Notes') }}</h5></div>
            <div class="card-body">
                <form id="add-note-form" class="mb-2">
                    <textarea name="note" class="form-control mb-1" rows="2" required placeholder="{{ __('penetration_testing.AddNote') }}"></textarea>
                    <div class="d-flex gap-1">
                        <select name="visibility" class="form-select form-select-sm w-auto">
                            <option value="all">all</option>
                            <option value="pentest">pentest</option>
                            <option value="grc">grc</option>
                            <option value="owner">owner</option>
                            <option value="risk">risk</option>
                        </select>
                        <button type="submit" class="btn btn-sm btn-primary">{{ __('penetration_testing.AddNote') }}</button>
                    </div>
                </form>
                <ul class="list-group list-group-flush">
                    @foreach($test->notes->sortByDesc('created_at') as $note)
                        <li class="list-group-item px-0">
                            <div class="d-flex justify-content-between">
                                <strong>{{ optional($note->user)->name }}</strong>
                                <small class="text-muted">{{ $note->created_at }} · {{ $note->visibility }}</small>
                            </div>
                            <div>{{ $note->note }}</div>
                        </li>
                    @endforeach
                </ul>
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header"><h5 class="mb-0">{{ __('penetration_testing.TrackingLog') }}</h5></div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>{{ __('locale.Date') ?? 'Date' }}</th>
                                <th>{{ __('penetration_testing.Finding') }}</th>
                                <th>From</th>
                                <th>To</th>
                                <th>Action</th>
                                <th>User</th>
                                <th>{{ __('penetration_testing.Notes') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($test->statusLogs->sortByDesc('id') as $log)
                                <tr>
                                    <td>{{ $log->created_at }}</td>
                                    <td>{{ $log->finding_id ?: '-' }}</td>
                                    <td>{{ $log->from_status ?: '-' }}</td>
                                    <td>{{ $log->to_status }}</td>
                                    <td>{{ $log->action }}</td>
                                    <td>{{ optional($log->user)->name }}</td>
                                    <td>{{ $log->note }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="card mb-2">
            <div class="card-header"><h5 class="mb-0">{{ __('penetration_testing.Workflow') }}</h5></div>
            <div class="card-body d-grid gap-1">
                @if($test->status === 'draft' && auth()->user()->hasPermission('penetration_testing.update'))
                    <button class="btn btn-primary workflow-btn" data-url="{{ route('admin.penetration_testing.ajax.submitApproval', $test->id) }}">
                        {{ __('penetration_testing.SubmitForApproval') }}
                    </button>
                @endif

                @if($test->status === 'pending_grc_approval' && (auth()->id() == $test->grc_manager_id || auth()->user()->hasPermission('penetration_testing.approve')))
                    <button class="btn btn-success workflow-btn" data-url="{{ route('admin.penetration_testing.ajax.approve', $test->id) }}" data-need-note="1">
                        {{ __('penetration_testing.Approve') }}
                    </button>
                    <button class="btn btn-danger workflow-btn" data-url="{{ route('admin.penetration_testing.ajax.reject', $test->id) }}" data-need-note="1">
                        {{ __('penetration_testing.Reject') }}
                    </button>
                @endif

                @if(in_array($test->status, ['approved', 'returned_to_pentest']) && auth()->user()->hasPermission('penetration_testing.update'))
                    <button class="btn btn-primary workflow-btn" data-url="{{ route('admin.penetration_testing.ajax.sendToOwner', $test->id) }}">
                        {{ __('penetration_testing.SendToOwner') }}
                    </button>
                @endif

                @if(in_array($test->status, ['sent_to_owner', 'owner_responded', 'escalated_to_risk', 'overdue']) || auth()->id() == $test->technical_owner_id)
                    @if(auth()->id() == $test->technical_owner_id || auth()->user()->hasPermission('penetration_testing.update'))
                        <button class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#owner-respond-modal">
                            {{ __('penetration_testing.OwnerRespond') }}
                        </button>
                    @endif
                @endif

                @if($test->status === 'returned_to_pentest' && auth()->user()->hasPermission('penetration_testing.update'))
                    <button class="btn btn-info workflow-btn" data-url="{{ route('admin.penetration_testing.ajax.reEvaluate', $test->id) }}" data-need-note="1">
                        {{ __('penetration_testing.ReEvaluate') }}
                    </button>
                @endif
            </div>
        </div>

        <div class="card mb-2">
            <div class="card-header"><h5 class="mb-0">{{ __('penetration_testing.Files') }}</h5></div>
            <div class="card-body">
                <ul class="list-unstyled">
                    @foreach($test->files as $file)
                        <li class="mb-1">
                            <a href="{{ route('admin.penetration_testing.downloadFile', $file->id) }}">
                                <i class="fa fa-file"></i> {{ $file->original_name }}
                            </a>
                            @if($file->parse_notes)
                                <small class="d-block text-muted">{{ $file->parse_notes }}</small>
                            @endif
                        </li>
                    @endforeach
                </ul>
                @if(auth()->user()->hasPermission('penetration_testing.update'))
                    <form id="upload-report-form" enctype="multipart/form-data">
                        <input type="file" name="report_file" class="form-control mb-1" accept=".pdf,.doc,.docx" required>
                        <button class="btn btn-sm btn-primary w-100" type="submit">{{ __('penetration_testing.UploadReport') }}</button>
                    </form>
                @endif
            </div>
        </div>
    </div>
</div>

{{-- Add Finding Modal --}}
<div class="modal fade" id="add-finding-modal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" id="add-finding-form">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('penetration_testing.AddFinding') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-1">
                    <label class="form-label">{{ __('penetration_testing.Title') }}</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="mb-1">
                    <label class="form-label">{{ __('penetration_testing.Severity') }}</label>
                    <select name="severity" class="form-select" required>
                        @foreach(['Critical','High','Medium','Low','Informational'] as $sev)
                            <option value="{{ $sev }}">{{ $sev }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="mb-1">
                    <label class="form-label">{{ __('penetration_testing.CVE') }}</label>
                    <input type="text" name="cve" class="form-control">
                </div>
                <div class="mb-1">
                    <label class="form-label">{{ __('penetration_testing.Description') }}</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                <div class="mb-1">
                    <label class="form-label">{{ __('penetration_testing.Recommendation') }}</label>
                    <textarea name="recommendation" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">{{ __('locale.Save') }}</button>
            </div>
        </form>
    </div>
</div>

{{-- Owner Respond Modal --}}
<div class="modal fade" id="owner-respond-modal" tabindex="-1">
    <div class="modal-dialog">
        <form class="modal-content" id="owner-respond-form">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('penetration_testing.OwnerRespond') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <textarea name="note" class="form-control" rows="4" required></textarea>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-primary">{{ __('locale.Save') }}</button>
            </div>
        </form>
    </div>
</div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
    var CSRF = "{{ csrf_token() }}";
    var lang = { success: "{{ __('locale.Success') }}", error: "{{ __('locale.Error') }}", confirm: "{{ __('locale.AreYouSureToDeleteThisRecord') }}" };
    var PT = {
        id: {{ $test->id }},
        addNote: "{{ route('admin.penetration_testing.ajax.addNote', $test->id) }}",
        addFinding: "{{ route('admin.penetration_testing.ajax.storeFinding', $test->id) }}",
        upload: "{{ route('admin.penetration_testing.ajax.uploadReport', $test->id) }}",
        ownerRespond: "{{ route('admin.penetration_testing.ajax.ownerRespond', $test->id) }}",
        escalate: "{{ route('admin.penetration_testing.ajax.escalateFinding', ':id') }}",
        closeFinding: "{{ route('admin.penetration_testing.ajax.closeFinding', ':id') }}",
    };
</script>
<script src="{{ asset('ajax-files/penetration_testing/show.js') }}"></script>
@endsection
