@extends('admin/layouts/contentLayoutMaster')

@section('title', __('penetration_testing.SlaSettings'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('content')
<div class="card">
    <div class="card-header d-flex justify-content-between">
        <h4 class="mb-0">{{ __('penetration_testing.SlaSettings') }}</h4>
        <a href="{{ route('admin.penetration_testing.index') }}" class="btn btn-outline-secondary btn-sm">{{ __('locale.Back') }}</a>
    </div>
    <div class="card-body">
        <p class="text-muted">{{ __('penetration_testing.ParseHint') }}</p>
        <form id="sla-settings-form">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>{{ __('penetration_testing.Severity') }}</th>
                            <th>{{ __('penetration_testing.AssetValue') }}</th>
                            <th>{{ __('penetration_testing.SlaDays') }}</th>
                            <th>{{ __('penetration_testing.ReminderDays') }}</th>
                            <th>{{ __('penetration_testing.EscalationDays') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($rules as $i => $rule)
                            <tr>
                                <td>
                                    <input type="hidden" name="rules[{{ $i }}][id]" value="{{ $rule->id }}">
                                    <input type="hidden" name="rules[{{ $i }}][severity]" value="{{ $rule->severity }}">
                                    {{ $rule->severity }}
                                </td>
                                <td>
                                    <input type="number" min="1" max="5" class="form-control" name="rules[{{ $i }}][asset_value_id]" value="{{ $rule->asset_value_id }}">
                                </td>
                                <td><input type="number" min="1" class="form-control" name="rules[{{ $i }}][sla_days]" value="{{ $rule->sla_days }}" required></td>
                                <td><input type="number" min="0" class="form-control" name="rules[{{ $i }}][reminder_days_before]" value="{{ $rule->reminder_days_before }}" required></td>
                                <td><input type="number" min="1" class="form-control" name="rules[{{ $i }}][escalation_days_no_response]" value="{{ $rule->escalation_days_no_response }}" required></td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <button type="submit" class="btn btn-primary">{{ __('locale.Save') }}</button>
        </form>
    </div>
</div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
$('#sla-settings-form').on('submit', function (e) {
    e.preventDefault();
    $.ajax({
        url: "{{ route('admin.penetration_testing.ajax.updateSlaSettings') }}",
        type: "POST",
        data: $(this).serialize() + "&_token={{ csrf_token() }}",
        success: function (data) {
            toastr[data.status ? 'success' : 'error'](data.message);
        },
        error: function (xhr) {
            toastr.error(xhr.responseJSON?.message || 'Error');
        }
    });
});
</script>
@endsection
