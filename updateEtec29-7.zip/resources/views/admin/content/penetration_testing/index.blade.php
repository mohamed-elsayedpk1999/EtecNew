@extends('admin/layouts/contentLayoutMaster')

@section('title', __('penetration_testing.PenetrationTesting'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <style>.error{color:red!important;font-size:14px;display:block;margin-top:5px}</style>
@endsection

@section('content')
<div class="content-header row">
    <div class="content-header-left col-12 mb-2">
        <div class="row breadcrumbs-top widget-grid">
            <div class="col-12">
                <div class="page-title mt-2">
                    <div class="row">
                        <div class="col-sm-6 ps-0">
                            @isset($breadcrumbs)
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}" style="display:flex;">
                                        <svg class="stroke-icon"><use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}"></use></svg></a></li>
                                    @foreach ($breadcrumbs as $breadcrumb)
                                        <li class="breadcrumb-item">
                                            @if (!empty($breadcrumb['link']))
                                                <a href="{{ url($breadcrumb['link']) }}">{{ $breadcrumb['name'] }}</a>
                                            @else
                                                {{ $breadcrumb['name'] }}
                                            @endif
                                        </li>
                                    @endforeach
                                </ol>
                            @endisset
                        </div>
                        <div class="col-sm-6 pe-0" style="text-align:end;">
                            <div class="action-content d-flex align-items-center justify-content-end gap-2">
                                @if (auth()->user()->hasPermission('penetration_testing.create'))
                                    <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#add-penetration-test" title="{{ __('penetration_testing.AddEngagement') }}">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                    <a href="{{ route('admin.penetration_testing.notificationsSettings') }}" class="btn btn-primary" title="{{ __('locale.NotificationsSettings') }}">
                                        <i class="fa-regular fa-bell"></i>
                                    </a>
                                @endif
                                @if (auth()->user()->hasPermission('penetration_testing.sla'))
                                    <a href="{{ route('admin.penetration_testing.slaSettings') }}" class="btn btn-primary" title="{{ __('penetration_testing.SlaSettings') }}">
                                        <i class="fa-solid fa-clock"></i>
                                    </a>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<section class="users-list-wrapper">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped" id="penetration-testing-table">
                    <thead>
                        <tr>
                            <th>{{ __('penetration_testing.Reference') }}</th>
                            <th>{{ __('penetration_testing.Title') }}</th>
                            <th>{{ __('penetration_testing.SystemName') }}</th>
                            <th>{{ __('penetration_testing.TechnicalOwner') }}</th>
                            <th>{{ __('penetration_testing.GrcManager') }}</th>
                            <th>{{ __('penetration_testing.Status') }}</th>
                            <th>{{ __('penetration_testing.TotalFindings') }}</th>
                            <th>{{ __('penetration_testing.OpenFindings') }}</th>
                            <th>{{ __('locale.Actions') }}</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
</section>

{{-- Add Modal --}}
<div class="modal fade" id="add-penetration-test" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <form id="add-penetration-test-form" action="{{ route('admin.penetration_testing.ajax.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('penetration_testing.AddEngagement') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted small">{{ __('penetration_testing.ParseHint') }}</p>
                    <div class="row">
                        <div class="col-md-6 mb-1">
                            <label class="form-label">{{ __('penetration_testing.Title') }} *</label>
                            <input type="text" name="title" class="form-control" required>
                            <span class="error error-title"></span>
                        </div>
                        <div class="col-md-6 mb-1">
                            <label class="form-label">{{ __('penetration_testing.SystemName') }}</label>
                            <input type="text" name="system_name" class="form-control">
                        </div>
                        <div class="col-md-6 mb-1">
                            <label class="form-label">{{ __('penetration_testing.TechnicalOwner') }} *</label>
                            <select name="technical_owner_id" class="form-select select2" required>
                                <option value="">--</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                @endforeach
                            </select>
                            <span class="error error-technical_owner_id"></span>
                        </div>
                        <div class="col-md-6 mb-1">
                            <label class="form-label">{{ __('penetration_testing.GrcManager') }} *</label>
                            <select name="grc_manager_id" class="form-select select2" required>
                                <option value="">--</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                @endforeach
                            </select>
                            <span class="error error-grc_manager_id"></span>
                        </div>
                        <div class="col-md-6 mb-1">
                            <label class="form-label">{{ __('penetration_testing.Asset') }}</label>
                            <select name="asset_id" class="form-select select2">
                                <option value="">--</option>
                                @foreach($assets as $asset)
                                    <option value="{{ $asset->id }}">{{ $asset->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-6 mb-1">
                            <label class="form-label">{{ __('penetration_testing.TestDate') }}</label>
                            <input type="date" name="test_date" class="form-control">
                        </div>
                        <div class="col-12 mb-1">
                            <label class="form-label">{{ __('penetration_testing.Description') }}</label>
                            <textarea name="description" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-12 mb-1">
                            <label class="form-label">{{ __('penetration_testing.ReportFile') }}</label>
                            <input type="file" name="report_file" class="form-control" accept=".pdf,.doc,.docx">
                            <span class="error error-report_file"></span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                    <button type="submit" class="btn btn-primary">{{ __('locale.Save') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
<script>
    var lang = { success: "{{ __('locale.Success') }}", error: "{{ __('locale.Error') }}", confirm: "{{ __('locale.AreYouSureToDeleteThisRecord') }}" };
    var URLs = {
        list: "{{ route('admin.penetration_testing.ajax.index') }}",
        store: "{{ route('admin.penetration_testing.ajax.store') }}",
        delete: "{{ route('admin.penetration_testing.ajax.destroy', ':id') }}",
    };
</script>
<script src="{{ asset('ajax-files/penetration_testing/index.js') }}"></script>
@endsection
