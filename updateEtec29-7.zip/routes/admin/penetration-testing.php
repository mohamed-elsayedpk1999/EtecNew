<?php

use App\Http\Controllers\admin\penetration_testing\PenetrationTestingController;
use Illuminate\Support\Facades\Route;

Route::group(
    [
        'prefix' => 'penetration-testing',
        'middleware' => [],
        'as' => 'penetration_testing.',
    ],
    function () {
        Route::get('/', [PenetrationTestingController::class, 'index'])->name('index');
        Route::get('/show/{id}', [PenetrationTestingController::class, 'show'])->name('show');
        Route::get('/sla-settings', [PenetrationTestingController::class, 'slaSettings'])->name('slaSettings');
        Route::get('/notifications-settings', [PenetrationTestingController::class, 'notificationsSettings'])->name('notificationsSettings');
        Route::get('/download-file/{fileId}', [PenetrationTestingController::class, 'downloadFile'])->name('downloadFile');

        Route::group(
            [
                'prefix' => 'ajax',
                'as' => 'ajax.',
            ],
            function () {
                Route::post('/list', [PenetrationTestingController::class, 'ajaxGetList'])->name('index');
                Route::post('/', [PenetrationTestingController::class, 'store'])->name('store');
                Route::put('/{id}', [PenetrationTestingController::class, 'update'])->name('update');
                Route::delete('/{id}', [PenetrationTestingController::class, 'destroy'])->name('destroy');

                Route::post('/{id}/upload-report', [PenetrationTestingController::class, 'uploadReport'])->name('uploadReport');
                Route::post('/{id}/findings', [PenetrationTestingController::class, 'storeFinding'])->name('storeFinding');
                Route::put('/findings/{findingId}', [PenetrationTestingController::class, 'updateFinding'])->name('updateFinding');
                Route::post('/{id}/notes', [PenetrationTestingController::class, 'addNote'])->name('addNote');

                Route::post('/{id}/submit-approval', [PenetrationTestingController::class, 'submitApproval'])->name('submitApproval');
                Route::post('/{id}/approve', [PenetrationTestingController::class, 'approve'])->name('approve');
                Route::post('/{id}/reject', [PenetrationTestingController::class, 'reject'])->name('reject');
                Route::post('/{id}/send-to-owner', [PenetrationTestingController::class, 'sendToOwner'])->name('sendToOwner');
                Route::post('/{id}/owner-respond', [PenetrationTestingController::class, 'ownerRespond'])->name('ownerRespond');
                Route::post('/{id}/re-evaluate', [PenetrationTestingController::class, 'reEvaluate'])->name('reEvaluate');
                Route::post('/findings/{findingId}/escalate', [PenetrationTestingController::class, 'escalateFinding'])->name('escalateFinding');
                Route::post('/findings/{findingId}/close', [PenetrationTestingController::class, 'closeFinding'])->name('closeFinding');
                Route::post('/sla-settings', [PenetrationTestingController::class, 'updateSlaSettings'])->name('updateSlaSettings');
            }
        );
    }
);
