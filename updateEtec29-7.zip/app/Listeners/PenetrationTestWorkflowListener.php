<?php

namespace App\Listeners;

use App\Events\PenetrationTestWorkflowEvent;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\User;
use Illuminate\Support\Facades\Log;

class PenetrationTestWorkflowListener
{
    use NotificationHandlingTrait;

    /** Map workflow steps to Action.name values */
    protected $actionMap = [
        'pending_grc_approval' => 'penetration_testing_submit_approval',
        'approved' => 'penetration_testing_approved',
        'rejected' => 'penetration_testing_rejected',
        'sent_to_owner' => 'penetration_testing_sent_to_owner',
        'owner_responded' => 'penetration_testing_owner_responded',
        'escalated_to_risk' => 'penetration_testing_escalated',
        'returned_to_pentest' => 'penetration_testing_returned',
        'reevaluate_resend' => 'penetration_testing_reevaluate_resend',
        'finding_closed' => 'penetration_testing_finding_closed',
        'finding_closed_after_escalation' => 'penetration_testing_finding_closed_escalated',
        'sla_reminder' => 'penetration_testing_sla_reminder',
        'sla_overdue' => 'penetration_testing_sla_overdue',
    ];

    public function handle(PenetrationTestWorkflowEvent $event)
    {
        try {
            $actionKey = $this->actionMap[$event->actionName] ?? null;
            if (!$actionKey) {
                return;
            }

            $action = Action::where('name', $actionKey)->first();
            if (!$action) {
                Log::info('PenTest notification skipped; action missing: ' . $actionKey);
                return;
            }

            $test = $event->penetrationTest;
            $finding = $event->finding;

            $openCount = $test->findings()->whereNotIn('status', ['closed'])->count();
            $totalCount = $test->findings()->count();
            $severitySummary = collect($test->findingsCountBySeverity())
                ->map(fn ($count, $sev) => $sev . ': ' . $count)
                ->implode(', ');

            $nearestDue = $test->findings()
                ->whereNotIn('status', ['closed'])
                ->whereNotNull('sla_due_date')
                ->orderBy('sla_due_date')
                ->value('sla_due_date');

            $test->Report_Title = $test->title;
            $test->System_Name = $test->system_name;
            $test->Status = $test->status;
            $test->Findings_Count = $totalCount;
            $test->Open_Findings_Count = $openCount;
            $test->Severity_Summary = $severitySummary ?: '-';
            $test->SLA_Due_Date = $nearestDue ?: '-';
            $test->Technical_Owner = optional($test->technicalOwner)->name;
            $test->GRC_Manager = optional($test->grcManager)->name;
            $test->Finding_Title = optional($finding)->title;
            $test->Finding_Severity = optional($finding)->severity;
            $test->Finding_Status = optional($finding)->status;
            $test->Finding_SLA_Due = optional(optional($finding)->sla_due_date)->format('Y-m-d') ?? optional($finding)->sla_due_date;
            $test->Risk_ID = optional($finding)->risk_id;

            $roles = [
                'creator' => [$test->created_by],
                'GRC_Manager' => [$test->grc_manager_id],
                'Technical_Owner' => [$test->technical_owner_id],
            ];

            // Risk team = users with riskmanagement.list or risks.list permission if resolvable
            $riskTeamIds = User::whereHas('role.permissions', function ($q) {
                $q->whereIn('key', ['riskmanagement.list', 'risks.list', 'risk_management.list']);
            })->pluck('id')->take(50)->toArray();
            $roles['Risk_Team'] = $riskTeamIds;

            // Pen-test team = creator + users with module permission
            $penTestIds = User::whereHas('role.permissions', function ($q) {
                $q->where('key', 'penetration_testing.list');
            })->pluck('id')->take(50)->toArray();
            $roles['PenTest_Team'] = array_values(array_unique(array_filter(array_merge($penTestIds, [$test->created_by]))));

            $link = ['link' => route('admin.penetration_testing.show', $test->id)];

            $this->sendNotificationForAction(
                $action->id,
                null,
                $link,
                $test,
                $roles,
                null,
                null,
                null,
                null
            );
        } catch (\Throwable $e) {
            Log::error('PenetrationTestWorkflowListener failed: ' . $e->getMessage());
        }
    }
}
