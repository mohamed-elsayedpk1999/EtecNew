<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PenetrationTestFile extends Model
{
    public $guarded = [];

    protected $casts = [
        'parsed' => 'boolean',
    ];

    public function penetrationTest()
    {
        return $this->belongsTo(PenetrationTest::class);
    }

    public function uploader()
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }
}
