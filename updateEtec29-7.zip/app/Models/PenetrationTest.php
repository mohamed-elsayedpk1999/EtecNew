<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PenetrationTest extends Model
{
    use SoftDeletes;

    public $guarded = [];

    protected $casts = [
        'test_date' => 'date',
        'submitted_for_approval_at' => 'datetime',
        'approved_at' => 'datetime',
        'sent_to_owner_at' => 'datetime',
        'owner_responded_at' => 'datetime',
        'escalated_at' => 'datetime',
        'closed_at' => 'datetime',
    ];

    public function findings()
    {
        return $this->hasMany(PenetrationTestFinding::class);
    }

    public function openFindings()
    {
        return $this->findings()->whereNotIn('status', ['closed']);
    }

    public function files()
    {
        return $this->hasMany(PenetrationTestFile::class);
    }

    public function notes()
    {
        return $this->hasMany(PenetrationTestNote::class);
    }

    public function statusLogs()
    {
        return $this->hasMany(PenetrationTestStatusLog::class);
    }

    public function asset()
    {
        return $this->belongsTo(Asset::class);
    }

    public function technicalOwner()
    {
        return $this->belongsTo(User::class, 'technical_owner_id');
    }

    public function grcManager()
    {
        return $this->belongsTo(User::class, 'grc_manager_id');
    }

    public function creator()
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function findingsCountBySeverity(): array
    {
        return $this->findings()
            ->selectRaw('severity, count(*) as total')
            ->groupBy('severity')
            ->pluck('total', 'severity')
            ->toArray();
    }
}
