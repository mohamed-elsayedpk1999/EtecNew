<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PenetrationTestSlaRule extends Model
{
    public $guarded = [];

    protected $casts = [
        'is_active' => 'boolean',
    ];
}
