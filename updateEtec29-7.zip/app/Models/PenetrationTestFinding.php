<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PenetrationTestFinding extends Model
{
    use SoftDeletes;

    public $guarded = [];

    protected $casts = [
        'sla_due_date' => 'date',
        'sla_paused_at' => 'date',
        'notified_owner_at' => 'datetime',
        'last_reminder_at' => 'datetime',
        'escalated_at' => 'datetime',
        'owner_responded_at' => 'datetime',
        'closed_at' => 'datetime',
        'escalated_to_risk' => 'boolean',
    ];

    public function penetrationTest()
    {
        return $this->belongsTo(PenetrationTest::class);
    }

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }

    public function notes()
    {
        return $this->hasMany(PenetrationTestNote::class, 'finding_id');
    }

    public function statusLogs()
    {
        return $this->hasMany(PenetrationTestStatusLog::class, 'finding_id');
    }

    public function isOpen(): bool
    {
        return !in_array($this->status, ['closed'], true);
    }
}
