<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PenetrationTestStatusLog extends Model
{
    public $guarded = [];

    public function penetrationTest()
    {
        return $this->belongsTo(PenetrationTest::class);
    }

    public function finding()
    {
        return $this->belongsTo(PenetrationTestFinding::class, 'finding_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
