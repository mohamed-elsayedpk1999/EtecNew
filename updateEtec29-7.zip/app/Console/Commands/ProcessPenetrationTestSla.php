<?php

namespace App\Console\Commands;

use App\Events\PenetrationTestWorkflowEvent;
use App\Models\PenetrationTestFinding;
use App\Services\PenetrationTesting\PenTestSlaService;
use App\Services\PenetrationTesting\PenTestWorkflowService;
use Carbon\Carbon;
use Illuminate\Console\Command;

class ProcessPenetrationTestSla extends Command
{
    protected $signature = 'penetration-testing:process-sla';
    protected $description = 'Send SLA reminders, mark overdue findings, and escalate unresponsive owner findings to risk';

    public function handle(PenTestWorkflowService $workflow, PenTestSlaService $sla)
    {
        $reminded = 0;
        $escalated = 0;

        $overdueCount = $workflow->markOverdueFindings();

        // Remind owners when due date is approaching
        $openFindings = PenetrationTestFinding::with(['penetrationTest.technicalOwner', 'penetrationTest.grcManager', 'penetrationTest.creator'])
            ->whereNotIn('status', ['closed', 'escalated', 'under_reevaluation'])
            ->whereNotNull('sla_due_date')
            ->whereNull('sla_paused_at')
            ->get();

        foreach ($openFindings as $finding) {
            $test = $finding->penetrationTest;
            if (!$test) {
                continue;
            }

            $reminderDays = $sla->reminderDaysBefore($finding->severity);
            $due = Carbon::parse($finding->sla_due_date)->startOfDay();
            $today = Carbon::today();
            $daysLeft = $today->diffInDays($due, false);

            if ($daysLeft >= 0 && $daysLeft <= $reminderDays) {
                $alreadyToday = $finding->last_reminder_at && Carbon::parse($finding->last_reminder_at)->isToday();
                if (!$alreadyToday) {
                    $finding->update(['last_reminder_at' => now()]);
                    event(new PenetrationTestWorkflowEvent($test, 'sla_reminder', $finding));
                    $reminded++;
                }
            }

            // Escalate if owner never responded and past escalation window after notify
            if (
                in_array($finding->status, ['awaiting_owner', 'overdue'], true)
                && !$finding->escalated_to_risk
                && $finding->notified_owner_at
                && !$finding->owner_responded_at
            ) {
                $escalationDays = $sla->escalationDaysNoResponse($finding->severity);
                if (Carbon::parse($finding->notified_owner_at)->addDays($escalationDays)->lte(now())) {
                    $workflow->escalateFindingToRisk($finding);
                    $escalated++;
                }
            }

            // Continuous overdue alert
            if ($finding->status === 'overdue') {
                $alreadyToday = $finding->last_reminder_at && Carbon::parse($finding->last_reminder_at)->isToday();
                if (!$alreadyToday) {
                    $finding->update(['last_reminder_at' => now()]);
                    event(new PenetrationTestWorkflowEvent($test, 'sla_overdue', $finding));
                    $reminded++;
                }
            }
        }

        $this->info("Overdue marked: {$overdueCount}, Reminders: {$reminded}, Escalated: {$escalated}");
        return 0;
    }
}
