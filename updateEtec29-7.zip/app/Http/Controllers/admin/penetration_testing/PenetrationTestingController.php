<?php

namespace App\Http\Controllers\admin\penetration_testing;

use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\Asset;
use App\Models\PenetrationTest;
use App\Models\PenetrationTestFile;
use App\Models\PenetrationTestFinding;
use App\Models\PenetrationTestSlaRule;
use App\Models\User;
use App\Services\PenetrationTesting\PenTestReportParser;
use App\Services\PenetrationTesting\PenTestSlaService;
use App\Services\PenetrationTesting\PenTestWorkflowService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Yajra\DataTables\Facades\DataTables;

class PenetrationTestingController extends Controller
{
    protected $workflow;
    protected $parser;
    protected $sla;

    public function __construct(PenTestWorkflowService $workflow, PenTestReportParser $parser, PenTestSlaService $sla)
    {
        $this->workflow = $workflow;
        $this->parser = $parser;
        $this->sla = $sla;
    }

    public function index()
    {
        $users = User::select('id', 'name', 'email')->where('enabled', true)->get();
        $assets = Asset::select('id', 'name', 'asset_value_id')->get();
        $slaRules = PenetrationTestSlaRule::orderBy('severity')->get();
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('penetration_testing.PenetrationTesting')],
        ];

        return view('admin.content.penetration_testing.index', compact('breadcrumbs', 'users', 'assets', 'slaRules'));
    }

    public function show($id)
    {
        $test = PenetrationTest::with([
            'findings.risk',
            'files',
            'notes.user',
            'statusLogs.user',
            'technicalOwner',
            'grcManager',
            'asset',
            'creator',
        ])->findOrFail($id);

        $users = User::select('id', 'name', 'email')->where('enabled', true)->get();
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.penetration_testing.index'), 'name' => __('penetration_testing.PenetrationTesting')],
            ['name' => $test->title],
        ];

        return view('admin.content.penetration_testing.show', compact('breadcrumbs', 'test', 'users'));
    }

    public function ajaxGetList(Request $request)
    {
        $query = PenetrationTest::with(['technicalOwner', 'grcManager', 'creator'])
            ->withCount([
                'findings',
                'findings as open_findings_count' => function ($q) {
                    $q->whereNotIn('status', ['closed']);
                },
            ])
            ->latest();

        $user = auth()->user();
        if (!($user->role_id == 1 || $user->hasPermission('penetration_testing.all'))) {
            $query->where(function ($q) use ($user) {
                $q->where('created_by', $user->id)
                    ->orWhere('technical_owner_id', $user->id)
                    ->orWhere('grc_manager_id', $user->id);
            });
        }

        return DataTables::of($query)
            ->addColumn('technical_owner', fn ($row) => optional($row->technicalOwner)->name)
            ->addColumn('grc_manager', fn ($row) => optional($row->grcManager)->name)
            ->addColumn('status_label', function ($row) {
                return __('penetration_testing.status.' . $row->status);
            })
            ->addColumn('actions', function ($row) {
                $showUrl = route('admin.penetration_testing.show', $row->id);
                $html = '<a class="btn btn-sm btn-primary" href="' . $showUrl . '"><i class="fa fa-eye"></i></a> ';
                if (auth()->user()->hasPermission('penetration_testing.delete')) {
                    $html .= '<button class="btn btn-sm btn-danger delete-pt" data-id="' . $row->id . '"><i class="fa fa-trash"></i></button>';
                }
                return $html;
            })
            ->rawColumns(['actions'])
            ->make(true);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'title' => ['required', 'max:255'],
            'system_name' => ['nullable', 'max:255'],
            'description' => ['nullable', 'string'],
            'asset_id' => ['nullable', 'exists:assets,id'],
            'technical_owner_id' => ['required', 'exists:users,id'],
            'grc_manager_id' => ['required', 'exists:users,id'],
            'test_date' => ['nullable', 'date'],
            'report_file' => ['nullable', 'file', 'mimes:pdf,doc,docx', 'max:20480'],
            'findings' => ['nullable', 'array'],
            'findings.*.title' => ['required_with:findings', 'max:255'],
            'findings.*.severity' => ['required_with:findings', Rule::in(['Critical', 'High', 'Medium', 'Low', 'Informational'])],
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        try {
            DB::beginTransaction();

            $test = PenetrationTest::create([
                'title' => $request->title,
                'reference_code' => 'PT-' . now()->format('Ymd') . '-' . strtoupper(substr(uniqid(), -5)),
                'description' => $request->description,
                'system_name' => $request->system_name,
                'asset_id' => $request->asset_id,
                'technical_owner_id' => $request->technical_owner_id,
                'grc_manager_id' => $request->grc_manager_id,
                'test_date' => $request->test_date,
                'status' => 'draft',
                'created_by' => auth()->id(),
                'updated_by' => auth()->id(),
            ]);

            if ($request->hasFile('report_file')) {
                $this->storeAndParseReport($test, $request->file('report_file'));
            }

            foreach ($request->input('findings', []) as $index => $findingData) {
                $this->createFinding($test, $findingData, $index);
            }

            $this->workflow->logStatus($test, null, null, 'draft', 'create');

            DB::commit();

            return response()->json([
                'status' => true,
                'message' => __('penetration_testing.CreatedSuccessfully'),
                'id' => $test->id,
                'redirect' => route('admin.penetration_testing.show', $test->id),
            ]);
        } catch (\Throwable $e) {
            DB::rollBack();
            return response()->json(['status' => false, 'message' => $e->getMessage()], 500);
        }
    }

    public function update(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'title' => ['required', 'max:255'],
            'system_name' => ['nullable', 'max:255'],
            'description' => ['nullable', 'string'],
            'asset_id' => ['nullable', 'exists:assets,id'],
            'technical_owner_id' => ['required', 'exists:users,id'],
            'grc_manager_id' => ['required', 'exists:users,id'],
            'test_date' => ['nullable', 'date'],
        ]);

        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        $test->update([
            'title' => $request->title,
            'description' => $request->description,
            'system_name' => $request->system_name,
            'asset_id' => $request->asset_id,
            'technical_owner_id' => $request->technical_owner_id,
            'grc_manager_id' => $request->grc_manager_id,
            'test_date' => $request->test_date,
            'updated_by' => auth()->id(),
        ]);

        return response()->json(['status' => true, 'message' => __('penetration_testing.UpdatedSuccessfully')]);
    }

    public function destroy($id)
    {
        $test = PenetrationTest::findOrFail($id);
        foreach ($test->files as $file) {
            Storage::delete($file->path);
        }
        $test->delete();
        return response()->json(['status' => true, 'message' => __('penetration_testing.DeletedSuccessfully')]);
    }

    public function uploadReport(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'report_file' => ['required', 'file', 'mimes:pdf,doc,docx', 'max:20480'],
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        $parsedCount = $this->storeAndParseReport($test, $request->file('report_file'));

        return response()->json([
            'status' => true,
            'message' => __('penetration_testing.ReportUploaded', ['count' => $parsedCount]),
            'parsed_count' => $parsedCount,
        ]);
    }

    public function storeFinding(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'title' => ['required', 'max:255'],
            'severity' => ['required', Rule::in(['Critical', 'High', 'Medium', 'Low', 'Informational'])],
            'description' => ['nullable', 'string'],
            'recommendation' => ['nullable', 'string'],
            'cve' => ['nullable', 'max:100'],
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        $finding = $this->createFinding($test, $request->all());
        return response()->json(['status' => true, 'message' => __('penetration_testing.FindingAdded'), 'finding' => $finding]);
    }

    public function updateFinding(Request $request, $findingId)
    {
        $finding = PenetrationTestFinding::findOrFail($findingId);
        $validator = Validator::make($request->all(), [
            'title' => ['required', 'max:255'],
            'severity' => ['required', Rule::in(['Critical', 'High', 'Medium', 'Low', 'Informational'])],
            'description' => ['nullable', 'string'],
            'recommendation' => ['nullable', 'string'],
            'cve' => ['nullable', 'max:100'],
            'status' => ['nullable', Rule::in(['open', 'in_progress', 'awaiting_owner', 'escalated', 'under_reevaluation', 'closed', 'overdue'])],
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        $oldStatus = $finding->status;
        $oldSeverity = $finding->severity;
        $data = $request->only(['title', 'severity', 'description', 'recommendation', 'cve', 'status']);
        $finding->update($data);

        if ($request->filled('status') && $request->status !== $oldStatus) {
            $this->workflow->logStatus($finding->penetrationTest, $finding, $oldStatus, $request->status, 'manual_status_update');
            if ($request->status === 'closed') {
                $this->workflow->closeFinding($finding->fresh(), $request->input('note'));
            }
        }

        if ($request->severity !== $oldSeverity && $finding->fresh()->isOpen()) {
            $this->sla->applySlaToFinding($finding->fresh(), optional($finding->penetrationTest)->asset, Carbon::now());
        }

        return response()->json(['status' => true, 'message' => __('penetration_testing.FindingUpdated')]);
    }

    public function addNote(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'note' => ['required', 'string'],
            'finding_id' => ['nullable', 'exists:penetration_test_findings,id'],
            'visibility' => ['nullable', Rule::in(['all', 'pentest', 'grc', 'owner', 'risk'])],
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        $note = $this->workflow->addNote($test, $request->note, $request->finding_id, $request->visibility ?? 'all');
        return response()->json(['status' => true, 'message' => __('penetration_testing.NoteAdded'), 'note' => $note->load('user')]);
    }

    public function submitApproval($id)
    {
        $test = PenetrationTest::findOrFail($id);
        if ($test->findings()->count() < 1) {
            return response()->json(['status' => false, 'message' => __('penetration_testing.NeedFindings')], 422);
        }
        $this->workflow->submitForGrcApproval($test);
        return response()->json(['status' => true, 'message' => __('penetration_testing.SubmittedForApproval')]);
    }

    public function approve(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $this->workflow->approveByGrc($test, $request->input('note'));
        return response()->json(['status' => true, 'message' => __('penetration_testing.Approved')]);
    }

    public function reject(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $this->workflow->rejectByGrc($test, $request->input('note'));
        return response()->json(['status' => true, 'message' => __('penetration_testing.Rejected')]);
    }

    public function sendToOwner($id)
    {
        $test = PenetrationTest::findOrFail($id);
        if (!in_array($test->status, ['approved', 'returned_to_pentest'], true)) {
            return response()->json(['status' => false, 'message' => __('penetration_testing.InvalidStatus')], 422);
        }
        $this->workflow->sendToTechnicalOwner($test);
        return response()->json(['status' => true, 'message' => __('penetration_testing.SentToOwner')]);
    }

    public function ownerRespond(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'note' => ['required', 'string'],
            'finding_id' => ['nullable', 'exists:penetration_test_findings,id'],
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        $this->workflow->ownerRespond($test, $request->note, $request->finding_id);
        return response()->json(['status' => true, 'message' => __('penetration_testing.OwnerResponseSaved')]);
    }

    public function reEvaluate(Request $request, $id)
    {
        $test = PenetrationTest::findOrFail($id);
        $this->workflow->reEvaluateAndResendToOwner($test, $request->input('note'));
        return response()->json(['status' => true, 'message' => __('penetration_testing.ResentToOwner')]);
    }

    public function escalateFinding($findingId)
    {
        $finding = PenetrationTestFinding::findOrFail($findingId);
        $finding = $this->workflow->escalateFindingToRisk($finding);
        return response()->json([
            'status' => true,
            'message' => __('penetration_testing.EscalatedToRisk'),
            'risk_id' => $finding->risk_id,
        ]);
    }

    public function closeFinding(Request $request, $findingId)
    {
        $finding = PenetrationTestFinding::findOrFail($findingId);
        $this->workflow->closeFinding($finding, $request->input('note'));
        return response()->json(['status' => true, 'message' => __('penetration_testing.FindingClosed')]);
    }

    public function slaSettings()
    {
        $rules = PenetrationTestSlaRule::orderBy('severity')->orderBy('asset_value_id')->get();
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.penetration_testing.index'), 'name' => __('penetration_testing.PenetrationTesting')],
            ['name' => __('penetration_testing.SlaSettings')],
        ];
        return view('admin.content.penetration_testing.sla-settings', compact('breadcrumbs', 'rules'));
    }

    public function updateSlaSettings(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'rules' => ['required', 'array'],
            'rules.*.id' => ['nullable', 'exists:penetration_test_sla_rules,id'],
            'rules.*.severity' => ['required', Rule::in(['Critical', 'High', 'Medium', 'Low', 'Informational'])],
            'rules.*.sla_days' => ['required', 'integer', 'min:1'],
            'rules.*.reminder_days_before' => ['required', 'integer', 'min:0'],
            'rules.*.escalation_days_no_response' => ['required', 'integer', 'min:1'],
            'rules.*.asset_value_id' => ['nullable', 'integer', 'min:1', 'max:5'],
        ]);
        if ($validator->fails()) {
            return response()->json(['status' => false, 'errors' => $validator->errors()], 422);
        }

        foreach ($request->rules as $ruleData) {
            PenetrationTestSlaRule::updateOrCreate(
                [
                    'severity' => $ruleData['severity'],
                    'asset_value_id' => $ruleData['asset_value_id'] ?? null,
                ],
                [
                    'sla_days' => $ruleData['sla_days'],
                    'reminder_days_before' => $ruleData['reminder_days_before'],
                    'escalation_days_no_response' => $ruleData['escalation_days_no_response'],
                    'is_active' => true,
                ]
            );
        }

        return response()->json(['status' => true, 'message' => __('penetration_testing.SlaUpdated')]);
    }

    public function notificationsSettings()
    {
        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['link' => route('admin.penetration_testing.index'), 'name' => __('penetration_testing.PenetrationTesting')],
            ['name' => __('locale.NotificationsSettings')],
        ];
        $users = User::select('id', 'name')->where('enabled', true)->get();
        $moduleActionsIds = Action::where('name', 'like', 'penetration_testing_%')->orderBy('id')->pluck('id')->toArray();
        $moduleActionsIdsAutoNotify = [];

        $variableList = [
            'Report_Title', 'System_Name', 'Status', 'Findings_Count', 'Open_Findings_Count',
            'Severity_Summary', 'SLA_Due_Date', 'Technical_Owner', 'GRC_Manager',
            'Finding_Title', 'Finding_Severity', 'Finding_Status', 'Finding_SLA_Due', 'Risk_ID',
        ];
        $roleList = [
            'creator' => 'Creator',
            'GRC_Manager' => 'GRC Manager',
            'Technical_Owner' => 'Technical Owner',
            'Risk_Team' => 'Risk Team',
            'PenTest_Team' => 'Penetration Testing Team',
        ];

        $actionsVariables = [];
        $actionsRoles = [];
        foreach ($moduleActionsIds as $actionId) {
            $actionsVariables[$actionId] = $variableList;
            $actionsRoles[$actionId] = $roleList;
        }

        $actionsWithSettings = Action::whereIn('actions.id', $moduleActionsIds)
            ->leftJoin('system_notifications_settings', 'actions.id', '=', 'system_notifications_settings.action_id')
            ->leftJoin('mail_settings', 'actions.id', '=', 'mail_settings.action_id')
            ->leftJoin('sms_settings', 'actions.id', '=', 'sms_settings.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'system_notifications_settings.id as system_notification_setting_id',
                'system_notifications_settings.status as system_notification_setting_status',
                'mail_settings.id as mail_setting_id',
                'mail_settings.status as mail_setting_status',
                'sms_settings.id as sms_setting_id',
                'sms_settings.status as sms_setting_status',
            ]);
        $actionsWithSettingsAuto = [];

        return view('admin.notifications-settings.index', compact(
            'breadcrumbs',
            'users',
            'actionsWithSettings',
            'actionsVariables',
            'actionsRoles',
            'moduleActionsIdsAutoNotify',
            'actionsWithSettingsAuto'
        ));
    }

    public function downloadFile($fileId)
    {
        $file = PenetrationTestFile::findOrFail($fileId);
        return Storage::download($file->path, $file->original_name);
    }

    protected function storeAndParseReport(PenetrationTest $test, $uploaded): int
    {
        $path = $uploaded->store('penetration_tests/' . $test->id);
        $file = PenetrationTestFile::create([
            'penetration_test_id' => $test->id,
            'original_name' => $uploaded->getClientOriginalName(),
            'stored_name' => basename($path),
            'path' => $path,
            'mime_type' => $uploaded->getClientMimeType(),
            'extension' => strtolower($uploaded->getClientOriginalExtension()),
            'size' => $uploaded->getSize(),
            'uploaded_by' => auth()->id(),
        ]);

        $parsed = $this->parser->parse($file);
        foreach ($parsed as $index => $findingData) {
            $this->createFinding($test, $findingData, $index);
        }

        return count($parsed);
    }

    protected function createFinding(PenetrationTest $test, array $data, int $sort = 0): PenetrationTestFinding
    {
        $finding = PenetrationTestFinding::create([
            'penetration_test_id' => $test->id,
            'title' => $data['title'],
            'cve' => $data['cve'] ?? null,
            'severity' => $data['severity'] ?? 'Medium',
            'description' => $data['description'] ?? null,
            'recommendation' => $data['recommendation'] ?? null,
            'evidence_text' => $data['evidence_text'] ?? null,
            'status' => 'open',
            'sort_order' => $sort,
        ]);

        $this->sla->applySlaToFinding($finding, $test->asset, Carbon::now());
        $this->workflow->logStatus($test, $finding, null, 'open', 'create_finding');

        return $finding->fresh();
    }
}
