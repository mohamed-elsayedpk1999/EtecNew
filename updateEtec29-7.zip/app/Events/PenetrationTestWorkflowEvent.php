<?php

namespace App\Events;

use App\Models\PenetrationTest;
use App\Models\PenetrationTestFinding;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class PenetrationTestWorkflowEvent
{
    use Dispatchable, SerializesModels;

    public $penetrationTest;
    public $actionName;
    public $finding;

    public function __construct(PenetrationTest $penetrationTest, string $actionName, ?PenetrationTestFinding $finding = null)
    {
        $this->penetrationTest = $penetrationTest;
        $this->actionName = $actionName;
        $this->finding = $finding;
    }
}
