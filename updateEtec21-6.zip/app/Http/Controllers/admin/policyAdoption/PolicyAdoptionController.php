<?php

namespace App\Http\Controllers\admin\policyAdoption;

use App\Exports\PolicyAdoptionExport;
use App\Events\PolicyAdoptionCreated;
use App\Events\PolicyAdoptionDeleted;
use App\Events\PolicyAdoptionStatusChanged;
use App\Events\PolicyAdoptionUpdated;
use App\Http\Controllers\Controller;
use App\Models\Action;
use App\Models\Document;
use App\Models\DocumentContentChange;
use App\Models\PolicyAdoption;
use App\Models\PolicyAdoptionConfig;
use App\Models\PolicySignature;
use App\Models\PolicySignatureAction;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use Twilio\Jwt\TaskRouter\Policy;
use Twilio\Rest\Preview;
use Yajra\DataTables\Facades\DataTables;

class PolicyAdoptionController extends Controller
{
    public function index()
    {
        if (!auth()->user()->hasPermission('policy_adoptions.list')) {
            abort(403, 'Unauthorized action.');
        }

        $users = User::select('name', 'id')->get();
        $config = PolicyAdoptionConfig::first(); // one record only

        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('locale.Governance')],
            ['name' => __('locale.AdoptionPolicies')]
        ];

        return view('admin.content.adoption_policy.index', compact('breadcrumbs', 'users', 'config'));
    }


    public function GetData(Request $request)
    {
        if ($request->ajax()) {
            $policiesQuery = PolicyAdoption::with('user', 'signature');

            // If the user is NOT admin (role_id != 1), filter policies assigned to them
            if (auth()->user()->role_id != 1) {
                $userId = auth()->id();
                $policiesQuery->whereHas('signature', function ($query) use ($userId) {
                    $query->whereRaw("FIND_IN_SET(?, rapporteurs)", [
                        $userId,
                        $userId,
                        $userId
                    ]);
                });
            }

            $policies = $policiesQuery->get();

            return DataTables::of($policies)
                ->addColumn('title', function ($policy) {
                    return $policy->name;
                })
                ->addColumn('created_by', function ($policy) {
                    return $policy->user->name;
                })
                ->addColumn('created_at', function ($policy) {
                    return $policy->created_at->format('Y-m-d');
                })
                ->addColumn('category', function ($policy) {
                    return $policy->category->name;
                })
                ->addColumn('action', function ($policy) {
                    $actions = '';

                    if (
                        auth()->user()->hasPermission('policy_adoptions.update') ||
                        auth()->user()->hasPermission('policy_adoptions.delete') ||
                        auth()->user()->hasPermission('policy_adoptions.preview_result')
                    ) {

                        $dropdown = '<div class="dropdown">
                        <a class="pe-1 dropdown-toggle hide-arrow text-primary" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-more-vertical font-small-4">
                                <circle cx="12" cy="12" r="1"></circle>
                                <circle cx="12" cy="5" r="1"></circle>
                                <circle cx="12" cy="19" r="1"></circle>
                            </svg>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">';

                        if (auth()->user()->hasPermission('policy_adoptions.update') && $policy->end_adoption == 0) {
                            $dropdown .= '<li><a class="dropdown-item edit-adotionPolicy" href="#" data-id="' . $policy->id . '">Edit</a></li>';
                        }

                        if (auth()->user()->hasPermission('policy_adoptions.delete')) {
                            $dropdown .= '<li><a class="dropdown-item delete-adotionPolicy" href="#" data-id="' . $policy->id . '">Delete</a></li>';
                        }

                        if (auth()->user()->hasPermission('policy_adoptions.preview_result') && $policy->signature && $policy->end_adoption == 0) {
                            $userId = auth()->id();
                            $rapporteurs = explode(',', $policy->signature->rapporteurs);
                            if (in_array($userId, $rapporteurs)) {
                                // $dropdown .= '<li><a class="dropdown-item" href="' . route('admin.adoption_policies.getPolicyAdoptionPreview', [$policy->id, 'preview']) . '">Preview</a></li>';
                                $dropdown .= '<li>
                                    <a class="dropdown-item preview-policy" href="#" data-id="' . $policy->id . '">
                                        Preview
                                    </a>
                                </li>';
                            }
                        }
                        if (auth()->user()->hasPermission('policy_adoptions.print')) {
                            $dropdown .= '<li><a class="dropdown-item export-adotionPolicy" href="#" data-id="' . $policy->id . '">Export</a></li>';
                        }


                        $dropdown .= '</ul></div>';
                        $actions = $dropdown;
                    } else {
                        $actions = '---';
                    }

                    return $actions;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
    }




    public function store(Request $request)
    {
        DB::beginTransaction();
        try {
            $content = [
                'en' => $request->introduction_content_en,
                'ar' => $request->introduction_content_ar
            ];

            $content2 = [
                'en' => $request->introduction_content_en2,
                'ar' => $request->introduction_content_ar2
            ];
            $description = [
                'en' => $request->description_content_en,
                'ar' => $request->description_content_ar
            ];


            $documentsIds = Document::where('document_type', $request->category_id)
                ->pluck('id')
                ->toArray();

            // Create new adoption policy
            $adoptionPolicy = PolicyAdoption::create([
                'name' => $request->name,
                'description' => $description,
                'category_id' => $request->category_id,
                'introduction_content' => $content,
                'introduction_content2' => $content2,
                'documents_ids' => implode(',', $documentsIds),
                'created_by' => auth()->id(),
            ]);

            // Set end_adoption = 1 for previous policies in the same category
            PolicyAdoption::where('category_id', $request->category_id)
                ->where('id', '!=', $adoptionPolicy->id) // don't update the newly created
                ->update(['end_adoption' => 1]);

            // Get latest config
            $config = PolicyAdoptionConfig::latest()->first();

            // Create policy signature
            $policySignature = PolicySignature::create([
                'policy_id' => $adoptionPolicy->id,
                'rapporteurs' => $config->rapporteurs,
            ]);

            DB::commit();
            event(new PolicyAdoptionCreated($adoptionPolicy, $policySignature));

            return response()->json([
                'status' => true,
                'message' => 'Policy adopted successfully!',
                'data' => $adoptionPolicy,
                'reload' => true
            ]);
        } catch (\Exception $e) {
            DD($e);
            DB::rollBack();
            return response()->json([
                'status' => false,
                'message' => 'Something went wrong while saving policy.',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    public function destroy(PolicyAdoption $policyAdoption)
    {
        DB::beginTransaction();
        try {
            event(new PolicyAdoptionDeleted($policyAdoption, $policyAdoption->signature));
            // Delete related policy signature(s)
            $policyAdoption->signatureActions()->delete();
            $policyAdoption->signature()->delete();
            // Delete the policy adoption itself
            $policyAdoption->delete();

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Policy Adoption and related signatures deleted successfully',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to delete Policy Adoption: ' . $e->getMessage(),
            ], 500);
        }
    }


    public function saveConfig(Request $request)
    {
        $request->validate([
            'rapporteurs' => 'required|array',
        ]);

        DB::beginTransaction();
        try {
            PolicyAdoptionConfig::updateOrCreate(
                ['id' => $request->id],
                [
                    'rapporteurs' => implode(',', $request->rapporteurs)
                ]
            );

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Configuration saved successfully!',
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to save configuration: ' . $e->getMessage(),
            ], 500);
        }
    }


    public function show($id)
    {
        $policy = PolicyAdoption::findOrFail($id);

        // Decode safely (fallback to empty array)
        $introduction1 = json_decode($policy->getRawOriginal('introduction_content') ?? '{}', true);
        $introduction2 = json_decode($policy->getRawOriginal('introduction_content2') ?? '{}', true);
        $description   = json_decode($policy->getRawOriginal('description') ?? '{}', true);

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $policy->id,
                'category_id' => $policy->category_id,
                'name' => $policy->name,
                // introduction 1
                'introduction_content_en' => $introduction1['en'] ?? '',
                'introduction_content_ar' => $introduction1['ar'] ?? '',
                // introduction 2
                'introduction_content2_en' => $introduction2['en'] ?? '',
                'introduction_content2_ar' => $introduction2['ar'] ?? '',

                // description
                'description_en' => $description['en'] ?? '',
                'description_ar' => $description['ar'] ?? '',
            ]
        ]);
    }


    public function update(Request $request)
    {
        DB::beginTransaction();

        try {
            $policy = PolicyAdoption::findOrFail($request->id);

            $introduction1 = [
                'en' => $request->introduction_content_en,
                'ar' => $request->introduction_content_ar,
            ];

            $introduction2 = [
                'en' => $request->introduction_content_en2,
                'ar' => $request->introduction_content_ar2,
            ];

            $description = [
                'en' => $request->description_en,
                'ar' => $request->description_ar,
            ];

            $policy->update([
                'name' => $request->name,
                'category_id' => $request->category_id,

                'introduction_content' => $introduction1,
                'introduction_content2' => $introduction2,
                'description' => $description,
            ]);

            DB::commit();

            event(new PolicyAdoptionUpdated($policy, $policy->signature));

            return response()->json([
                'success' => true,
                'message' => 'Policy Adoption updated successfully!',
                'data' => $policy,
                'reload' => true,
            ]);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Failed to update Policy Adoption: ' . $e->getMessage(),
            ], 500);
        }
    }

    public function updateStatus(Request $request)
    {
        DB::beginTransaction();
        try {
            $signatureAction = PolicySignatureAction::create([
                'signature_id' => $request->signature_id,
                'document_id'    => $request->document_id,
                'action1'      => $request->action1 ?? 0,
                'action2'      => $request->action2 ?? 0,
                'user_id'      => auth()->id(),
            ]);
            $signatureAction->load('signature.policyAdoption');
            DB::commit();
            event(new PolicyAdoptionStatusChanged(
                $signatureAction
            ));
            return response()->json([
                'success' => true,
                'message' => 'Policy adopted status updated successfully!',
                'updated_by' => auth()->user()->name,
                'reload' => true
            ]);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
                'message' => 'Failed to update status: ' . $e->getMessage(),
            ], 500);
        }
    }


    public function getPolicyAdoptionPreview($policyId, $documentId)
    {
        // Load policy
        $policy = PolicyAdoption::with('signature')->findOrFail($policyId);
        $userId = auth()->id();
        $rapporteurs = explode(',', $policy->signature->rapporteurs);
        if (!in_array($userId, $rapporteurs)) {
            abort(403, 'You do not have access to this resource.');
        }
        $actions = PolicySignatureAction::where('user_id', auth()->user()->id)->where('signature_id', $policy->signature->id)->where('document_id',$documentId)->first();

        // Load selected document
        $document = Document::findOrFail($documentId);

        return view('admin.content.adoption_policy.policyPerview', compact(
            'policy',
            'document',
            'actions'
        ));
    }

    public function previewDocuments($id)
    {
        $policy = PolicyAdoption::with(['signature.signatureActions'])
            ->findOrFail($id);

        $documentIds = explode(',', $policy->documents_ids ?? '');

        $documents = Document::whereIn('id', $documentIds)
            ->get()
            ->map(function ($doc) use ($policy) {
                $action = $policy->signature?->signatureActions
                    ->where('user_id', auth()->id())
                    ->where('document_id', $doc->id)
                    ->first();

                return [
                    'id' => $doc->id,
                    'title' => $doc->document_name,
                    'action' => $action ? [
                        'id' => $action->id,
                        'action' => $action->action1,
                        'action2' => $action->action2,
                        'created_at' => $action->created_at,
                    ] : null,
                ];
            })
            ->values();

        return response()->json([
            'success' => true,
            'data' => [
                'id' => $policy->id,
                'documents' => $documents,
            ],
        ]);
    }

    public function export(Request $request)
    {
        if (!auth()->user()->hasPermission('policy_adoptions.print')) {
            abort(403, 'Unauthorized action.');
        }

        $policyId = $request->input('policy_id');

        if (!PolicyAdoption::where('id', $policyId)->exists()) {
            abort(404, 'Policy adoption not found');
        }

        return Excel::download(
            new PolicyAdoptionExport($policyId),
            'policy_adoption_' . $policyId . '.xlsx'
        );
    }

    public function notificationsSettingsPolicyAdoption()
    {
        // defining the breadcrumbs that will be shown in page

        $breadcrumbs = [
            ['link' => route('admin.dashboard'), 'name' => __('locale.Dashboard')],
            ['name' => __('locale.Regulators')],
            ['link' => route('admin.governance.control.list'), 'name' => __('locale.Control')],
            ['name' => __('locale.NotificationsSettings')]
        ];

        $users = User::select('id', 'name')->get();  // getting all users to list them in select input of users
        $moduleActionsIds = [145, 146, 147, 148];   // defining ids of actions modules
        $moduleActionsIdsAutoNotify = [];  // defining ids of actions modules

        // defining variables associated with each action "for the user to choose variables he wants to add to the message of notification" "each action id will be the array key of action's variables list"
        $actionsVariables = [
            145 => ['name', 'category', 'created_by', 'rapporteur'],
            146 => ['name', 'category', 'created_by', 'rapporteur'],
            147 => ['name', 'category', 'created_by', 'rapporteur'],
            148 => ['name', 'category', 'created_by', 'rapporteur'],


        ];
        // defining roles associated with each action "for the user to choose roles he wants to sent the notification to" "each action id will be the array key of action's roles list"
        $actionsRoles = [
            145 => ['rapporteur' => __('locale.rapporteur'), 'creator' => __('locale.creator')],
            146 => ['rapporteur' => __('locale.rapporteur'), 'creator' => __('locale.creator')],
            147 =>  ['rapporteur' => __('locale.rapporteur'), 'creator' => __('locale.creator')],
            148 =>  ['rapporteur' => __('locale.rapporteur'), 'creator' => __('locale.creator')],

        ];
        // getting actions with their system notifications settings, sms settings and mail settings to list them in tables
        $actionsWithSettings = Action::whereIn('actions.id', $moduleActionsIds)
            ->leftJoin('system_notifications_settings', 'actions.id', '=', 'system_notifications_settings.action_id')
            ->leftJoin('mail_settings', 'actions.id', '=', 'mail_settings.action_id')
            ->leftJoin('sms_settings', 'actions.id', '=', 'sms_settings.action_id')
            ->leftJoin('auto_notifies', 'actions.id', '=', 'auto_notifies.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'system_notifications_settings.id as system_notification_setting_id',
                'system_notifications_settings.status as system_notification_setting_status',
                'mail_settings.id as mail_setting_id',
                'mail_settings.status as mail_setting_status',
                'sms_settings.id as sms_setting_id',
                'sms_settings.status as sms_setting_status',
                'auto_notifies.id as auto_notifies_id',
                'auto_notifies.status as auto_notifies_status',
            ]);
        $actionsWithSettingsAuto = Action::whereIn('actions.id', $moduleActionsIdsAutoNotify)
            ->leftJoin('auto_notifies', 'actions.id', '=', 'auto_notifies.action_id')
            ->get([
                'actions.id as action_id',
                'actions.name as action_name',
                'auto_notifies.id as auto_notifies_id',
                'auto_notifies.status as auto_notifies_status',
            ]);
        return view('admin.notifications-settings.index', compact('breadcrumbs', 'users', 'actionsWithSettings', 'actionsVariables', 'actionsRoles', 'moduleActionsIdsAutoNotify', 'actionsWithSettingsAuto'));
    }
}
