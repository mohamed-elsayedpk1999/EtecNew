<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PolicySignature extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function signatureActions()
    {
        return $this->hasMany(PolicySignatureAction::class, 'signature_id');
    }

    public function policyAdoption()
    {
        return $this->belongsTo(policyAdoption::class, 'policy_id');
    }
}
