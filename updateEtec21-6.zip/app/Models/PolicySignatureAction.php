<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PolicySignatureAction extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function signature()
    {
        return $this->belongsTo(PolicySignature::class, 'signature_id');
    }
}
