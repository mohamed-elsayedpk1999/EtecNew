<?php

namespace App\Events;

use App\Models\PolicyAdoption;
use App\Models\PolicySignature;
use App\Models\PolicySignatureAction;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class PolicyAdoptionStatusChanged
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $signatureAction; 

    public function __construct(PolicySignatureAction $signatureAction)
    {
        $this->signatureAction = $signatureAction;
    }

    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}