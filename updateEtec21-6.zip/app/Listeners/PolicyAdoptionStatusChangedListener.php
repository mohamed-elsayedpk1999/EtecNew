<?php

namespace App\Listeners;

use App\Events\PolicyAdoptionStatusChanged;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class PolicyAdoptionStatusChangedListener
{
 use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(PolicyAdoptionStatusChanged $event)
    {

        // Get the action ID for Risk_Add
        $action1 = Action::where('name', 'policy_adoption_change_status')->first();
        $actionId1 = $action1['id'];

        // Access the variables from the event
        $signatureAction = $event->signatureAction;

        // Convert IDs to arrays
        $rapporteurs = $signatureAction->signature?->rapporteurs ? explode(',', $signatureAction->signature?->rapporteurs) : [];
        // Get user names from IDs
        $rapporteursNames = User::whereIn('id', $rapporteurs)->pluck('name')->toArray();

        // Prepare roles for notifications
        $roles = [
            'rapporteur' => $rapporteurs,
            'creator' =>[$signatureAction->signature?->policyAdoption?->created_by]
        ];
        $link = ['link' => route('admin.adoption_policies.index')];

        // Set properties for notification (names instead of IDs)
        $signatureAction->category = $signatureAction->signature?->policyAdoption?->category->name ?? null;
        $signatureAction->created_by = $signatureAction->signature?->policyAdoption?->user->name ?? null;
        $signatureAction->rapporteur =implode(',',$rapporteursNames);
        $signatureAction->name = $signatureAction->signature?->policyAdoption?->name ?? null;

        
        // Call the function to handle different kinds of notifications
        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // handling different kinds of notifications using  "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $signatureAction, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}