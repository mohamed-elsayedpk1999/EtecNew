<?php

namespace App\Listeners;

use App\Events\PolicyAdoptionCreated;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\PolicyAdoption;
use App\Models\User;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class PolicyAdoptionCreatedListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(PolicyAdoptionCreated $event)
    {

        // Get the action ID for Risk_Add
        $action1 = Action::where('name', 'policy_adoption_add')->first();
        $actionId1 = $action1['id'];

        // Access the variables from the event
        $policyAdoption = $event->policyAdoption;
        $policySignature = $event->policySignature;

        // Example usage
        $action = Action::where('name', 'policy_adoption_add')->first();
        $actionId = $action->id;

        // Convert IDs to arrays
        $rapporteurs = $policySignature->rapporteurs ? explode(',', $policySignature->rapporteurs) : [];
        // Get user names from IDs
        $rapporteurs = User::whereIn('id', $rapporteurs)->pluck('name')->toArray();


        // Prepare roles for notifications
        $roles = [
            'rapporteurs' => $rapporteurs,
            'creator' => [$policyAdoption->created_by ?? null],
        ];

        $link = ['link' => route('admin.adoption_policies.index')];

        // Set properties for notification (names instead of IDs)
        $policyAdoption->category = $policyAdoption->category->name ?? null;
        $policyAdoption->created_by = $policyAdoption->user->name ?? null;
        $policyAdoption->rapporteur = implode(', ', $rapporteurs);

        // Call the function to handle different kinds of notifications
        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // handling different kinds of notifications using  "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $policyAdoption, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}