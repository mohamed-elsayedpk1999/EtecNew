<?php

namespace App\Exports;

use App\Models\Document;
use App\Models\PolicyAdoption;
use App\Models\User;
use Carbon\Carbon;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithCustomStartCell;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithStyles;
use Maatwebsite\Excel\Events\AfterSheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Worksheet\Drawing;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class PolicyAdoptionExport implements FromArray, WithStyles, WithColumnWidths, WithEvents, WithCustomStartCell
{
    protected $policyData;
    protected $documentGroups = [];
    protected $reportData = [];
    protected $groupRowRanges = [];
    protected $hasAction2 = false;

    public function __construct($policyId)
    {
        $this->policyData = PolicyAdoption::with([
            'user',
            'category',
            'signature.signatureActions',
        ])->findOrFail($policyId);

        $introduction2 = json_decode($this->policyData->getRawOriginal('introduction_content2') ?? '{}', true);
        $this->hasAction2 = !empty($introduction2['en']) || !empty($introduction2['ar']);

        $documentIds = array_filter(explode(',', $this->policyData->documents_ids ?? ''));
        $documents = Document::whereIn('id', $documentIds)->get(['id', 'document_name']);

        $rapporteurIds = array_filter(explode(',', $this->policyData->signature?->rapporteurs ?? ''));
        $rapporteurs = User::whereIn('id', $rapporteurIds)->get()->keyBy('id');

        $signatureActions = $this->policyData->signature?->signatureActions ?? collect();

        $relativeRow = 0;

        foreach ($documents as $document) {
            $users = [];

            foreach ($rapporteurIds as $rapporteurId) {
                $rapporteur = $rapporteurs->get((int) $rapporteurId);
                $action = $signatureActions
                    ->where('document_id', $document->id)
                    ->where('user_id', (int) $rapporteurId)
                    ->first();

                $statusKey = $this->resolveStatusKey($action);

                $userRow = [
                    'rapporteur'    => $rapporteur?->name ?? '—',
                    'action1'       => $this->formatActionValue($action?->action1, $action !== null),
                    'action2'       => $this->formatActionValue($action?->action2, $action !== null, $this->hasAction2),
                    'status'        => $this->translateStatus($statusKey),
                    'status_key'    => $statusKey,
                    'signed_date'   => $action?->created_at
                        ? Carbon::parse($action->created_at)->format('Y-m-d')
                        : null,
                ];

                $users[] = $userRow;
                $this->reportData[] = array_merge(['document_name' => $document->document_name], $userRow);
            }

            if (empty($users)) {
                continue;
            }

            $groupStart = $relativeRow + 1;
            $relativeRow += count($users);

            $this->documentGroups[] = [
                'document_name' => $document->document_name,
                'users'         => $users,
            ];

            $this->groupRowRanges[] = [
                'start' => $groupStart,
                'end'   => $relativeRow,
            ];
        }
    }

    protected function trans(string $key, array $replace = []): string
    {
        return __('policy_adoptions.export.' . $key, $replace);
    }

    protected function headerRowNumber(): int
    {
        return count($this->introductionRows()) + 1;
    }

    protected function firstDataRowNumber(): int
    {
        return $this->headerRowNumber() + 1;
    }

    protected function lastDataRowNumber(): int
    {
        if (empty($this->reportData)) {
            return $this->headerRowNumber();
        }

        return $this->firstDataRowNumber() + count($this->reportData) - 1;
    }

    protected function introductionRows(): array
    {
        $rapporteurIds = array_filter(explode(',', $this->policyData->signature?->rapporteurs ?? ''));
        $rapporteurNames = User::whereIn('id', $rapporteurIds)->pluck('name')->implode(', ') ?: '—';

        return [
            [$this->trans('document_revision_history')],
            [
                $this->trans('reviewer'),
                $this->trans('version'),
                $this->trans('date'),
                $this->trans('description'),
            ],
            [
                $rapporteurNames,
                $this->policyData->id,
                $this->policyData->created_at
                    ? Carbon::parse($this->policyData->created_at)->format('d/m/Y')
                    : '—',
                $this->policyData->category?->name ?? '—',
            ],
            ['', '', '', ''],
            ['', '', '', ''],
            [$this->trans('report_purpose')],
            [$this->trans('report_purpose_line1')],
            [$this->trans('report_purpose_line2')],
            ['', '', '', ''],
            [$this->trans('policy_name') . ': ' . ($this->policyData->name ?? '—')],
            [$this->trans('category') . ': ' . ($this->policyData->category?->name ?? '—')],
            [$this->trans('created_by') . ': ' . ($this->policyData->user?->name ?? '—')],
            [$this->trans('report_generated_on') . ': ' . Carbon::now()->format('F j, Y')],
            [$this->trans('generated_by') . ': ' . (auth()->user()->name ?? $this->trans('system'))],
            ['', '', '', ''],
            ['', '', '', ''],
            ['', '', '', ''],
        ];
    }

    protected function formatActionValue($value, bool $hasRecord, bool $applicable = true): string
    {
        if (!$applicable) {
            return $this->trans('na');
        }

        if (!$hasRecord) {
            return $this->trans('pending');
        }

        return $value
            ? '✔ ' . $this->trans('yes')
            : '✘ ' . $this->trans('no');
    }

    protected function resolveStatusKey($action): string
    {
        if (!$action) {
            return 'not_signed';
        }

        $action1 = (bool) $action->action1;
        $action2 = (bool) $action->action2;

        if ($action1 && (!$this->hasAction2 || $action2)) {
            return 'completed';
        }

        if ($action1 || $action2) {
            return 'partial';
        }

        return 'not_signed';
    }

    protected function translateStatus(string $statusKey): string
    {
        return match ($statusKey) {
            'completed'   => '✔ ' . $this->trans('status_completed'),
            'partial'     => $this->trans('status_partial'),
            default       => $this->trans('status_not_signed'),
        };
    }

    protected function buildGroupedRows(): array
    {
        $rows = [];

        foreach ($this->documentGroups as $group) {
            $isFirstUser = true;

            foreach ($group['users'] as $user) {
                $rows[] = [
                    $isFirstUser ? $group['document_name'] : '',
                    $user['rapporteur'],
                    $user['action1'],
                    $user['action2'],
                    $user['status'],
                    $user['signed_date'],
                ];

                $isFirstUser = false;
            }
        }

        return $rows;
    }

    public function array(): array
    {
        $headerRow = [[
            $this->trans('document_name'),
            $this->trans('rapporteur'),
            $this->trans('action1'),
            $this->trans('action2'),
            $this->trans('status'),
            $this->trans('signed_date'),
        ]];

        return array_merge($this->introductionRows(), $headerRow, $this->buildGroupedRows());
    }

    public function startCell(): string
    {
        return 'A1';
    }

    public function styles(Worksheet $sheet)
    {
        $headerRow = $this->headerRowNumber();
        $firstDataRow = $this->firstDataRowNumber();
        $lastDataRow = $this->lastDataRowNumber();

        return [
            1 => [
                'font' => ['bold' => true, 'size' => 16, 'color' => ['rgb' => '1F4E78']],
                'alignment' => ['horizontal' => Alignment::HORIZONTAL_LEFT],
            ],
            2 => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78'],
                ],
            ],
            3 => [
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => 'F2F2F2'],
                ],
            ],
            6 => [
                'font' => ['bold' => true, 'size' => 12],
            ],
            10 => [
                'font' => ['bold' => true],
            ],
            11 => [
                'font' => ['bold' => true],
            ],
            12 => [
                'font' => ['bold' => true],
            ],
            13 => [
                'font' => ['italic' => true],
            ],
            14 => [
                'font' => ['italic' => true],
            ],
            $headerRow => [
                'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                'alignment' => [
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                    'vertical' => Alignment::VERTICAL_CENTER,
                ],
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'color' => ['rgb' => '1F4E78'],
                ],
            ],
            'A' . $firstDataRow . ':F' . max($firstDataRow, $lastDataRow) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => Alignment::HORIZONTAL_LEFT,
                ],
                'borders' => [
                    'allBorders' => [
                        'borderStyle' => Border::BORDER_THIN,
                        'color' => ['rgb' => 'D9D9D9'],
                    ],
                ],
            ],
            'C' . $firstDataRow . ':E' . max($firstDataRow, $lastDataRow) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                ],
            ],
            'F' . $firstDataRow . ':F' . max($firstDataRow, $lastDataRow) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_CENTER,
                    'horizontal' => Alignment::HORIZONTAL_CENTER,
                ],
            ],
            'A1:D' . ($headerRow - 1) => [
                'alignment' => [
                    'vertical' => Alignment::VERTICAL_TOP,
                ],
            ],
        ];
    }

    public function columnWidths(): array
    {
        return [
            'A' => 35,
            'B' => 25,
            'C' => 15,
            'D' => 15,
            'E' => 18,
            'F' => 15,
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $sheet = $event->sheet->getDelegate();
                $totalDataRows = count($this->reportData);
                $headerRow = $this->headerRowNumber();
                $firstDataRow = $this->firstDataRowNumber();
                $lastDataRow = $this->lastDataRowNumber();

                $drawing = new Drawing();
                $drawing->setName('Logo');
                $drawing->setDescription('Logo');
                $drawing->setPath(public_path('images/ksu-logo.png'));
                $drawing->setHeight(70);
                $drawing->setCoordinates('F1');
                $drawing->setWorksheet($sheet);

                $sheet->getStyle('A2:D4')->applyFromArray([
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '000000'],
                        ],
                    ],
                ]);

                $sheet->getStyle('A2:D2')->applyFromArray([
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                    ],
                ]);

                $sheet->getStyle("A{$headerRow}:F{$headerRow}")->applyFromArray([
                    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF']],
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                        'vertical' => Alignment::VERTICAL_CENTER,
                    ],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => '1F4E78'],
                    ],
                    'borders' => [
                        'allBorders' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'FFFFFF'],
                        ],
                    ],
                ]);

                $groupColors = ['E9F1FA', 'F5F5F5'];

                foreach ($this->groupRowRanges as $index => $range) {
                    $excelStart = $firstDataRow + $range['start'] - 1;
                    $excelEnd = $firstDataRow + $range['end'] - 1;
                    $groupColor = $groupColors[$index % 2];

                    if ($excelEnd > $excelStart) {
                        $sheet->mergeCells("A{$excelStart}:A{$excelEnd}");
                    }

                    $sheet->getStyle("A{$excelStart}:A{$excelEnd}")->applyFromArray([
                        'font' => ['bold' => true, 'color' => ['rgb' => '1F4E78']],
                        'alignment' => [
                            'vertical' => Alignment::VERTICAL_CENTER,
                            'horizontal' => Alignment::HORIZONTAL_LEFT,
                            'wrapText' => true,
                        ],
                        'fill' => [
                            'fillType' => Fill::FILL_SOLID,
                            'color' => ['rgb' => 'DDEBF7'],
                        ],
                    ]);

                    $sheet->getStyle("A{$excelStart}:F{$excelEnd}")->applyFromArray([
                        'fill' => [
                            'fillType' => Fill::FILL_SOLID,
                            'color' => ['rgb' => $groupColor],
                        ],
                        'borders' => [
                            'outline' => [
                                'borderStyle' => Border::BORDER_MEDIUM,
                                'color' => ['rgb' => '1F4E78'],
                            ],
                        ],
                    ]);
                }

                $summaryRow = $lastDataRow + 2;
                $sheet->setCellValue('A' . $summaryRow, $this->trans('summary'));
                $sheet->mergeCells('A' . $summaryRow . ':F' . $summaryRow);
                $sheet->getStyle('A' . $summaryRow . ':F' . $summaryRow)->applyFromArray([
                    'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => '1F4E78']],
                    'fill' => [
                        'fillType' => Fill::FILL_SOLID,
                        'color' => ['rgb' => 'DDEBF7'],
                    ],
                    'alignment' => [
                        'horizontal' => Alignment::HORIZONTAL_CENTER,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_MEDIUM,
                            'color' => ['rgb' => '1F4E78'],
                        ],
                    ],
                ]);

                $completedCount = count(array_filter($this->reportData, fn ($item) => $item['status_key'] === 'completed'));
                $partialCount = count(array_filter($this->reportData, fn ($item) => $item['status_key'] === 'partial'));
                $notSignedCount = count(array_filter($this->reportData, fn ($item) => $item['status_key'] === 'not_signed'));

                $sheet->setCellValue('A' . ($summaryRow + 1), $this->trans('completed') . ':');
                $sheet->setCellValue('B' . ($summaryRow + 1), $completedCount);
                $sheet->getStyle('A' . ($summaryRow + 1) . ':B' . ($summaryRow + 1))->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'E2EFDA']],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'A9D08E'],
                        ],
                    ],
                ]);
                $sheet->getStyle('B' . ($summaryRow + 1))->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    'font' => ['bold' => true, 'size' => 12],
                ]);

                $sheet->setCellValue('D' . ($summaryRow + 1), $this->trans('partial') . ':');
                $sheet->setCellValue('E' . ($summaryRow + 1), $partialCount);
                $sheet->getStyle('D' . ($summaryRow + 1) . ':E' . ($summaryRow + 1))->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FFF2CC']],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'FFD966'],
                        ],
                    ],
                ]);
                $sheet->getStyle('E' . ($summaryRow + 1))->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    'font' => ['bold' => true, 'size' => 12],
                ]);

                $sheet->setCellValue('A' . ($summaryRow + 2), $this->trans('not_signed') . ':');
                $sheet->setCellValue('B' . ($summaryRow + 2), $notSignedCount);
                $sheet->getStyle('A' . ($summaryRow + 2) . ':B' . ($summaryRow + 2))->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'FCE4D6']],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => 'FF7C80'],
                        ],
                    ],
                ]);
                $sheet->getStyle('B' . ($summaryRow + 2))->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    'font' => ['bold' => true, 'size' => 12],
                ]);

                $sheet->setCellValue('D' . ($summaryRow + 2), $this->trans('total_records') . ':');
                $sheet->setCellValue('E' . ($summaryRow + 2), $totalDataRows);
                $sheet->setCellValue('A' . ($summaryRow + 3), $this->trans('total_documents') . ':');
                $sheet->setCellValue('B' . ($summaryRow + 3), count($this->documentGroups));
                $sheet->getStyle('D' . ($summaryRow + 2) . ':E' . ($summaryRow + 2))->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'DDEBF7']],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '5B9BD5'],
                        ],
                    ],
                ]);
                $sheet->getStyle('E' . ($summaryRow + 2))->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    'font' => ['bold' => true, 'size' => 12],
                ]);
                $sheet->getStyle('A' . ($summaryRow + 3) . ':B' . ($summaryRow + 3))->applyFromArray([
                    'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'DDEBF7']],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => Border::BORDER_THIN,
                            'color' => ['rgb' => '5B9BD5'],
                        ],
                    ],
                ]);
                $sheet->getStyle('B' . ($summaryRow + 3))->applyFromArray([
                    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    'font' => ['bold' => true, 'size' => 12],
                ]);

                if ($totalDataRows > 0) {
                    $completionRate = round(($completedCount / $totalDataRows) * 100, 2);
                    $sheet->setCellValue('D' . ($summaryRow + 4), $this->trans('completion_rate') . ':');
                    $sheet->setCellValue('E' . ($summaryRow + 4), $completionRate . '%');
                    $sheet->getStyle('D' . ($summaryRow + 4) . ':E' . ($summaryRow + 4))->applyFromArray([
                        'fill' => ['fillType' => Fill::FILL_SOLID, 'color' => ['rgb' => 'E2EFDA']],
                        'borders' => [
                            'outline' => [
                                'borderStyle' => Border::BORDER_MEDIUM,
                                'color' => ['rgb' => '70AD47'],
                            ],
                        ],
                        'font' => ['bold' => true],
                    ]);
                    $sheet->getStyle('E' . ($summaryRow + 4))->applyFromArray([
                        'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
                    ]);
                }

                $sheet->freezePane('A' . $firstDataRow);
            },
        ];
    }
}
