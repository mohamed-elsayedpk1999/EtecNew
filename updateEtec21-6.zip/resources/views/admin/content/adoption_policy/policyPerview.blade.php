@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.AdoptionPolicy'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <style>
        body {
            direction: rtl;
            font-family: 'Segoe UI', Tahoma, Arial, sans-serif;
            background-color: #f0f2f5;
        }

        /* ── Logo bar ── */
        .policy-logo-bar {
            display: flex;
            justify-content: flex-end;
            /* physical right always */
            align-items: center;
            gap: 12px;
            padding-block-end: 20px;
            border-block-end: 1px solid #dde3ea;
            margin-block-end: 20px;
            direction: ltr;
            /* locks flex so flex-end = right in both LTR & RTL */
        }

        .policy-logo-bar img {
            height: 80px;
            width: 200px;
            margin-left: auto;
            /* physical left margin pushes img to physical right */
        }

        .policy-logo-bar .logo-text {
            text-align: right;
            line-height: 1.35;
        }

        .policy-logo-bar .logo-text .logo-title {
            font-size: .95rem;
            font-weight: 700;
            color: #1a3a5c;
        }

        .policy-logo-bar .logo-text .logo-subtitle {
            font-size: .72rem;
            color: #6b7a8d;
            letter-spacing: .03em;
            margin-top: 2px;
        }

        .policy-page-wrapper {
            max-width: 900px;
            margin: 0 auto 48px;
            padding: 24px 16px 0;
        }

        /* ── Breadcrumb ── */
        .policy-breadcrumb {
            display: flex;
            align-items: center;
            gap: 6px;
            justify-content: flex-end;
            margin-block-end: 16px;
            font-size: .8rem;
            color: #8a96a3;
        }

        .policy-breadcrumb a {
            color: #1a6eb5;
            text-decoration: none;
        }

        /* ── Page title with blue underline ── */
        .policy-page-title {
            text-align: right;
            margin-block-end: 20px;
            padding-block-end: 12px;
            border-block-end: 2px solid #1a6eb5;
        }

        .policy-page-title a {
            color: #1a3a5c;
            font-size: 1.18rem;
            font-weight: 700;
            text-decoration: none;
        }

        .policy-page-title a:hover {
            color: #1a6eb5;
        }

        /* ── White cards (shared) ── */
        .policy-card {
            background: #fff;
            border: 1px solid #dde3ea;
            border-radius: 8px;
            padding: 22px 26px;
            margin-block-end: 14px;
            text-align: right;
            color: #2d3a48;
        }

        /* Card 1 – reference header with left accent bar (RTL = inline-start) */
        .policy-card-header {
            border-inline-start: 4px solid #1a6eb5;
            padding-inline-start: 20px;
        }

        .policy-card-header .ref-label {
            font-size: .72rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .08em;
            color: #1a6eb5;
            margin-block-end: 6px;
        }

        .policy-card-header .ref-value {
            font-size: 1rem;
            font-weight: 700;
            color: #1a3a5c;
        }

        /* Card 2 – rules */
        .policy-card-list {
            font-size: .93rem;
            line-height: 1.9;
            color: #3a3a3a;
        }

        /* Card 3 – checkboxes */
        .policy-card-checks {}

        .policy-card-checks .section-label {
            display: block;
            font-weight: 700;
            font-size: .95rem;
            color: #1a3a5c;
            margin-block-end: 16px;
            padding-block-end: 10px;
            border-block-end: 1px solid #e8ecf1;
        }

        /* ── Checkbox rows ── */
        .policy-check-item {
            display: flex;
            flex-direction: row;
            align-items: flex-start;
            gap: 14px;
            border: 1px solid #c8daf0;
            border-radius: 8px;
            padding: 14px 16px;
            margin-block-end: 10px;
            background: #fafcff;
            cursor: pointer;
            transition: border-color .18s, background .18s;
        }

        .policy-check-item:hover {
            border-color: #1a6eb5;
            background: #f0f7ff;
        }

        .policy-check-item label {
            flex: 1;
            text-align: right;
            font-size: .91rem;
            color: #2d3a48;
            line-height: 1.75;
            cursor: pointer;
            margin: 0;
        }

        /* Custom checkbox — sits at inline-start (visually left in RTL) */
        .policy-check-item input[type="checkbox"] {
            width: 19px;
            height: 19px;
            margin-top: 3px;
            flex-shrink: 0;
            accent-color: #1a6eb5;
            cursor: pointer;
            order: 1;
        }

        /* ── Back-to-top nav card ── */
        .policy-nav-card {
            background: #fff;
            border: 1px solid #dde3ea;
            border-radius: 8px;
            padding: 10px 18px;
            margin-block-end: 14px;
            text-align: right;
        }

        .policy-nav-card a {
            color: #6b7a8d;
            font-size: .84rem;
            text-decoration: underline;
            text-decoration-color: #c8d4e0;
        }

        /* ── Actions ── */
        .policy-actions {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 12px;
            direction: rtl;
            margin-top: 8px;
        }

        .btn-policy-submit {
            background-color: #1a6eb5;
            color: #fff;
            border: none;
            border-radius: 7px;
            padding: 11px 48px;
            font-size: .97rem;
            font-weight: 700;
            cursor: pointer;
            letter-spacing: .01em;
            transition: background .16s, transform .1s;
        }

        .btn-policy-submit:hover {
            background-color: #155a96;
        }

        .btn-policy-submit:active {
            transform: scale(.98);
        }

        .btn-policy-prev {
            background: transparent;
            color: #6b7a8d;
            border: 1px solid #c8d4e0;
            border-radius: 7px;
            padding: 11px 28px;
            font-size: .95rem;
            cursor: pointer;
            transition: background .16s, color .16s;
        }

        .btn-policy-prev:hover {
            background: #f0f2f5;
            color: #2d3a48;
        }

        /* ── Cookie notice (LTR intentionally) ── */
        .policy-footer-note {
            text-align: left;
            font-size: .75rem;
            color: #aab4bf;
            margin-top: 22px;
            direction: ltr;
        }
    </style>
@endsection

@section('content')

    <div class="policy-page-wrapper">

        {{-- ── Logo bar (always right, language-independent) ── --}}
        <div class="policy-logo-bar">
            <div class="logo-text">

            </div>
            <img src="{{ asset('images/ksu-logo.png') }}" alt="Logo">
        </div>

        {{-- ── Blue page title ── --}}
        <div class="policy-page-title">
            <a href="#">{{ $policy->name ?? 'إقرار بالاطلاع على سياسات الأمن السيبراني والالتزام بها' }}</a>
        </div>

        {{-- ── Card 1 : reference header (uses policy reference / description) ── --}}
        <div class="policy-card policy-card-header">
            {{ __('policy_adoptions.cybersecurity_policy_reference', ['name' => $document->document_name]) }}
        </div>

        {{-- ── Card 2 : policy rules pulled from the document ── --}}
        <div class="policy-card policy-card-list">
            {!! $policy->description !!}
        </div>

        {{-- ── Card 3 : acknowledgment checkboxes ── --}}
        <div class="policy-card policy-card-checks">
            <span class="section-label">
                {{ __('policy_adoptions.statement_intro') }}
            </span>
            {{-- Checkbox 1 --}}
            @if (!empty($policy->introduction_content))
                <div class="policy-check-item">
                    <label for="check_policy">
                        {!! $policy->introduction_content !!}
                    </label>
                    <input type="checkbox" id="action1" name="action1" @if (!is_null(optional($actions)->action1)) disabled @endif
                        @if (optional($actions)->action1) checked @endif>
                </div>
            @endif

            {{-- Checkbox 2 --}}
            @if (!empty($policy->introduction_content2))
                <div class="policy-check-item">
                    <label for="check_apps">
                        {!! $policy->introduction_content2 !!}
                    </label>
                    <input type="checkbox" id="action2" name="action2" @if (!is_null(optional($actions)->action2)) disabled @endif
                        @if (optional($actions)->action2) checked @endif>
                </div>
            @endif
        </div>

        @if (empty($actions) || !$actions->action1 || !$actions->action2)
            <div class="policy-actions">
                <button type="button" class="btn-policy-submit" onclick="submitPolicy()">
                    {{ __('policy_adoptions.Send') }}
                </button>

                <button type="button" class="btn-policy-prev" onclick="window.history.back()">
                    {{ __('policy_adoptions.Back') }}
                </button>
            </div>
        @endif

        {{-- ── Cookie notice ── --}}
        <div class="policy-footer-note">
            {{ __('policy_adoptions.cookie_notice') }}
        </div>

    </div>

@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script>
        const signatureId = {{ $policy->signature->id }};
        const documentId = {{ $document->id }};

        function submitPolicy() {

            const action1 = document.getElementById('action1')?.checked ? 1 : 0;
            const action2 = document.getElementById('action2')?.checked ? 1 : 0;

            Swal.fire({
                title: "{{ __('locale.AreYouSureToDoThisAction') }}",
                text: '@lang('locale.YouWontBeAbleToRevertThis')',
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: "{{ __('locale.ConfirmAction') }}",
                cancelButtonText: "{{ __('locale.Cancel') }}",
                customClass: {
                    confirmButton: 'btn btn-relief-success ms-1',
                    cancelButton: 'btn btn-outline-danger ms-1'
                },
                buttonsStyling: false
            }).then((result) => {

                if (!result.isConfirmed) return;

                $.ajax({
                    url: "{{ route('admin.adoption_policies.updateStatus') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        signature_id: signatureId,
                        document_id: documentId,
                        action1: action1,
                        action2: action2
                    },
                    success: function(response) {
                        if (response.success) {
                            toastr.success(response.message || 'تم الإرسال بنجاح');
                            if (response.reload) {
                                location.reload();
                            }
                        } else {
                            toastr.error(response.message || 'حدث خطأ');
                        }
                    },
                    error: function(xhr) {
                        toastr.error(xhr.responseJSON?.message || 'Request failed');
                    }
                });
            });
        }
    </script>
@endsection
