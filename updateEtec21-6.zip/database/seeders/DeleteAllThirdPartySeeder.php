<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DeleteAllThirdPartySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        /*
        |--------------------------------------------------------------------------
        | Files
        |--------------------------------------------------------------------------
        */
        Storage::deleteDirectory('third_questionnaire_results');

        /*
        |--------------------------------------------------------------------------
        | Questionnaire Results
        |--------------------------------------------------------------------------
        */
        DB::table('third_party_contact_questionnaire_answer_result')->truncate();
        DB::table('third_party_contact_questionnaire_answer')->truncate();
        DB::table('third_party_contact_questionnaire')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Questionnaire
        |--------------------------------------------------------------------------
        */
        DB::table('third_party_questionnaire_risk')->truncate();
        DB::table('third_party_questionnaire_question')->truncate();

        // Uncomment if exists
        // DB::table('third_party_questionnaires')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Profile Relations
        |--------------------------------------------------------------------------
        */
        DB::table('third_party_profile_contact')->truncate();
        DB::table('third_party_profile_entity')->truncate();
        DB::table('third_party_profile_subsidiary')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Requests
        |--------------------------------------------------------------------------
        */
        DB::table('evaluation_request')->truncate();
        DB::table('third_party_requests')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Profiles
        |--------------------------------------------------------------------------
        */
        DB::table('third_party_profiles')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}