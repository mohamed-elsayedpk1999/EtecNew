<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestPoliciesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        /*
        |--------------------------------------------------------------------------
        | Audit Relations
        |--------------------------------------------------------------------------
        */

        DB::table('audit_document_policy_policy_document')->truncate();
        DB::table('audit_document_policy_statuses')->truncate();
        DB::table('audit_document_policy_comments')->truncate();
        DB::table('audit_document_policy_files')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Document Policies
        |--------------------------------------------------------------------------
        */

        DB::table('document_policies')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Center Policies
        |--------------------------------------------------------------------------
        */

        DB::table('center_policies')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}