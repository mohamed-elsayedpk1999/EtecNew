<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DeleteTestTasksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // Delete all task files from storage
        Storage::deleteDirectory('task');

        // Delete related files records
        DB::table('file_tasks')->truncate();

        // Delete all tasks
        DB::table('tasks')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}