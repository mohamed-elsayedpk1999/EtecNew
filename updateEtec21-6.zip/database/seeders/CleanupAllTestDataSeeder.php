<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class CleanupAllTestDataSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            DeleteAllChangeRequestsSeeder::class,
            DeleteAllThirdPartySeeder::class,
            DeleteAllKpisSeeder::class,
            DeleteTestTasksSeeder::class,
            DeleteTestRisksSeeder::class,
            DeleteTestPoliciesSeeder::class,
            DeleteTestNdasSeeder::class,
            DeleteTestExceptionsSeeder::class,
            DeleteTestMappedControlsCompliancesSeeder::class,
            DeleteTestAwarenessSurveysSeeder::class,
        ]);
    }
}