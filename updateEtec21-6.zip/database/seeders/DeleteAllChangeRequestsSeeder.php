<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DeleteAllChangeRequestsSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // Delete uploaded files
        Storage::deleteDirectory('change_request');

        // Delete records
        DB::table('change_requests')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}