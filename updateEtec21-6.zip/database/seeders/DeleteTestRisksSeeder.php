<?php

namespace Database\Seeders;

use App\Models\Risk;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DeleteTestRisksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        /*
        |--------------------------------------------------------------------------
        | Delete Files Directories
        |--------------------------------------------------------------------------
        */
        Storage::deleteDirectory('risk');
        Storage::deleteDirectory('risk_mitigation');

        /*
        |--------------------------------------------------------------------------
        | Files
        |--------------------------------------------------------------------------
        */
        DB::table('files')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Management Reviews
        |--------------------------------------------------------------------------
        */
        DB::table('mgmt_reviews')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Residual Risk Scoring History
        |--------------------------------------------------------------------------
        */
        DB::table('residual_risk_scoring_histories')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Risk Scoring
        |--------------------------------------------------------------------------
        */
        DB::table('risk_scorings')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Risk Relations
        |--------------------------------------------------------------------------
        */
        DB::table('risk_to_locations')->truncate();
        DB::table('risk_to_teams')->truncate();
        DB::table('risk_to_technologies')->truncate();
        DB::table('risk_to_additional_stakeholders')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Tags
        |--------------------------------------------------------------------------
        */
        DB::table('taggables')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Mitigation Relations
        |--------------------------------------------------------------------------
        */
        DB::table('mitigation_to_controls')->truncate();
        DB::table('mitigation_to_teams')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Mitigations
        |--------------------------------------------------------------------------
        */
        DB::table('mitigations')->truncate();

        /*
        |--------------------------------------------------------------------------
        | Risks
        |--------------------------------------------------------------------------
        */
        DB::table('risks')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}