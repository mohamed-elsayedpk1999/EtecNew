<?php

namespace Database\Seeders;

use App\Models\Exception;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestExceptionsSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        DB::table('exception_policy')->truncate();
        DB::table('control_exception')->truncate();
        DB::table('exception_risk')->truncate();
        DB::table('exceptions')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}