<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestAwarenessSurveysSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        DB::table('answer_question_surveys')->truncate();
        DB::table('survey_question_answers')->truncate();
        DB::table('survey_responses')->truncate();
        DB::table('survey_questions')->truncate();
        DB::table('awareness_surveys')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}