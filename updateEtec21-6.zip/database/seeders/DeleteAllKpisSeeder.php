<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteAllKpisSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // Delete child table first
        DB::table('kpi_assessments')->truncate();

        // Delete parent table
        DB::table('kpis')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}