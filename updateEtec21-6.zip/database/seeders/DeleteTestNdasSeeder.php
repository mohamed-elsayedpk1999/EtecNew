<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestNdasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        DB::table('nda_results')->truncate();
        DB::table('nda_receivers')->truncate();
        DB::table('ndas')->truncate();

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}