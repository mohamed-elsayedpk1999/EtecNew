<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('policy_adoption_configs', function (Blueprint $table) {

            // Drop columns you don't want (replace with your real column names)
            $table->dropColumn([
                'reviewer_id',
                'owner_id',
                'authorized_person_id',
            ]);
            // Ensure rapporteurs exists (if not already)
            if (!Schema::hasColumn('policy_adoption_configs', 'rapporteurs')) {
                $table->text('rapporteurs')->nullable();
            }
        });
    }

    public function down(): void
    {
        Schema::table('policy_adoption_configs', function (Blueprint $table) {

            // Recreate dropped columns (optional, only if you need rollback)
            $table->string('reviewer_id')->nullable();
            $table->string('owner_id')->nullable();
            $table->string('authorized_person_id')->nullable();

            $table->dropColumn('rapporteurs');
        });
    }
};