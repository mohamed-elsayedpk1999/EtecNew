<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('policy_signatures', function (Blueprint $table) {
            // drop old columns
            $table->dropColumn([
                'reviewer_id',
                'authorized_person_id',
                'owner_id',
            ]);

            // add new column
            $table->text('rapporteurs')->nullable();
            $table->longtext('introduction_content2')->nullable();
            $table->longtext('description')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('policy_signatures', function (Blueprint $table) {
            // restore old columns
            $table->unsignedBigInteger('reviewer_id')->nullable();
            $table->unsignedBigInteger('authorized_person_id')->nullable();
            $table->unsignedBigInteger('owner_id')->nullable();

            // remove new column
            $table->dropColumn('rapporteurs');
            $table->dropColumn('introduction_content2');
            $table->dropColumn('description');
        });
    }
};
