<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class QualysKnowledgeBase extends Model
{
    protected $table = 'qualys_knowledge_base';

    protected $primaryKey = 'qid';

    public $incrementing = false;

    protected $guarded = [];

    protected $casts = [
        'patchable' => 'boolean',
        'published_at' => 'datetime',
        'modified_at' => 'datetime',
    ];
}
