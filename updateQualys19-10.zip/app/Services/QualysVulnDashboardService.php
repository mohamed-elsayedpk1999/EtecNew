<?php

namespace App\Services;

use Carbon\Carbon;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class QualysVulnDashboardService
{
    public const SCOPES = ['open', 'fixed', 'all'];

    /**
     * Unique vulnerabilities (distinct QIDs), like the Qualys "Unique Vulnerability Count".
     *
     * @return array<string, mixed>
     */
    public function unique(Request $request): array
    {
        $scope = in_array($request->input('scope'), self::SCOPES, true) ? $request->input('scope') : 'open';
        $unscoped = QualysVulnQuery::filtered($request);
        $base = clone $unscoped;
        $this->applyScope($base, $scope);

        $total = (clone $base)->distinct()->count('v.qualys_qid');

        $bySeverity = (clone $base)
            ->selectRaw('v.qualys_severity as sev, COUNT(DISTINCT v.qualys_qid) as c')
            ->groupBy('v.qualys_severity')
            ->pluck('c', 'sev')
            ->all();

        $byType = (clone $base)
            ->selectRaw('v.qualys_type as t, COUNT(DISTINCT v.qualys_qid) as c')
            ->whereNotNull('v.qualys_type')
            ->groupBy('v.qualys_type')
            ->pluck('c', 't')
            ->all();

        $byPatchable = (clone $base)
            ->selectRaw('v.qualys_patchable as p, COUNT(DISTINCT v.qualys_qid) as c')
            ->groupBy('v.qualys_patchable')
            ->get();
        $patchable = ['yes' => 0, 'no' => 0, 'unknown' => 0];
        foreach ($byPatchable as $row) {
            $key = $row->p === null ? 'unknown' : ((int) $row->p === 1 ? 'yes' : 'no');
            $patchable[$key] += (int) $row->c;
        }

        $byStatus = [];
        foreach (QualysVulnQuery::ALL_STATUSES as $status) {
            $byStatus[$status] = (clone $unscoped)->where('v.qualys_status', $status)->distinct()->count('v.qualys_qid');
        }

        $byCategory = (clone $base)
            ->selectRaw("COALESCE(v.qualys_category, 'Uncategorized') as name, COUNT(DISTINCT v.qualys_qid) as c")
            ->groupBy('name')
            ->orderByDesc('c')
            ->limit(10)
            ->get();

        $topByAssets = (clone $base)
            ->leftJoin('asset_vulnerabilities as av', 'av.vulnerability_id', '=', 'v.id')
            ->selectRaw('v.qualys_qid as qid, MAX(v.name) as title, MAX(v.qualys_severity) as sev,
                MAX(v.qualys_category) as category, MAX(v.qds) as qds, MAX(v.qualys_patchable) as patchable,
                COUNT(DISTINCT av.asset_id) as assets, COUNT(*) as detections')
            ->groupBy('v.qualys_qid')
            ->orderByDesc('assets')
            ->limit(10)
            ->get();

        $topByQds = (clone $base)
            ->selectRaw('v.qualys_qid as qid, MAX(v.name) as title, MAX(v.qualys_severity) as sev, MAX(v.qds) as qds')
            ->whereNotNull('v.qds')
            ->groupBy('v.qualys_qid')
            ->orderByDesc('qds')
            ->limit(10)
            ->get();

        $pairs = (int) ((clone $base)
            ->leftJoin('asset_vulnerabilities as av', 'av.vulnerability_id', '=', 'v.id')
            ->selectRaw('COUNT(DISTINCT v.qualys_qid, av.asset_id) as c')
            ->value('c') ?? 0);

        $firstSeen = (clone $base)
            ->selectRaw('v.qualys_qid as qid, MIN(v.first_discovered) as first_seen')
            ->groupBy('v.qualys_qid')
            ->pluck('first_seen', 'qid')
            ->all();

        $ageBuckets = array_fill_keys(array_keys(QualysVulnQuery::AGE_BUCKETS), 0);
        $months = $this->lastMonths(12);
        $newPerMonth = array_fill_keys(array_keys($months), 0);
        $now = Carbon::now();
        foreach ($firstSeen as $date) {
            if (!$date) {
                continue;
            }
            $first = Carbon::parse($date);
            $ageBuckets[$this->ageBucket($first->diffInDays($now))]++;
            $key = $first->format('Y-m');
            if (isset($newPerMonth[$key])) {
                $newPerMonth[$key]++;
            }
        }

        return [
            'scope' => $scope,
            'cards' => [
                'total' => $total,
                'urgent' => (int) ($bySeverity[5] ?? 0),
                'critical' => (int) ($bySeverity[4] ?? 0),
                'patchable' => $patchable['yes'],
                'confirmed' => (int) ($byType['Confirmed'] ?? 0),
                'potential' => (int) ($byType['Potential'] ?? 0),
                'new' => $byStatus['New'],
                'avg_assets' => $total > 0 ? round($pairs / $total, 1) : 0,
            ],
            'bySeverity' => [5 => (int) ($bySeverity[5] ?? 0), 4 => (int) ($bySeverity[4] ?? 0)],
            'byType' => $byType,
            'patchable' => $patchable,
            'byStatus' => $byStatus,
            'byCategory' => $byCategory,
            'topByAssets' => $topByAssets,
            'topByQds' => $topByQds,
            'ageBuckets' => $ageBuckets,
            'months' => array_values($months),
            'newPerMonth' => array_values($newPerMonth),
        ];
    }

    /**
     * Detection (instance) level dashboard.
     *
     * @return array<string, mixed>
     */
    public function advanced(Request $request): array
    {
        $base = QualysVulnQuery::filtered($request);
        $open = (clone $base)->whereIn('v.qualys_status', QualysVulnQuery::OPEN_STATUSES);

        $total = (clone $base)->count();
        $byStatus = (clone $base)
            ->selectRaw('v.qualys_status as s, COUNT(*) as c')
            ->groupBy('v.qualys_status')
            ->pluck('c', 's')
            ->all();
        $openCount = 0;
        foreach (QualysVulnQuery::OPEN_STATUSES as $status) {
            $openCount += (int) ($byStatus[$status] ?? 0);
        }

        $affectedAssets = (int) ((clone $open)
            ->join('asset_vulnerabilities as av', 'av.vulnerability_id', '=', 'v.id')
            ->selectRaw('COUNT(DISTINCT av.asset_id) as c')
            ->value('c') ?? 0);

        $avgOpenAge = (clone $open)
            ->whereNotNull('v.first_discovered')
            ->selectRaw('AVG(DATEDIFF(NOW(), v.first_discovered)) as a')
            ->value('a');

        $mttr = (clone $base)
            ->where('v.qualys_status', 'Fixed')
            ->whereNotNull('v.last_fixed')
            ->whereNotNull('v.first_discovered')
            ->selectRaw('AVG(DATEDIFF(v.last_fixed, v.first_discovered)) as a')
            ->value('a');

        $reopened = (clone $base)->where('v.times_reopened', '>', 0)->count();

        $matrixRows = (clone $base)
            ->selectRaw('v.qualys_severity as sev, v.qualys_status as s, COUNT(*) as c')
            ->groupBy('v.qualys_severity', 'v.qualys_status')
            ->get();
        $matrix = [5 => [], 4 => []];
        foreach ([5, 4] as $sev) {
            foreach (QualysVulnQuery::ALL_STATUSES as $status) {
                $matrix[$sev][$status] = 0;
            }
        }
        foreach ($matrixRows as $row) {
            if (isset($matrix[(int) $row->sev][$row->s])) {
                $matrix[(int) $row->sev][$row->s] = (int) $row->c;
            }
        }

        $months = $this->lastMonths(12);
        $start = Carbon::now()->subMonths(11)->startOfMonth()->format('Y-m-d H:i:s');
        $found = (clone $base)
            ->where('v.first_discovered', '>=', $start)
            ->selectRaw("DATE_FORMAT(v.first_discovered, '%Y-%m') as m, COUNT(*) as c")
            ->groupBy('m')
            ->pluck('c', 'm')
            ->all();
        $fixed = (clone $base)
            ->where('v.last_fixed', '>=', $start)
            ->selectRaw("DATE_FORMAT(v.last_fixed, '%Y-%m') as m, COUNT(*) as c")
            ->groupBy('m')
            ->pluck('c', 'm')
            ->all();
        $trendFound = [];
        $trendFixed = [];
        foreach (array_keys($months) as $key) {
            $trendFound[] = (int) ($found[$key] ?? 0);
            $trendFixed[] = (int) ($fixed[$key] ?? 0);
        }

        $ageCase = $this->ageCaseSql();
        $ageRows = (clone $open)
            ->whereNotNull('v.first_discovered')
            ->selectRaw("$ageCase as bucket, v.qualys_severity as sev, COUNT(*) as c")
            ->groupBy('bucket', 'v.qualys_severity')
            ->get();
        $ageBySeverity = [5 => [], 4 => []];
        foreach ([5, 4] as $sev) {
            $ageBySeverity[$sev] = array_fill_keys(array_keys(QualysVulnQuery::AGE_BUCKETS), 0);
        }
        foreach ($ageRows as $row) {
            if (isset($ageBySeverity[(int) $row->sev][$row->bucket])) {
                $ageBySeverity[(int) $row->sev][$row->bucket] = (int) $row->c;
            }
        }

        $topAssets = (clone $open)
            ->join('asset_vulnerabilities as av', 'av.vulnerability_id', '=', 'v.id')
            ->join('assets as a', 'a.id', '=', 'av.asset_id')
            ->selectRaw('a.id, a.name, a.ip,
                SUM(CASE WHEN v.qualys_severity = 5 THEN 1 ELSE 0 END) as sev5,
                SUM(CASE WHEN v.qualys_severity = 4 THEN 1 ELSE 0 END) as sev4,
                COUNT(*) as total')
            ->groupBy('a.id', 'a.name', 'a.ip')
            ->orderByDesc('total')
            ->limit(10)
            ->get();

        $topCategories = (clone $open)
            ->selectRaw("COALESCE(v.qualys_category, 'Uncategorized') as name, COUNT(*) as c")
            ->groupBy('name')
            ->orderByDesc('c')
            ->limit(10)
            ->get();

        $qdsBands = (clone $open)
            ->selectRaw("CASE
                WHEN v.qds IS NULL THEN 'N/A'
                WHEN v.qds >= 90 THEN 'Critical (90-100)'
                WHEN v.qds >= 70 THEN 'High (70-89)'
                WHEN v.qds >= 40 THEN 'Medium (40-69)'
                ELSE 'Low (1-39)' END as band, COUNT(*) as c")
            ->groupBy('band')
            ->pluck('c', 'band')
            ->all();
        $qdsOrdered = [];
        foreach (['Critical (90-100)', 'High (70-89)', 'Medium (40-69)', 'Low (1-39)', 'N/A'] as $band) {
            $qdsOrdered[$band] = (int) ($qdsBands[$band] ?? 0);
        }

        $byType = (clone $open)
            ->selectRaw("COALESCE(v.qualys_type, 'Unknown') as t, COUNT(*) as c")
            ->groupBy('t')
            ->pluck('c', 't')
            ->all();

        $topPorts = (clone $open)
            ->whereNotNull('v.port')
            ->selectRaw("CONCAT(v.port, '/', COALESCE(v.protocol, '')) as name, COUNT(*) as c")
            ->groupBy('name')
            ->orderByDesc('c')
            ->limit(10)
            ->get();

        $patchRows = (clone $open)
            ->selectRaw('v.qualys_patchable as p, COUNT(*) as c')
            ->groupBy('v.qualys_patchable')
            ->get();
        $patchable = ['yes' => 0, 'no' => 0, 'unknown' => 0];
        foreach ($patchRows as $row) {
            $key = $row->p === null ? 'unknown' : ((int) $row->p === 1 ? 'yes' : 'no');
            $patchable[$key] += (int) $row->c;
        }

        $topOs = (clone $open)
            ->whereNotNull('v.qualys_os')
            ->selectRaw('v.qualys_os as name, COUNT(*) as c')
            ->groupBy('v.qualys_os')
            ->orderByDesc('c')
            ->limit(10)
            ->get();

        return [
            'cards' => [
                'total' => $total,
                'open' => $openCount,
                'new' => (int) ($byStatus['New'] ?? 0),
                'active' => (int) ($byStatus['Active'] ?? 0),
                'reopened' => (int) ($byStatus['Re-Opened'] ?? 0),
                'fixed' => (int) ($byStatus['Fixed'] ?? 0),
                'assets' => $affectedAssets,
                'avg_open_age' => $avgOpenAge !== null ? (int) round($avgOpenAge) : 0,
                'mttr' => $mttr !== null ? (int) round($mttr) : 0,
                'reopen_rate' => $total > 0 ? round($reopened / $total * 100, 1) : 0,
            ],
            'matrix' => $matrix,
            'months' => array_values($months),
            'trendFound' => $trendFound,
            'trendFixed' => $trendFixed,
            'ageBySeverity' => $ageBySeverity,
            'topAssets' => $topAssets,
            'topCategories' => $topCategories,
            'qdsBands' => $qdsOrdered,
            'byType' => $byType,
            'topPorts' => $topPorts,
            'patchable' => $patchable,
            'topOs' => $topOs,
        ];
    }

    protected function applyScope(Builder $query, string $scope): void
    {
        if ($scope === 'open') {
            $query->whereIn('v.qualys_status', QualysVulnQuery::OPEN_STATUSES);
        } elseif ($scope === 'fixed') {
            $query->where('v.qualys_status', 'Fixed');
        }
    }

    /**
     * @return array<string, string> 'Y-m' => 'M Y'
     */
    protected function lastMonths(int $count): array
    {
        $months = [];
        $cursor = Carbon::now()->subMonths($count - 1)->startOfMonth();
        for ($i = 0; $i < $count; $i++) {
            $months[$cursor->format('Y-m')] = $cursor->format('M Y');
            $cursor->addMonth();
        }

        return $months;
    }

    protected function ageBucket(int $days): string
    {
        foreach (QualysVulnQuery::AGE_BUCKETS as $label => [$min, $max]) {
            if ($days >= $min && ($max === null || $days <= $max)) {
                return $label;
            }
        }

        return '365+';
    }

    protected function ageCaseSql(): string
    {
        $parts = [];
        foreach (QualysVulnQuery::AGE_BUCKETS as $label => [$min, $max]) {
            $cond = 'DATEDIFF(NOW(), v.first_discovered) >= ' . (int) $min;
            if ($max !== null) {
                $cond .= ' AND DATEDIFF(NOW(), v.first_discovered) <= ' . (int) $max;
            }
            $parts[] = "WHEN $cond THEN '" . $label . "'";
        }

        return 'CASE ' . implode(' ', $parts) . " ELSE '365+' END";
    }
}
