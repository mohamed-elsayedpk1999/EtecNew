<?php

namespace App\Services;

use App\Jobs\SyncQualysJob;
use App\Models\QualysAuth;
use App\Models\QualysKnowledgeBase;
use App\Models\QualysSyncHistory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class QualysVulnPullService
{
    public const DEFAULT_QUALYS_BASE_URL = 'https://qualysapi.qg1.apps.qualysksa.com';

    public const FO_DETECTION_PATH = '/api/2.0/fo/asset/host/vm/detection/';

    public const FO_KNOWLEDGE_BASE_PATH = '/api/2.0/fo/knowledge_base/vuln/';

    public const FO_HOST_PATH = '/api/2.0/fo/asset/host/';

    /** Qualys severity 4 (Critical → GRC High) and 5 (Urgent → GRC Critical). */
    public const SEVERITIES = '4-5';

    public const STATUSES = 'New,Active,Re-Opened,Fixed';

    public const KB_CHUNK_SIZE = 100;

    protected $baseUrl;

    protected $username;

    protected $password;

    public function __construct()
    {
        $setting = QualysAuth::first();
        $this->username = $setting ? $setting->username : null;
        $this->password = $setting ? $setting->password : null;
        $apiUrl = $setting ? trim($setting->api_url ?? '') : '';
        $this->baseUrl = $apiUrl !== '' ? rtrim($apiUrl, '/') : self::DEFAULT_QUALYS_BASE_URL;
    }

    /**
     * Controller / artisan / schedule entry: pull all detections, then dispatch insert.
     *
     * @return array{ok: bool, skipped?: bool, history_id?: int, message?: string}
     */
    public function start(): array
    {
        ignore_user_abort(true);

        QualysSyncHistory::where('type', 'Vulnerability')
            ->where('status', 1)
            ->where('created_at', '<', now()->subMinutes(30))
            ->update([
                'status' => 2,
                'error' => 'Timed out / interrupted',
            ]);

        if (QualysSyncHistory::where('type', 'Vulnerability')->where('status', 1)->exists()) {
            return [
                'ok' => true,
                'skipped' => true,
                'message' => 'A Qualys vulnerability sync is already running. Please wait until it finishes.',
            ];
        }

        $history = QualysSyncHistory::create([
            'type' => 'Vulnerability',
            'processed' => 0,
            'total' => null,
            'imported' => 0,
            'failed' => 0,
            'status' => 1,
        ]);

        $historyId = $history->id;
        app()->terminating(function () use ($historyId) {
            ignore_user_abort(true);
            set_time_limit(0);
            $history = QualysSyncHistory::find($historyId);
            if (!$history) {
                return;
            }
            try {
                (new QualysVulnPullService())->collectAndDispatch($history);
            } catch (\Throwable $e) {
                $history->update([
                    'status' => 2,
                    'error' => mb_substr($e->getMessage(), 0, 1000),
                ]);
            }
        });

        return [
            'ok' => true,
            'skipped' => false,
            'history_id' => $history->id,
        ];
    }

    /**
     * Pull Qualys severity 4-5 detections 25 hosts at a time, then dispatch insert for each batch.
     */
    public function collectAndDispatch(QualysSyncHistory $history): void
    {
        $idMin = 1;
        $pageSize = 25;
        $maxPages = 50000;

        // Progress is measured in hosts: pages walk host IDs ascending via id_min,
        // so hosts with an ID below the next id_min are already done.
        $hostRanges = $this->fetchHostIdRanges();
        $totalHosts = $this->countIds($hostRanges);
        $history->update(['processed' => 0, 'total' => $totalHosts > 0 ? $totalHosts : null]);

        for ($page = 1; $page <= $maxPages; $page++) {
            $pageData = $this->fetchPage($idMin, $pageSize);

            $isLast = $pageData['done']
                || $pageData['next_id_min'] === null
                || $pageData['next_id_min'] <= $idMin;

            if ($pageData['rows'] !== []) {
                $knowledgeBase = $this->fetchMissingKnowledgeBase(array_column($pageData['rows'], 'qid'));
                dispatch_now(new SyncQualysJob($history->id, $pageData['rows'], false, $knowledgeBase));
            }

            if ($isLast) {
                $history->update([
                    'status' => 0,
                    'processed' => $totalHosts,
                    'total' => $totalHosts > 0 ? $totalHosts : null,
                ]);
                break;
            }

            $idMin = $pageData['next_id_min'];
            if ($totalHosts > 0) {
                $history->update(['processed' => min($totalHosts, $this->countIds($hostRanges, $idMin))]);
            }
        }
    }

    /**
     * All host IDs in the subscription as sorted [start, end] ranges (empty on failure).
     *
     * @return array<int, array{0:int,1:int}>
     */
    protected function fetchHostIdRanges(): array
    {
        try {
            $response = $this->qualysApi()->get($this->url(self::FO_HOST_PATH), [
                'action' => 'list',
                'details' => 'None',
                'truncation_limit' => 0,
            ]);
        } catch (\Throwable $e) {
            Log::warning('Qualys host ID list request failed', ['error' => $e->getMessage()]);

            return [];
        }

        $xml = $response->successful() ? @simplexml_load_string($response->body()) : false;
        if ($xml === false) {
            Log::warning('Qualys host ID list request failed', ['status' => $response->status()]);

            return [];
        }

        $ranges = [];
        if (isset($xml->RESPONSE->ID_SET)) {
            foreach ($xml->RESPONSE->ID_SET->children() as $node) {
                $value = trim((string) $node);
                if ($node->getName() === 'ID_RANGE' && preg_match('/^(\d+)\s*-\s*(\d+)$/', $value, $m)) {
                    $ranges[] = [(int) $m[1], (int) $m[2]];
                } elseif ($node->getName() === 'ID' && ctype_digit($value)) {
                    $ranges[] = [(int) $value, (int) $value];
                }
            }
        } elseif (isset($xml->RESPONSE->HOST_LIST)) {
            foreach ($this->xmlChildren($xml->RESPONSE->HOST_LIST, 'HOST') as $host) {
                $id = (int) ($host->ID ?? 0);
                if ($id > 0) {
                    $ranges[] = [$id, $id];
                }
            }
        }

        usort($ranges, function ($a, $b) {
            return $a[0] <=> $b[0];
        });

        return $ranges;
    }

    /**
     * Count IDs in the ranges, optionally only those below $below.
     *
     * @param array<int, array{0:int,1:int}> $ranges
     */
    protected function countIds(array $ranges, ?int $below = null): int
    {
        $count = 0;
        foreach ($ranges as [$start, $end]) {
            if ($below !== null) {
                if ($start >= $below) {
                    break;
                }
                $end = min($end, $below - 1);
            }
            $count += $end - $start + 1;
        }

        return $count;
    }

    /**
     * Fetch one Qualys detection page and map it to insert rows.
     *
     * @return array{rows: array<int, array<string, mixed>>, next_id_min: int|null, done: bool}
     */
    protected function fetchPage(int $idMin, int $pageSize = 25): array
    {
        $response = $this->qualysApi()->get($this->url(self::FO_DETECTION_PATH), [
            'action' => 'list',
            'truncation_limit' => $pageSize,
            'id_min' => $idMin,
            'severities' => self::SEVERITIES,
            'status' => self::STATUSES,
            'show_results' => 1,
            'show_qds' => 1,
            'show_qds_factors' => 1,
            'show_tags' => 1,
            'show_asset_id' => 1,
        ]);

        if (!$response->successful()) {
            throw new \RuntimeException('Qualys detection page failed: HTTP ' . $response->status());
        }

        $xml = @simplexml_load_string($response->body());
        if ($xml === false) {
            throw new \RuntimeException('Qualys detection page returned invalid XML');
        }

        $hostList = isset($xml->RESPONSE->HOST_LIST)
            ? $this->xmlChildren($xml->RESPONSE->HOST_LIST, 'HOST')
            : [];

        $maxHostId = 0;
        $rows = [];
        foreach ($hostList as $host) {
            $hostId = (int) ($host->ID ?? 0);
            if ($hostId > $maxHostId) {
                $maxHostId = $hostId;
            }

            $detections = isset($host->DETECTION_LIST)
                ? $this->xmlChildren($host->DETECTION_LIST, 'DETECTION')
                : [];

            foreach ($detections as $det) {
                $row = $this->mapHostDetectionToRow($host, $det);
                if ($row !== null) {
                    $rows[] = $row;
                }
            }
        }

        $nextIdMin = $this->nextIdMinFromWarning($xml);
        if ($nextIdMin === null && count($hostList) >= $pageSize && $maxHostId > 0) {
            $nextIdMin = $maxHostId + 1;
        }

        return [
            'rows' => $rows,
            'next_id_min' => $nextIdMin,
            'done' => $nextIdMin === null,
        ];
    }

    /**
     * Fetch KnowledgeBase entries for QIDs that are not stored yet.
     *
     * @param array<int, string> $qids
     * @return array<int, array<string, mixed>> keyed by QID
     */
    protected function fetchMissingKnowledgeBase(array $qids): array
    {
        $qids = array_values(array_unique(array_filter(array_map('intval', $qids))));
        if ($qids === []) {
            return [];
        }

        $known = QualysKnowledgeBase::whereIn('qid', $qids)->pluck('qid')->map('intval')->all();
        $missing = array_values(array_diff($qids, $known));
        if ($missing === []) {
            return [];
        }

        $entries = [];
        foreach (array_chunk($missing, self::KB_CHUNK_SIZE) as $chunk) {
            try {
                $response = $this->qualysApi()->get($this->url(self::FO_KNOWLEDGE_BASE_PATH), [
                    'action' => 'list',
                    'details' => 'All',
                    'ids' => implode(',', $chunk),
                ]);
            } catch (\Throwable $e) {
                Log::warning('Qualys KnowledgeBase request failed', ['error' => $e->getMessage()]);
                continue;
            }

            if (!$response->successful()) {
                Log::warning('Qualys KnowledgeBase request failed', ['status' => $response->status()]);
                continue;
            }

            $xml = @simplexml_load_string($response->body());
            if ($xml === false || !isset($xml->RESPONSE->VULN_LIST)) {
                continue;
            }

            foreach ($this->xmlChildren($xml->RESPONSE->VULN_LIST, 'VULN') as $vuln) {
                $entry = $this->mapKnowledgeBaseVuln($vuln);
                if ($entry !== null) {
                    $entries[$entry['qid']] = $entry;
                }
            }
        }

        return $entries;
    }

    /**
     * @return array<string, mixed>|null
     */
    protected function mapKnowledgeBaseVuln($vuln): ?array
    {
        $qid = (int) $this->xmlText($vuln, 'QID');
        if ($qid <= 0) {
            return null;
        }

        $cves = [];
        if (isset($vuln->CVE_LIST)) {
            foreach ($this->xmlChildren($vuln->CVE_LIST, 'CVE') as $cve) {
                $id = $this->xmlText($cve, 'ID');
                if ($id !== '') {
                    $cves[] = $id;
                }
            }
        }

        $patchable = $this->xmlText($vuln, 'PATCHABLE');

        return [
            'qid' => $qid,
            'title' => mb_substr($this->xmlText($vuln, 'TITLE'), 0, 500),
            'vuln_type' => mb_substr($this->xmlText($vuln, 'VULN_TYPE'), 0, 60),
            'severity_level' => (int) $this->xmlText($vuln, 'SEVERITY_LEVEL') ?: null,
            'category' => mb_substr($this->xmlText($vuln, 'CATEGORY'), 0, 255),
            'diagnosis' => $this->htmlToText($this->xmlText($vuln, 'DIAGNOSIS')),
            'consequence' => $this->htmlToText($this->xmlText($vuln, 'CONSEQUENCE')),
            'solution' => $this->htmlToText($this->xmlText($vuln, 'SOLUTION')),
            'cve_list' => implode(',', $cves),
            'cvss_base' => isset($vuln->CVSS) ? $this->xmlText($vuln->CVSS, 'BASE') : '',
            'cvss3_base' => isset($vuln->CVSS_V3) ? $this->xmlText($vuln->CVSS_V3, 'BASE') : '',
            'patchable' => $patchable === '' ? null : $patchable === '1',
            'published_at' => $this->xmlText($vuln, 'PUBLISHED_DATETIME'),
            'modified_at' => $this->xmlText($vuln, 'LAST_SERVICE_MODIFICATION_DATETIME'),
        ];
    }

    protected function htmlToText(string $html): string
    {
        if ($html === '') {
            return '';
        }
        $text = preg_replace('#<\s*(br|/p|/li|/div|/tr)\s*/?>#i', "\n", $html);
        $text = preg_replace('#<\s*li[^>]*>#i', '- ', $text);
        $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace("/[ \t]+/", ' ', $text);
        $text = preg_replace("/\n\s*\n+/", "\n\n", $text);

        return trim($text);
    }

    protected function qualysApi(): PendingRequest
    {
        return Http::withHeaders([
            'X-Requested-With' => 'Curl Sample',
        ])
            ->withBasicAuth($this->username, $this->password)
            ->timeout(120)
            ->retry(2, 2000);
    }

    protected function url(string $path): string
    {
        return $this->baseUrl . (isset($path[0]) && $path[0] === '/' ? $path : '/' . $path);
    }

    /**
     * @return array<string, mixed>|null
     */
    protected function mapHostDetectionToRow($host, $det): ?array
    {
        $qid = $this->xmlText($det, 'QID');
        if ($qid === '') {
            return null;
        }

        $qdsNode = $det->QDS ?? null;
        $qdsScore = $qdsNode !== null ? trim((string) $qdsNode) : '';
        $qdsSeverity = '';
        if ($qdsNode !== null && isset($qdsNode['severity'])) {
            $qdsSeverity = trim((string) $qdsNode['severity']);
        }

        return [
            'qid' => $qid,
            'unique_vuln_id' => $this->xmlText($det, 'UNIQUE_VULN_ID'),
            'type' => $this->xmlText($det, 'TYPE'),
            'severity' => $this->xmlText($det, 'SEVERITY'),
            'port' => $this->xmlText($det, 'PORT'),
            'protocol' => $this->xmlText($det, 'PROTOCOL'),
            'ssl' => $this->xmlText($det, 'SSL'),
            'fqdn' => $this->xmlText($det, 'FQDN'),
            'instance' => $this->xmlText($det, 'INSTANCE'),
            'results' => $this->xmlText($det, 'RESULTS'),
            'status' => $this->xmlText($det, 'STATUS'),
            'first_found_datetime' => $this->xmlText($det, 'FIRST_FOUND_DATETIME'),
            'last_found_datetime' => $this->xmlText($det, 'LAST_FOUND_DATETIME'),
            'source' => $this->xmlText($det, 'SOURCE'),
            'qds' => $qdsScore,
            'qds_severity' => $qdsSeverity,
            'qds_factors' => $this->xmlQdsFactors($det),
            'times_found' => $this->xmlText($det, 'TIMES_FOUND'),
            'last_test_datetime' => $this->xmlText($det, 'LAST_TEST_DATETIME'),
            'last_update_datetime' => $this->xmlText($det, 'LAST_UPDATE_DATETIME'),
            'last_fixed_datetime' => $this->xmlText($det, 'LAST_FIXED_DATETIME'),
            'first_reopened_datetime' => $this->xmlText($det, 'FIRST_REOPENED_DATETIME'),
            'last_reopened_datetime' => $this->xmlText($det, 'LAST_REOPENED_DATETIME'),
            'times_reopened' => $this->xmlText($det, 'TIMES_REOPENED'),
            'service' => $this->xmlText($det, 'SERVICE'),
            'is_ignored' => $this->xmlText($det, 'IS_IGNORED'),
            'is_disabled' => $this->xmlText($det, 'IS_DISABLED'),
            'affect_running_kernel' => $this->xmlText($det, 'AFFECT_RUNNING_KERNEL'),
            'affect_running_service' => $this->xmlText($det, 'AFFECT_RUNNING_SERVICE'),
            'affect_exploitable_config' => $this->xmlText($det, 'AFFECT_EXPLOITABLE_CONFIG'),
            'last_processed_datetime' => $this->xmlText($det, 'LAST_PROCESSED_DATETIME'),
            'asset_cve' => $this->xmlText($det, 'ASSET_CVE'),
            'host_id' => $this->xmlText($host, 'ID'),
            'asset_id' => $this->xmlText($host, 'ASSET_ID'),
            'ip' => $this->xmlText($host, 'IP'),
            'ipv6' => $this->xmlText($host, 'IPV6'),
            'tracking_method' => $this->xmlText($host, 'TRACKING_METHOD'),
            'os' => $this->xmlText($host, 'OS'),
            'os_cpe' => $this->xmlText($host, 'OS_CPE'),
            'dns' => $this->xmlText($host, 'DNS'),
            'netbios' => $this->xmlText($host, 'NETBIOS'),
            'hostname' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'HOSTNAME') : '',
            'domain' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'DOMAIN') : '',
            'host_fqdn' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'FQDN') : '',
            'tags' => $this->xmlHostTags($host),
        ];
    }

    protected function xmlText($node, string $name): string
    {
        if ($node === null || !isset($node->{$name})) {
            return '';
        }

        return html_entity_decode(trim((string) $node->{$name}), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /**
     * @return array<string, string>
     */
    protected function xmlQdsFactors($det): array
    {
        $factors = [];
        if (!isset($det->QDS_FACTORS->QDS_FACTOR)) {
            return $factors;
        }

        $list = $this->xmlChildren($det->QDS_FACTORS, 'QDS_FACTOR');
        foreach ($list as $factor) {
            $name = strtolower(trim((string) ($factor['name'] ?? '')));
            if ($name === '') {
                continue;
            }
            $value = trim((string) $factor);
            if ($value === '' || strcasecmp($value, 'null') === 0) {
                continue;
            }
            if (isset($factors[$name]) && $factors[$name] !== '') {
                $factors[$name] .= ',' . $value;
            } else {
                $factors[$name] = $value;
            }
        }

        return $factors;
    }

    protected function xmlHostTags($host): string
    {
        if (!isset($host->TAGS->TAG)) {
            return '';
        }

        $names = [];
        $list = $this->xmlChildren($host->TAGS, 'TAG');
        foreach ($list as $tag) {
            $name = trim((string) ($tag->NAME ?? ''));
            if ($name !== '') {
                $names[] = $name;
            }
        }

        return implode(', ', $names);
    }

    /**
     * @return array<int, \SimpleXMLElement>
     */
    protected function xmlChildren($parent, string $name): array
    {
        if ($parent === null || !isset($parent->{$name})) {
            return [];
        }

        $items = [];
        foreach ($parent->{$name} as $child) {
            $items[] = $child;
        }

        return $items;
    }

    protected function nextIdMinFromWarning($xml): ?int
    {
        $url = isset($xml->RESPONSE->WARNING->URL)
            ? trim((string) $xml->RESPONSE->WARNING->URL)
            : '';
        if ($url === '') {
            return null;
        }

        $query = parse_url(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'), PHP_URL_QUERY);
        if (!is_string($query) || $query === '') {
            return null;
        }

        parse_str($query, $params);
        if (!isset($params['id_min']) || !is_numeric($params['id_min'])) {
            return null;
        }

        return (int) $params['id_min'];
    }
}
