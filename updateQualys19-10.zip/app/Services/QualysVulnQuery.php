<?php

namespace App\Services;

use App\Models\Department;
use App\Models\User;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Shared base query for Qualys detections (vulnerabilities table, alias `v`),
 * with per-user visibility and the Qualys-style filters.
 */
class QualysVulnQuery
{
    public const SEVERITIES = [5, 4];

    public const OPEN_STATUSES = ['New', 'Active', 'Re-Opened'];

    public const ALL_STATUSES = ['New', 'Active', 'Re-Opened', 'Fixed'];

    public const TYPES = ['Confirmed', 'Potential'];

    public const AGE_BUCKETS = [
        '0-30' => [0, 30],
        '31-60' => [31, 60],
        '61-90' => [61, 90],
        '91-180' => [91, 180],
        '181-365' => [181, 365],
        '365+' => [366, null],
    ];

    public static function base(): Builder
    {
        $query = DB::table('vulnerabilities as v')
            ->where('v.family', 'Qualys')
            ->whereNotNull('v.qualys_qid')
            ->whereIn('v.qualys_severity', self::SEVERITIES);

        self::applyVisibility($query);

        return $query;
    }

    public static function filtered(Request $request): Builder
    {
        $query = self::base();
        self::applyFilters($query, $request);

        return $query;
    }

    public static function applyVisibility(Builder $query): void
    {
        $user = auth()->user();
        if (!$user || (int) $user->role_id === 1 || $user->hasPermission('vulnerability_management.all')) {
            return;
        }

        $userIds = [(int) $user->id];
        $department = Department::where('manager_id', $user->id)->first();
        if ($department) {
            $userIds = array_merge($userIds, User::where('department_id', $department->id)->pluck('id')->map('intval')->all());
        }
        $userIds = array_values(array_unique($userIds));
        $teamIds = DB::table('user_to_teams')->whereIn('user_id', $userIds)->pluck('team_id')->unique()->values()->all();

        $query->where(function (Builder $w) use ($userIds, $teamIds) {
            $w->whereIn('v.created_by', $userIds)
                ->orWhereExists(function (Builder $sub) use ($userIds) {
                    $sub->select(DB::raw(1))
                        ->from('asset_vulnerabilities as avv')
                        ->join('assets as aa', 'aa.id', '=', 'avv.asset_id')
                        ->whereColumn('avv.vulnerability_id', 'v.id')
                        ->whereIn('aa.asset_owner', $userIds);
                });
            if ($teamIds !== []) {
                $w->orWhereExists(function (Builder $sub) use ($teamIds) {
                    $sub->select(DB::raw(1))
                        ->from('team_vulnerabilities as tv')
                        ->whereColumn('tv.vulnerability_id', 'v.id')
                        ->whereIn('tv.team_id', $teamIds);
                });
            }
        });
    }

    public static function applyFilters(Builder $query, Request $request): void
    {
        $search = trim((string) $request->input('q', ''));
        if ($search !== '') {
            $like = '%' . str_replace(['%', '_'], ['\%', '\_'], $search) . '%';
            $query->where(function (Builder $w) use ($search, $like) {
                if (ctype_digit($search)) {
                    $w->orWhere('v.qualys_qid', (int) $search);
                }
                $w->orWhere('v.name', 'like', $like)
                    ->orWhere('v.cve', 'like', $like)
                    ->orWhere('v.ip_address', 'like', $like)
                    ->orWhere('v.dns_name', 'like', $like)
                    ->orWhere('v.qualys_category', 'like', $like)
                    ->orWhereExists(function (Builder $sub) use ($like) {
                        $sub->select(DB::raw(1))
                            ->from('asset_vulnerabilities as avs')
                            ->join('assets as as2', 'as2.id', '=', 'avs.asset_id')
                            ->whereColumn('avs.vulnerability_id', 'v.id')
                            ->where(function (Builder $a) use ($like) {
                                $a->where('as2.name', 'like', $like)->orWhere('as2.ip', 'like', $like);
                            });
                    });
            });
        }

        $qid = trim((string) $request->input('qid', ''));
        if ($qid !== '' && ctype_digit($qid)) {
            $query->where('v.qualys_qid', (int) $qid);
        }

        $assetId = (int) $request->input('asset_id', 0);
        if ($assetId > 0) {
            $query->whereExists(function (Builder $sub) use ($assetId) {
                $sub->select(DB::raw(1))
                    ->from('asset_vulnerabilities as ava')
                    ->whereColumn('ava.vulnerability_id', 'v.id')
                    ->where('ava.asset_id', $assetId);
            });
        }

        $severities = self::intList($request->input('severity'), self::SEVERITIES);
        if ($severities !== []) {
            $query->whereIn('v.qualys_severity', $severities);
        }

        $statuses = self::stringList($request->input('status'), self::ALL_STATUSES);
        if ($statuses !== []) {
            $query->whereIn('v.qualys_status', $statuses);
        }

        $types = self::stringList($request->input('type'), self::TYPES);
        if ($types !== []) {
            $query->whereIn('v.qualys_type', $types);
        }

        $category = trim((string) $request->input('category', ''));
        if ($category !== '') {
            $query->where('v.qualys_category', $category);
        }

        $patchable = (string) $request->input('patchable', '');
        if ($patchable === '1' || $patchable === '0') {
            $query->where('v.qualys_patchable', (int) $patchable);
        }

        $port = trim((string) $request->input('port', ''));
        if ($port !== '' && ctype_digit($port)) {
            $query->where('v.port', (int) $port);
        }

        $qdsMin = trim((string) $request->input('qds_min', ''));
        if ($qdsMin !== '' && is_numeric($qdsMin)) {
            $query->where('v.qds', '>=', (int) $qdsMin);
        }

        foreach (['first' => 'v.first_discovered', 'last' => 'v.last_observed'] as $prefix => $column) {
            $from = self::date($request->input($prefix . '_from'));
            $to = self::date($request->input($prefix . '_to'));
            if ($from) {
                $query->where($column, '>=', $from . ' 00:00:00');
            }
            if ($to) {
                $query->where($column, '<=', $to . ' 23:59:59');
            }
        }

        $age = (string) $request->input('age', '');
        if (isset(self::AGE_BUCKETS[$age])) {
            [$min, $max] = self::AGE_BUCKETS[$age];
            $query->whereRaw('DATEDIFF(NOW(), v.first_discovered) >= ?', [$min]);
            if ($max !== null) {
                $query->whereRaw('DATEDIFF(NOW(), v.first_discovered) <= ?', [$max]);
            }
        }
    }

    /**
     * @return array<int, int>
     */
    protected static function intList($value, array $allowed): array
    {
        $values = is_array($value) ? $value : ($value === null || $value === '' ? [] : explode(',', (string) $value));

        return array_values(array_intersect(array_map('intval', $values), $allowed));
    }

    /**
     * @return array<int, string>
     */
    protected static function stringList($value, array $allowed): array
    {
        $values = is_array($value) ? $value : ($value === null || $value === '' ? [] : explode(',', (string) $value));

        return array_values(array_intersect(array_map('trim', $values), $allowed));
    }

    protected static function date($value): ?string
    {
        $value = trim((string) $value);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) ? $value : null;
    }
}
