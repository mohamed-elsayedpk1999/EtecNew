<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddQualysFieldsToVulnerabilitiesTable extends Migration
{
    public function up()
    {
        Schema::table('vulnerabilities', function (Blueprint $table) {
            $table->unsignedBigInteger('qualys_qid')->nullable()->index();
            $table->unsignedTinyInteger('qualys_severity')->nullable()->index();
            $table->string('qualys_status', 20)->nullable()->index();
            $table->string('qualys_type', 40)->nullable()->index();
            $table->string('qualys_title', 500)->nullable();
            $table->string('qualys_category', 255)->nullable()->index();
            $table->unsignedSmallInteger('qds')->nullable()->index();
            $table->string('qds_severity', 20)->nullable();
            $table->unsignedInteger('times_found')->nullable();
            $table->timestamp('last_fixed')->nullable();
            $table->timestamp('last_tested')->nullable();
            $table->timestamp('last_reopened')->nullable();
            $table->unsignedInteger('times_reopened')->nullable();
            $table->boolean('qualys_patchable')->nullable()->index();
            $table->string('qualys_host_id', 40)->nullable()->index();
            $table->string('qualys_os', 255)->nullable();
        });

        Schema::create('qualys_knowledge_base', function (Blueprint $table) {
            $table->unsignedBigInteger('qid')->primary();
            $table->string('title', 500)->nullable();
            $table->string('vuln_type', 60)->nullable();
            $table->unsignedTinyInteger('severity_level')->nullable();
            $table->string('category', 255)->nullable();
            $table->longText('diagnosis')->nullable();
            $table->longText('consequence')->nullable();
            $table->longText('solution')->nullable();
            $table->text('cve_list')->nullable();
            $table->string('cvss_base', 20)->nullable();
            $table->string('cvss3_base', 20)->nullable();
            $table->boolean('patchable')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamp('modified_at')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('qualys_knowledge_base');

        Schema::table('vulnerabilities', function (Blueprint $table) {
            $table->dropColumn([
                'qualys_qid',
                'qualys_severity',
                'qualys_status',
                'qualys_type',
                'qualys_title',
                'qualys_category',
                'qds',
                'qds_severity',
                'times_found',
                'last_fixed',
                'last_tested',
                'last_reopened',
                'times_reopened',
                'qualys_patchable',
                'qualys_host_id',
                'qualys_os',
            ]);
        });
    }
}
