<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasColumn('policy_signature_actions', 'document_id')) {

            try {
                DB::statement("
                    ALTER TABLE policy_signature_actions
                    DROP FOREIGN KEY policy_signature_actions_document_id_foreign
                ");
            } catch (\Throwable $e) {
                // Foreign key does not exist
            }

            Schema::table('policy_signature_actions', function (Blueprint $table) {
                $table->dropColumn('document_id');
            });
        }

        Schema::table('policy_signature_actions', function (Blueprint $table) {

            if (!Schema::hasColumn('policy_signature_actions', 'category_id')) {

                $table->unsignedBigInteger('category_id')->after('id');

                $table->foreign('category_id')
                    ->references('id')
                    ->on('categories')
                    ->cascadeOnDelete();
            }
        });
    }

    public function down(): void
    {
        Schema::table('policy_signature_actions', function (Blueprint $table) {

            try {
                $table->dropForeign(['category_id']);
            } catch (\Throwable $e) {
            }

            if (Schema::hasColumn('policy_signature_actions', 'category_id')) {
                $table->dropColumn('category_id');
            }

            if (!Schema::hasColumn('policy_signature_actions', 'document_id')) {

                $table->unsignedBigInteger('document_id')->after('id');

                $table->foreign('document_id')
                    ->references('id')
                    ->on('documents')
                    ->cascadeOnDelete();
            }
        });
    }
};