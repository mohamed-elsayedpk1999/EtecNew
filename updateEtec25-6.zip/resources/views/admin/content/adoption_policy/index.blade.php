@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.AdoptionPolicy'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">

    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <script src="{{ asset('new_d/js/editor/ckeditor/ckeditor.js') }}"></script>
    <script src="{{ asset('new_d/js/editor/ckeditor/adapters/jquery.js') }}"></script>
    <script src="{{ asset('new_d/js/editor/ckeditor/styles.js') }}"></script>
    <script src="{{ asset('new_d/js/editor/ckeditor/ckeditor.custom.js') }}"></script>
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <style>

    </style>

@endsection
@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-sm-6 pe-0" style="text-align: end;">

                            <div class="action-content">
                                @if (auth()->user()->hasPermission('policy_adoptions.create'))
                                    <a href="{{ route('admin.adoption_policies.notificationsSettingsPolicyAdoption') }}"
                                        class="btn btn-primary">
                                        <i class="fa-regular fa-bell"></i>

                                    </a>
                                @endif
                                @if (auth()->user()->hasPermission('policy_adoptions.configuration'))
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal"
                                        data-bs-target="#policyConfigModal">
                                        <i class="fa fa-cog"></i> {{-- config icon --}}
                                    </button>
                                @endif


                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="quill-service-content" class="d-none"></div>

    <section>

        <table id="adoptionPolicies" class="dt-advanced-server-search table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>{{ __('locale.Name') }}</th>
                    <th>{{ __('locale.Category') }}</th>
                    <th>{{ __('locale.CreatedBy') }}</th>
                    <th>{{ __('locale.Created_at') }}</th>
                    <th>{{ __('locale.Action') }}</th>
                </tr>
            </thead>
            <tbody>
                <!-- Data will be populated here by DataTables -->
            </tbody>
        </table>

        <div class="modal fade" id="policyConfigModal" tabindex="-1" aria-labelledby="policyConfigModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-xl modal-dialog">
                <form id="policyConfigForm">
                    @csrf
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="policyConfigModalLabel">
                                <i class="fa fa-cog"></i> Policy Configuration
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>

                        <div class="modal-body">
                            <div class="row g-3">
                                <input type="hidden" value="{{ $config->id ?? '' }}" name='id'>
                                {{-- rapporteurs --}}
                                <div class="col-12">
                                    <div class="col-12">
                                        <label for="rapporteurs" class="form-label">rapporteurs</label>

                                        <div class="mb-2">
                                            <button type="button" id="selectAllRapporteurs"
                                                class="btn btn-sm btn-outline-primary">
                                                Select All
                                            </button>

                                            <button type="button" id="clearRapporteurs"
                                                class="btn btn-sm btn-outline-secondary">
                                                Clear
                                            </button>
                                        </div>

                                        <select name="rapporteurs[]" id="rapporteurs"
                                            class="form-select dt-select select2" multiple>
                                            @foreach ($users as $user)
                                                <option value="{{ $user->id }}"
                                                    @if ($config && in_array($user->id, explode(',', $config->rapporteurs ?? ''))) selected @endif>
                                                    {{ $user->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-primary">
                                <i class="fa fa-save"></i> Save
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="modal fade" id="approve-modal" tabindex="-1" aria-labelledby="approveModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-xl">
                <form id="policyAdoptionForm">
                    @csrf
                    <input type="hidden" name="id" id="policy_id">
                    <input type="hidden" name="category_id" id="category_id">

                    <div class="modal-content shadow-lg border-0 rounded-3">
                        <div class="modal-header">
                            <h5 class="modal-title" id="approveModalLabel">{{ __('locale.Policy Adoption') }}</h5>
                            <button type="button" class="btn-close btn-close-white"
                                data-bs-dismiss="modal"></button>
                        </div>

                        <div class="modal-body">
                            {{-- Name --}}
                            <div class="mb-3">
                                <label for="name" class="form-label">{{ __('locale.Name') }}</label>
                                <textarea name="name" id="name" class="form-control"></textarea>
                            </div>


                            {{-- Description EN --}}
                            <div class="mb-3">
                                <label>{{ __('locale.Description_En') }}</label>
                                <textarea name="description_en" id="description_editor_en" class="form-control"></textarea>
                                <span class="error error-description_en"></span>
                            </div>

                            {{-- Description AR --}}
                            <div class="mb-3">
                                <label>{{ __('locale.Description_Ar') }}</label>
                                <textarea name="description_ar" id="description_editor_ar" class="form-control"></textarea>
                                <span class="error error-description_ar"></span>
                            </div>


                            {{-- Introduction EN --}}
                            <div class="mb-3">
                                <label>{{ __('locale.Introduction_Content_En') }}</label>
                                <textarea name="introduction_content_en" id="introduction_content_editor_en" class="form-control"></textarea>
                                <span class="error error-introduction_content_en"></span>
                            </div>

                            {{-- Introduction AR --}}
                            <div class="mb-3">
                                <label>{{ __('locale.Introduction_Content_Ar') }}</label>
                                <textarea name="introduction_content_ar" id="introduction_content_editor_ar" class="form-control"></textarea>
                                <span class="error error-introduction_content_ar"></span>
                            </div>

                            {{-- Introduction 2 EN --}}
                            <div class="mb-3">
                                <label>{{ __('locale.Introduction_Content_En_2') }}</label>
                                <textarea name="introduction_content_en2" id="introduction_content_editor_en2" class="form-control"></textarea>
                                <span class="error error-introduction_content_en2"></span>
                            </div>

                            {{-- Introduction 2 AR --}}
                            <div class="mb-3">
                                <label>{{ __('locale.Introduction_Content_Ar_2') }}</label>
                                <textarea name="introduction_content_ar2" id="introduction_content_editor_ar2" class="form-control"></textarea>
                                <span class="error error-introduction_content_ar2"></span>
                            </div>
                        </div>

                        <div class="modal-footer d-flex justify-content-center">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                {{ __('locale.Cancel') }}
                            </button>
                            <button type="submit" class="btn btn-success">
                                {{ __('locale.Submit') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="modal fade" id="previewModal" tabindex="-1">
            <div class="modal-dialog modal-xl modal-dialog-scrollable">
                <div class="modal-content">

                    <div class="modal-header">
                        <div>
                            <h5 class="modal-title mb-1">Policy Documents</h5>
                            <small>
                                <a id="policyCategoryName" href="#" target="_blank"
                                    class="text-decoration-none">
                                </a>
                            </small>
                        </div>

                        <button type="button" class="btn-close" data-bs-dismiss="modal">
                        </button>
                    </div>

                    <div class="modal-body" id="previewContent">
                        Loading...
                    </div>

                </div>
            </div>
        </div>

    </section>



@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection


@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>

    <script>
        $(document).ready(function() {
            // Set the CSRF token in the AJAX setup
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var table = $('#adoptionPolicies').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: '{{ route('admin.adoption_policies.GetData') }}',
                    type: 'POST'
                },
                columns: [{
                        data: null, // Auto-incrementing index
                        render: function(data, type, row, meta) {
                            return meta.row + meta.settings._iDisplayStart + 1;
                        }
                    },
                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'category',
                        name: 'category'
                    },
                    {
                        data: 'created_by',
                        name: 'created_by'
                    },
                    {
                        data: 'created_at',
                        name: 'created_at'
                    },


                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });
        });
        $(document).ready(function() {

            const editors = [
                'introduction_content_editor_en',
                'introduction_content_editor_ar',
                'introduction_content_editor_en2',
                'introduction_content_editor_ar2',
                'description_editor_en',
                'description_editor_ar'
            ];

            editors.forEach(id => {
                if (!CKEDITOR.instances[id]) {
                    CKEDITOR.replace(id);
                }
            });

        });
        $(document).on('click', '.delete-adotionPolicy', function(e) {
            e.preventDefault();
            const adotionPolicyId = $(this).data('id');
            const $row = $(this).closest('tr'); // Get the table row for removal

            // Show confirmation dialog
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading state
                    $row.addClass('deleting');

                    // Send delete request
                    $.ajax({
                        url: "{{ route('admin.adoption_policies.delete', ':id') }}".replace(':id',
                            adotionPolicyId),
                        type: 'DELETE',
                        data: {
                            _token: "{{ csrf_token() }}"
                        },
                        success: function(response) {
                            if (response.success) {
                                makeAlert('success', response.message, 'Success');
                                $('#adoptionPolicies').DataTable().ajax.reload();

                            } else {
                                makeAlert('error', response.message, 'Error');
                                $row.removeClass('deleting');
                            }
                        },
                        error: function(xhr) {
                            makeAlert('error', xhr.responseJSON?.message ||
                                'Failed to delete NDA', 'Error');
                            $row.removeClass('deleting');
                        }
                    });
                }
            });
        });
        $(document).on('click', '.export-adotionPolicy', function(e) {
            e.preventDefault();
            const adotionPolicyId = $(this).data('id');

            var form = document.createElement('form');
            form.method = 'POST';
            form.action = "{{ route('admin.adoption_policies.export') }}";

            var csrf = document.createElement('input');
            csrf.type = 'hidden';
            csrf.name = '_token';
            csrf.value = '{{ csrf_token() }}';
            form.appendChild(csrf);

            var policyInput = document.createElement('input');
            policyInput.type = 'hidden';
            policyInput.name = 'policy_id';
            policyInput.value = adotionPolicyId;
            form.appendChild(policyInput);

            document.body.appendChild(form);
            form.submit();
            document.body.removeChild(form);
        });

        function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false,
            });
        }

        $(document).on('submit', '#policyConfigForm', function(e) {
            e.preventDefault();

            $.ajax({
                url: "{{ route('admin.adoption_policies.config') }}",
                type: "POST",
                data: $(this).serialize(),
                success: function(response) {
                    if (response.success) {
                        makeAlert('success', response.message, 'Success');
                        $('#policyConfigModal').modal('hide');
                    } else {
                        makeAlert('error', response.message, 'Error');
                    }
                },
                error: function(xhr) {
                    makeAlert('error', xhr.responseJSON?.message || 'Failed to save configuration',
                        'Error');
                }
            });
        });
        // Add this inside your $(document).ready() function
        $(document).on('click', '.edit-adotionPolicy', function(e) {
            e.preventDefault();
            const adotionPolicyId = $(this).data('id');
            const $modal = $('#approve-modal'); // use the correct modal

            // Set modal to edit mode
            $modal.data('edit-mode', true);
            $modal.data('edit-id', adotionPolicyId);

            // Show loading state (optional styling)
            $modal.find('.modal-body').addClass('loading');

            // Fetch Policy Adoption data
            $.ajax({
                url: "{{ route('admin.adoption_policies.show', ':id') }}".replace(':id', adotionPolicyId),
                type: 'GET',
                success: function(response) {
                    if (response.success) {
                        let data = response.data;

                        $('#policy_id').val(data.id);
                        $('#category_id').val(data.category_id);
                        $('#name').val(data.name);

                        // introduction 1
                        CKEDITOR.instances['introduction_content_editor_en']
                            ?.setData(data.introduction_content_en || '');

                        CKEDITOR.instances['introduction_content_editor_ar']
                            ?.setData(data.introduction_content_ar || '');

                        // introduction 2
                        CKEDITOR.instances['introduction_content_editor_en2']
                            ?.setData(data.introduction_content2_en || '');

                        CKEDITOR.instances['introduction_content_editor_ar2']
                            ?.setData(data.introduction_content2_ar || '');

                        // description
                        CKEDITOR.instances['description_editor_en']
                            ?.setData(data.description_en || '');

                        CKEDITOR.instances['description_editor_ar']
                            ?.setData(data.description_ar || '');

                        $modal.modal('show');
                    }
                },
                error: function(xhr) {
                    makeAlert('error', xhr.responseJSON?.message || 'Failed to load policy adoption',
                        'Error');
                },
                complete: function() {
                    $modal.find('.modal-body').removeClass('loading');
                }
            });
        });
        $(document).on('submit', '#policyAdoptionForm', function(e) {
            e.preventDefault();

            const formData = $(this).serialize();
            const id = $('#policy_id').val(); // if has id → update

            let url = "{{ route('admin.adoption_policies.update') }}";

            let method = 'POST';

            $.ajax({
                url: url,
                type: method,
                data: formData,
                success: function(response) {
                    if (response.success) {
                        makeAlert('success', response.message, 'Success');
                        $('#approve-modal').modal('hide');
                        // reload table if using datatables
                    } else {
                        makeAlert('error', response.message, 'Error');
                    }
                },
                error: function(xhr) {
                    makeAlert('error', xhr.responseJSON?.message || 'Failed to save', 'Error');
                }
            });
        });
        $('.modal').on('hidden.bs.modal', function() {

            const editors = [
                'introduction_content_editor_en',
                'introduction_content_editor_ar',
                'introduction_content_editor_en2',
                'introduction_content_editor_ar2',
                'description_editor_en',
                'description_editor_ar'
            ];

            editors.forEach(name => {
                if (CKEDITOR.instances[name]) {
                    CKEDITOR.instances[name].setData('');
                }
            });

            $(this).find('.error').text('');
        });
        $(document).on('click', '#selectAllRapporteurs', function() {
            let allValues = [];

            $('#rapporteurs option').each(function() {
                allValues.push($(this).val());
            });

            $('#rapporteurs').val(allValues).trigger('change');
        });

        $(document).on('click', '#clearRapporteurs', function() {
            $('#rapporteurs').val(null).trigger('change');
        });

        $(document).on('click', '.preview-policy', function(e) {
            e.preventDefault();

            const previewRoute =
                "{{ route('admin.adoption_policies.previewDocuments', ':id') }}";
            const catRoute =
                "{{ route('admin.adoption_policies.getPolicyAdoptionPreview', [':policy', ':doc']) }}";

            let id = $(this).data('id');
            let url = previewRoute.replace(':id', id);

            $.ajax({
                url: url,
                type: 'GET',
                success: function(res) {

                    if (!res.success) {
                        return;
                    }

                    let categoryUrl = catRoute
                        .replace(':policy', res.data.id)
                        .replace(':doc', res.data.category.id);

                    $('#policyCategoryName')
                        .attr('href', categoryUrl)
                        .text('Category: ' + (res.data.category?.name ?? 'N/A'));

                    let html = `
                        <ul class="list-group">
                    `;

                    res.data.documents.forEach(function(doc) {

                        let actionButton = '';

                        if (doc.file) {
                            actionButton = `
                                <form method="POST"
                                    action="{{ route('admin.governance.ajax.download_file') }}"
                                    target="_blank"
                                    class="d-inline">

                                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                    <input type="hidden" name="document_id" value="${doc.id}">

                                    <button type="submit"
                                            class="btn btn-sm btn-outline-primary">
                                        Open File
                                    </button>

                                </form>
                            `;
                        } else {
                            actionButton = `
                                <span class="badge bg-secondary">
                                    No File Uploaded
                                </span>
                            `;
                        }

                        html += `
                            <li class="list-group-item d-flex justify-content-between align-items-center">

                                <div>
                                    <strong>${doc.document_name}</strong>
                                </div>

                                ${actionButton}

                            </li>
                        `;
                    });

                    html += `
                        </ul>
                    `;

                    $('#previewContent').html(html);

                    $('#previewModal').modal('show');
                },
                error: function() {
                    $('#previewContent').html(
                        '<div class="alert alert-danger">Failed to load documents.</div>'
                    );

                    $('#previewModal').modal('show');
                }
            });
        });
    </script>

    <script src="{{ asset('cdn/ckeditor.min.js') }}"></script>

@endsection
