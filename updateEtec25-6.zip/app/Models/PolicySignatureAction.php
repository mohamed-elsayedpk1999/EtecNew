<?php

namespace App\Models;

use Dom\DocumentType;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PolicySignatureAction extends Model
{
    use HasFactory;
    protected $guarded = [];

    public function signature()
    {
        return $this->belongsTo(PolicySignature::class, 'signature_id');
    }

    public function category(){
        return $this->belongsTo(DocumentType::class, 'category_id');
    }
}
