@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.Document') . ' - ' . $data['document_name'])

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
@endsection

@section('page-style')
<style>
    :root {
        --doc-bg: #F7F6F2;
        --doc-surface: #FFFFFF;
        --doc-border: #E8E4DC;
        --doc-ink: #1A1814;
        --doc-muted: #7A756B;
        --doc-accent: #2D5A3D;
        --doc-accent-light: #EAF1EC;
        --doc-amber: #C8873A;
        --doc-amber-light: #FDF3E7;
        --doc-shadow: 0 1px 3px rgba(26,24,20,0.06), 0 4px 16px rgba(26,24,20,0.04);
        --doc-shadow-md: 0 2px 8px rgba(26,24,20,0.08), 0 8px 32px rgba(26,24,20,0.06);
    }

    body { background: var(--doc-bg) !important; }

    /* ── Page Layout ── */
    .doc-page {
        max-width: 960px;
        margin: 0 auto;
        padding: 2rem 1.5rem 4rem;
        font-family: 'DM Sans', sans-serif;
    }

    /* ── Header ── */
    .doc-header {
        background: var(--doc-surface);
        border: 1px solid var(--doc-border);
        border-radius: 16px;
        padding: 2.25rem 2.5rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--doc-shadow);
        position: relative;
        overflow: hidden;
    }
    .doc-header::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        background: linear-gradient(90deg, var(--doc-accent) 0%, #4A8C60 50%, var(--doc-amber) 100%);
    }
    .doc-header-top {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 1rem;
        flex-wrap: wrap;
    }
    .doc-title {
        font-family: 'DM Serif Display', serif;
        font-size: 1.85rem;
        font-weight: 400;
        color: var(--doc-ink);
        line-height: 1.25;
        margin: 0 0 0.5rem;
        letter-spacing: -0.02em;
    }
    .doc-version {
        font-size: 0.78rem;
        color: var(--doc-muted);
        font-weight: 500;
        letter-spacing: 0.06em;
        text-transform: uppercase;
    }
    .doc-status-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        padding: 0.4rem 1rem;
        border-radius: 50px;
        font-size: 0.78rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
        background: var(--doc-accent-light);
        color: var(--doc-accent);
        border: 1px solid rgba(45,90,61,0.2);
        white-space: nowrap;
        flex-shrink: 0;
    }
    .doc-status-badge::before {
        content: '';
        width: 6px; height: 6px;
        border-radius: 50%;
        background: var(--doc-accent);
    }

    /* ── People Row ── */
    .doc-people-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
        margin-top: 1.75rem;
        padding-top: 1.75rem;
        border-top: 1px solid var(--doc-border);
    }
    .doc-person {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    .doc-avatar {
        width: 38px; height: 38px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--doc-accent-light), #C8DDD0);
        border: 2px solid var(--doc-border);
        display: flex; align-items: center; justify-content: center;
        font-size: 0.78rem;
        font-weight: 600;
        color: var(--doc-accent);
        flex-shrink: 0;
        text-transform: uppercase;
    }
    .doc-person-info small {
        display: block;
        font-size: 0.7rem;
        font-weight: 500;
        color: var(--doc-muted);
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin-bottom: 0.15rem;
    }
    .doc-person-info strong {
        font-size: 0.88rem;
        font-weight: 500;
        color: var(--doc-ink);
    }

    /* ── Dates Card ── */
    .doc-dates-card {
        background: var(--doc-surface);
        border: 1px solid var(--doc-border);
        border-radius: 14px;
        padding: 1.5rem 2rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--doc-shadow);
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 0;
    }
    .doc-date-item {
        padding: 0.25rem 1.25rem;
        border-right: 1px solid var(--doc-border);
    }
    .doc-date-item:first-child { padding-left: 0.25rem; }
    .doc-date-item:last-child { border-right: none; }
    .doc-date-label {
        font-size: 0.69rem;
        font-weight: 600;
        color: var(--doc-muted);
        text-transform: uppercase;
        letter-spacing: 0.07em;
        margin-bottom: 0.3rem;
    }
    .doc-date-value {
        font-size: 0.88rem;
        font-weight: 500;
        color: var(--doc-ink);
    }
    .doc-date-value.next-review {
        color: var(--doc-amber);
        font-weight: 600;
    }

    /* ── Tags Card ── */
    .doc-tags-card {
        background: var(--doc-surface);
        border: 1px solid var(--doc-border);
        border-radius: 14px;
        padding: 1.5rem 2rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--doc-shadow);
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.25rem 2rem;
    }
    .doc-tag-group-label {
        font-size: 0.7rem;
        font-weight: 600;
        color: var(--doc-muted);
        text-transform: uppercase;
        letter-spacing: 0.07em;
        margin-bottom: 0.5rem;
    }
    .doc-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 0.4rem;
    }
    .doc-tag {
        display: inline-block;
        padding: 0.28rem 0.7rem;
        border-radius: 6px;
        font-size: 0.78rem;
        font-weight: 500;
    }
    .doc-tag.framework {
        background: #EEF2FF;
        color: #4338CA;
        border: 1px solid #C7D2FE;
    }
    .doc-tag.control {
        background: var(--doc-amber-light);
        color: #92520F;
        border: 1px solid #F0CFA0;
    }
    .doc-tag.team {
        background: #F0FDF4;
        color: #15803D;
        border: 1px solid #BBF7D0;
    }
    .doc-tag.stakeholder {
        background: #FDF4FF;
        color: #7E22CE;
        border: 1px solid #E9D5FF;
    }
    .doc-tag-empty {
        font-size: 0.82rem;
        color: var(--doc-muted);
        font-style: italic;
    }

    /* ── Content Card ── */
    .doc-content-card {
        background: var(--doc-surface);
        border: 1px solid var(--doc-border);
        border-radius: 14px;
        padding: 2rem 2.5rem;
        margin-bottom: 1.5rem;
        box-shadow: var(--doc-shadow);
    }
    .doc-section-heading {
        font-family: 'DM Serif Display', serif;
        font-size: 1.05rem;
        font-weight: 400;
        color: var(--doc-ink);
        margin: 0 0 1.25rem;
        padding-bottom: 0.75rem;
        border-bottom: 1px solid var(--doc-border);
        display: flex;
        align-items: center;
        gap: 0.6rem;
    }
    .doc-section-icon {
        width: 28px; height: 28px;
        border-radius: 8px;
        background: var(--doc-accent-light);
        display: inline-flex; align-items: center; justify-content: center;
        flex-shrink: 0;
    }
    .doc-section-icon svg { color: var(--doc-accent); }
    .doc-content-body {
        font-size: 0.92rem;
        line-height: 1.75;
        color: #3A3630;
    }
    .doc-content-body h1, .doc-content-body h2, .doc-content-body h3 {
        font-family: 'DM Serif Display', serif;
        font-weight: 400;
        color: var(--doc-ink);
        margin-top: 1.5rem;
    }
    .doc-content-body p { margin-bottom: 1rem; }
    .doc-content-body ul, .doc-content-body ol { padding-left: 1.5rem; margin-bottom: 1rem; }
    .doc-content-body li { margin-bottom: 0.4rem; }
    .doc-content-body table { width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: 0.88rem; }
    .doc-content-body table th { background: var(--doc-bg); padding: 0.6rem 1rem; text-align: left; font-weight: 600; border: 1px solid var(--doc-border); }
    .doc-content-body table td { padding: 0.55rem 1rem; border: 1px solid var(--doc-border); }

    /* ── Notes Card ── */
    .doc-notes-card {
        background: var(--doc-surface);
        border: 1px solid var(--doc-border);
        border-radius: 14px;
        padding: 2rem 2.5rem;
        box-shadow: var(--doc-shadow);
    }
    .doc-notes-list {
        display: flex;
        flex-direction: column;
        gap: 1.25rem;
        margin-top: 0.5rem;
    }
    .doc-note {
        display: flex;
        gap: 1rem;
        align-items: flex-start;
        padding: 1.1rem 1.25rem;
        border-radius: 10px;
        background: var(--doc-bg);
        border: 1px solid var(--doc-border);
        transition: border-color 0.2s;
    }
    .doc-note:hover { border-color: #C8C2B7; }
    .doc-note-avatar {
        width: 36px; height: 36px;
        border-radius: 50%;
        background: linear-gradient(135deg, #C7D2FE, #A5B4FC);
        display: flex; align-items: center; justify-content: center;
        font-size: 0.72rem;
        font-weight: 700;
        color: #3730A3;
        flex-shrink: 0;
        text-transform: uppercase;
    }
    .doc-note-avatar.file-note {
        background: linear-gradient(135deg, #FED7AA, #FDBA74);
        color: #92400E;
    }
    .doc-note-body { flex: 1; min-width: 0; }
    .doc-note-meta {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        margin-bottom: 0.35rem;
        flex-wrap: wrap;
    }
    .doc-note-author {
        font-size: 0.82rem;
        font-weight: 600;
        color: var(--doc-ink);
    }
    .doc-note-time {
        font-size: 0.73rem;
        color: var(--doc-muted);
    }
    .doc-note-type-badge {
        font-size: 0.65rem;
        font-weight: 600;
        letter-spacing: 0.05em;
        text-transform: uppercase;
        padding: 0.15rem 0.5rem;
        border-radius: 4px;
    }
    .doc-note-type-badge.text { background: #DBEAFE; color: #1D4ED8; }
    .doc-note-type-badge.file { background: var(--doc-amber-light); color: #92520F; }
    .doc-note-text {
        font-size: 0.87rem;
        color: #3A3630;
        line-height: 1.6;
        margin: 0;
    }
    .doc-note-file-link {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        font-size: 0.87rem;
        color: var(--doc-accent);
        font-weight: 500;
        text-decoration: none;
        padding: 0.3rem 0.75rem;
        border-radius: 6px;
        background: var(--doc-accent-light);
        border: 1px solid rgba(45,90,61,0.2);
        transition: background 0.15s;
    }
    .doc-note-file-link:hover { background: #D4E8DA; color: var(--doc-accent); text-decoration: none; }
    .doc-no-notes {
        text-align: center;
        padding: 2.5rem 1rem;
        color: var(--doc-muted);
        font-size: 0.88rem;
    }

    /* ── Breadcrumb Override ── */
    .content-header .breadcrumb { font-size: 0.82rem; }

    /* ── Responsive ── */
    @media (max-width: 768px) {
        .doc-dates-card { grid-template-columns: 1fr 1fr; }
        .doc-date-item:nth-child(2) { border-right: none; }
        .doc-date-item:nth-child(3) { border-right: 1px solid var(--doc-border); }
        .doc-people-row { grid-template-columns: 1fr; }
        .doc-tags-card { grid-template-columns: 1fr; }
        .doc-header { padding: 1.5rem; }
        .doc-content-card, .doc-notes-card { padding: 1.25rem 1.5rem; }
    }
    @media (max-width: 576px) {
        .doc-title { font-size: 1.4rem; }
        .doc-dates-card { grid-template-columns: 1fr; }
        .doc-date-item { border-right: none; border-bottom: 1px solid var(--doc-border); padding: 0.75rem 0.25rem; }
        .doc-date-item:last-child { border-bottom: none; }
    }
</style>
@endsection

@section('content')
<div class="doc-page">

    {{-- ── Document Header ── --}}
    <div class="doc-header">
        <div class="doc-header-top">
            <div>
                <h1 class="doc-title">{{ $data['document_name'] }}</h1>
                @if(!empty($data['version_name']))
                    <span class="doc-version">Version {{ $data['version_name'] }}</span>
                @endif
            </div>
            <span class="doc-status-badge">{{ $data['document_status_name'] }}</span>
        </div>

        <div class="doc-people-row">
            <div class="doc-person">
                <div class="doc-avatar">
                    {{ strtoupper(substr($data['document_owner'] ?? 'O', 0, 2)) }}
                </div>
                <div class="doc-person-info">
                    <small>{{ __('locale.DocumentOwner') }}</small>
                    <strong>{{ $data['document_owner'] ?: '—' }}</strong>
                </div>
            </div>
            <div class="doc-person">
                <div class="doc-avatar">
                    {{ strtoupper(substr($data['document_reviewer'] ?? 'R', 0, 2)) }}
                </div>
                <div class="doc-person-info">
                    <small>{{ __('locale.DocumentReviewer') }}</small>
                    <strong>{{ $data['document_reviewer'] ?: '—' }}</strong>
                </div>
            </div>
        </div>
    </div>

    {{-- ── Dates ── --}}
    <div class="doc-dates-card">
        <div class="doc-date-item">
            <div class="doc-date-label">{{ __('locale.CreationDate') }}</div>
            <div class="doc-date-value">{{ $data['creation_date'] ?: '—' }}</div>
        </div>
        <div class="doc-date-item">
            <div class="doc-date-label">{{ __('locale.LastReviewDate') }}</div>
            <div class="doc-date-value">{{ $data['last_review_date'] ?: '—' }}</div>
        </div>
        <div class="doc-date-item">
            <div class="doc-date-label">{{ __('locale.NextReviewDate') }}</div>
            <div class="doc-date-value next-review">{{ $data['next_review_date'] ?: '—' }}</div>
        </div>
        <div class="doc-date-item">
            <div class="doc-date-label">{{ __('locale.ApprovalDate') }}</div>
            <div class="doc-date-value">{{ $data['approval_date'] ?: '—' }}</div>
        </div>
    </div>

    {{-- ── Tags / Associations ── --}}
    <div class="doc-tags-card">
        <div>
            <div class="doc-tag-group-label">{{ __('locale.Frameworks') }}</div>
            <div class="doc-tags">
                @forelse($data['frameworks'] as $framework)
                    <span class="doc-tag framework">{{ $framework }}</span>
                @empty
                    <span class="doc-tag-empty">{{ __('locale.None') }}</span>
                @endforelse
            </div>
        </div>
        <div>
            <div class="doc-tag-group-label">{{ __('locale.Controls') }}</div>
            <div class="doc-tags">
                @forelse($data['controls'] as $control)
                    <span class="doc-tag control">{{ $control }}</span>
                @empty
                    <span class="doc-tag-empty">{{ __('locale.None') }}</span>
                @endforelse
            </div>
        </div>
        <div>
            <div class="doc-tag-group-label">{{ __('locale.Teams') }}</div>
            <div class="doc-tags">
                @forelse($data['teams'] as $team)
                    <span class="doc-tag team">{{ $team }}</span>
                @empty
                    <span class="doc-tag-empty">{{ __('locale.None') }}</span>
                @endforelse
            </div>
        </div>
        <div>
            <div class="doc-tag-group-label">{{ __('locale.AdditionalStakeholders') }}</div>
            <div class="doc-tags">
                @forelse($data['additional_stakeholders'] as $stakeholder)
                    <span class="doc-tag stakeholder">{{ $stakeholder }}</span>
                @empty
                    <span class="doc-tag-empty">{{ __('locale.None') }}</span>
                @endforelse
            </div>
        </div>
    </div>

    {{-- ── Document Content ── --}}
    <div class="doc-content-card">
        <h2 class="doc-section-heading">
            <span class="doc-section-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                    <polyline points="14 2 14 8 20 8"/>
                    <line x1="16" y1="13" x2="8" y2="13"/>
                    <line x1="16" y1="17" x2="8" y2="17"/>
                    <polyline points="10 9 9 9 8 9"/>
                </svg>
            </span>
            {{ __('locale.Content') }}
        </h2>
        <div class="doc-content-body">
            {!! $data['content'] !!}
        </div>
    </div>

    {{-- ── Notes & Files ── --}}
    <div class="doc-notes-card">
        <h2 class="doc-section-heading">
            <span class="doc-section-icon">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
            </span>
            {{ __('locale.Notes') }}
            @if(!empty($data['notes']))
                <span style="font-family:'DM Sans',sans-serif;font-size:0.75rem;font-weight:600;background:var(--doc-bg);border:1px solid var(--doc-border);color:var(--doc-muted);padding:0.15rem 0.55rem;border-radius:50px;margin-left:0.25rem;">
                    {{ count($data['notes']) }}
                </span>
            @endif
        </h2>

        @if(!empty($data['notes']))
            <div class="doc-notes-list">
                @foreach($data['notes'] as $note)
                <div class="doc-note">
                    <div class="doc-note-avatar {{ $note['type'] === 'f' ? 'file-note' : '' }}">
                        {{ $note['custom_user_name'] ?? strtoupper(substr($note['user_name'], 0, 2)) }}
                    </div>
                    <div class="doc-note-body">
                        <div class="doc-note-meta">
                            <span class="doc-note-author">{{ $note['user_name'] }}</span>
                            <span class="doc-note-type-badge {{ $note['type'] === 'f' ? 'file' : 'text' }}">
                                {{ $note['type'] === 'f' ? __('locale.File') : __('locale.Note') }}
                            </span>
                            <span class="doc-note-time">{{ $note['created_at'] }}</span>
                        </div>
                        @if($note['type'] === 't')
                            <p class="doc-note-text">{{ $note['note'] }}</p>
                        @else
                            <a href="{{ route('admin.governance.ajax.downloadDocumentCommentFile', $note['id']) }}"
                               class="doc-note-file-link">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                                    <polyline points="7 10 12 15 17 10"/>
                                    <line x1="12" y1="15" x2="12" y2="3"/>
                                </svg>
                                {{ $note['note'] }}
                            </a>
                        @endif
                    </div>
                </div>
                @endforeach
            </div>
        @else
            <div class="doc-no-notes">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="color:var(--doc-border);margin-bottom:0.75rem;">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                <p style="margin:0;">{{ __('locale.NoNotesYet') }}</p>
            </div>
        @endif
    </div>

</div>
@endsection

@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
@endsection