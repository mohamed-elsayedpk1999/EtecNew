@extends('admin.layouts.contentLayoutMaster')
@section('title', __('locale.AuditDocument'))
<style>
    .gov_btn {
        border-color: #0097a7 !important;
        background-color: #0097a7 !important;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_check {
        padding: 0.786rem 0.7rem;
        line-height: 1;
        font-weight: 500;
        font-size: 1.2rem;
    }

    .gov_err {

        color: red;
    }

    .gov_btn {
        border-color: #0097a7;
        background-color: #0097a7;
        color: #fff !important;
        /* padding: 7px; */
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_edit {
        border-color: #5388B4 !important;
        background-color: #5388B4 !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_map {
        border-color: #6c757d !important;
        background-color: #6c757d !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    .gov_btn_delete {
        border-color: red !important;
        background-color: red !important;
        color: #fff !important;
        border: 1px solid transparent;
        padding: 0.786rem 1.5rem;
        line-height: 1;
        border-radius: 0.358rem;
        font-weight: 500;
        font-size: 1rem;
    }

    /* .card {
        transition: transform 0.2s;
    }

    .card:hover {
        transform: scale(1.05);
    } */

    .badge-success {
        background-color: #28a745;
    }

    .badge-danger {
        background-color: #dc3545;
    }

    .alert {
        font-size: 1.1rem;
        /* Slightly larger font */
        border-radius: 0.5rem;
        /* Rounded corners */
    }

    .alert-dismissible .btn-close {
        margin-left: 15px;
        /* Space between alert text and close button */
    }

    .modal-body ul {
        margin: 0;
        /* Remove default margin for the list */
        padding-left: 20px;
        /* Indent the list */
    }

    .modal-body li {
        margin-bottom: 5px;
        /* Space between list items */
    }
</style>

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">

    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/pages/app-chat.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/pages/app-chat-list.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/wizard/bs-stepper.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/jquery.rateyo.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/plyr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
    <link rel="stylesheet" href="{{ asset('cdn/toastr.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('css/core.css')) }}" />
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/vendors.min.css')) }}" />


@endsection

@section('content')

    <input type="hidden" id="AduitId" value="{{ $id }}">
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <h5 class="mb-0 me-3">{{ __('locale.Audit Information') }} :</h5>
                <i class="fas fa-file-alt me-1"></i>
                <strong class="mx-0">{{ __('locale.AuditName') }}: {{ $auditDocumentPolicy->aduit_name }}</strong>
                <i class="fas fa-folder mx-1"></i>
                <strong class="mx-0">{{ __('locale.Document') }}:
                    {{ $auditDocumentPolicy->document->document_name }}</strong>
                <i class="fas fa-check mx-1"></i> <!-- Add your status icon here -->
                <strong class="mx-0">{{ __('locale.Status') }}:
                    @if (empty($statustotal))
                        <span class="badge rounded-pill badge-light-info">{{ __('locale.No Action') }}</span>
                    @else
                        @switch($statustotal)
                            @case('Not Implemented')
                                <span class="badge rounded-pill badge-light-danger">{{ __('locale.Not Implemented') }}</span>
                            @break

                            @case('Not Applicable')
                                <span class="badge rounded-pill badge-light-secondary">{{ __('locale.Not Applicable') }}</span>
                            @break

                            @case('Partially Implemented')
                                <span
                                    class="badge rounded-pill badge-light-warning">{{ __('locale.Partially Implemented') }}</span>
                            @break

                            @case('Implemented')
                                <span class="badge rounded-pill badge-light-success">{{ __('locale.Implemented') }}</span>
                            @break

                            @default
                                <span class="badge rounded-pill badge-light-info">{{ __('locale.No Action') }}</span>
                        @endswitch
                    @endif
                </strong>
            </div>
            <div class="d-flex align-items-center">
                <h5 class="mb-0">{{ __('locale.AnswerSubmited') }} :</h5>
                <span class="check-send-result">
                    <!-- The icon will be dynamically updated based on the response -->
                    @if ($checkSendResult)
                        <!-- If there is a status (not null), show the check icon (correct) -->
                        <i class="fas fa-check mx-1 text-success"></i> <!-- Green check icon -->
                    @else
                        <!-- If the status is null, show the mistake icon (error) -->
                        <i class="fas fa-times mx-1 text-danger"></i> <!-- Red "X" icon -->
                    @endif
                </span>
            </div>

        </div>
    </div>
    <div class="card mb-4">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center">
                <!-- Div with Export and Import buttons -->
                <div class="action-buttons">
                    <!-- Export button -->
                    <button id="exportButton" class="btn btn-success">
                        {{ __('locale.Export') }}
                    </button>

                    <!-- Import button (opens modal) -->
                    <button id="importButton" class="btn btn-primary" data-bs-toggle="modal"
                        data-bs-target="#importModal">{{ __('locale.Import') }}</button>

                    <!-- Import button (opens modal) -->
                    <button id="SendResult" data-id="{{ $id }}" class="btn btn-primary">
                        {{ __('locale.SendResult') }}
                    </button>
                </div>
            </div>
        </div>
    </div>


    <table id="AduitDocumentpoliciesTable" class="dt-advanced-server-search table">
        <thead>
            <tr>
                <th>#</th>
                <th>{{ __('locale.Policy Clause') }}</th>
                <th>{{ __('locale.AuditeeStatus') }}</th>
                {{-- <th>{{ __('locale.AuditeeStatus') }}</th> --}}
                <th>{{ __('locale.AuditerStatus') }}</th>
                <th>{{ __('locale.Action') }}</th>
            </tr>
        </thead>
        <tbody>
            <!-- Data will be populated here by DataTables -->
        </tbody>
    </table>
    <!-- Modal for Importing Excel File -->
    <div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="importModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="importModalLabel">{{ __('locale.Import Excel File') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="importForm" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="fileInput">{{ __('locale.Choose Excel File') }}</label>
                            <input type="file" name="file" id="fileInputAnswer" class="form-control"
                                accept=".xlsx, .xls">
                        </div>
                        <button type="submit" class="btn btn-primary mt-3">{{ __('locale.Upload') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <input type="hidden" value="{{ $auditDocumentPolicy->id }}" id="audit_id">

    <!-- Consolidated Modal with Tabs -->
    <div class="modal fade" id="consolidatedModal" tabindex="-1" aria-labelledby="consolidatedModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="consolidatedModalLabel">{{ __('locale.Audit Actions') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Nav Tabs -->
                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="edit-status-tab" data-bs-toggle="tab"
                                data-bs-target="#edit-status" type="button" role="tab" aria-controls="edit-status"
                                aria-selected="false">{{ __('locale.Update Status') }}</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="comment-tab" data-bs-toggle="tab" data-bs-target="#comment"
                                type="button" role="tab" aria-controls="comment"
                                aria-selected="false">{{ __('locale.Add Comment') }}</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="file-upload-tab" data-bs-toggle="tab"
                                data-bs-target="#file-upload" type="button" role="tab" aria-controls="file-upload"
                                aria-selected="false">{{ __('locale.Upload File') }}</button>
                        </li>
                    </ul>

                    <!-- Tab Content -->
                    <div class="tab-content" id="myTabContent">

                        <!-- Add Comment Tab -->
                        <div class="tab-pane fade" id="comment" role="tabpanel" aria-labelledby="comment-tab">
                            <ul @if ($auditDocumentPolicy->enable_audit == 0) disabled @endif class="list-group mb-3"
                                id="commentsList"></ul>
                            <textarea @if ($auditDocumentPolicy->enable_audit == 0) disabled @endif class="form-control" id="commentInput" rows="3"
                                placeholder="{{ __('locale.Enter your comment') }}"></textarea>
                            @if ($auditDocumentPolicy->enable_audit == 1)
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                                    <button type="button" class="btn btn-primary"
                                        id="saveCommentBtn">{{ __('locale.Send') }}</button>
                                </div>
                            @endif
                        </div>

                        <!-- Upload File Tab -->
                        <div class="tab-pane fade" id="file-upload" role="tabpanel" aria-labelledby="file-upload-tab">
                            @if ($auditDocumentPolicy->enable_audit == 1)
                                {{-- <div class="mb-1">
                                    <label for="evidenc_name"
                                        class="form-label">{{ __('locale.Evidence Name') }}:</label>
                                    <input type="text" class="form-control" id="evidenc_name" required>
                                    <div id="evidencNameError" class="text-danger mt-2" style="display: none;"></div>
                                </div> --}}
                                <div class="mb-1">
                                    <label for="description" class="form-label">{{ __('locale.Description') }}:</label>
                                    <input type="text" class="form-control" id="description" required>
                                    <div id="descriptionError" class="text-danger mt-2" style="display: none;"></div>
                                </div>
                                <input type="hidden" value="{{ $auditDocumentPolicy->requires_file }}"
                                    id="requiredFile">
                                <div class="mb-3">
                                    <label for="fileInput"
                                        class="form-label">{{ __('locale.Choose a file to upload') }}:</label>
                                    <input type="file" class="form-control" id="fileInput" accept="*">
                                    <div id="fileError" class="text-danger mt-2" style="display: none;"></div>
                                </div>
                            @endif
                            <h6>{{ __('locale.Existing Files') }}</h6>
                            <div class="table-responsive">
                                <table id="existingFilesTable" class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            {{-- <th>{{ __('locale.Evidence Name') }}</th> --}}
                                            <th>{{ __('locale.Description') }}</th>
                                            <th>{{ __('locale.File Name') }}</th>
                                            <th>{{ __('locale.Upload Date') }}</th>
                                            @if ($auditDocumentPolicy->enable_audit != 0)
                                                <th>{{ __('locale.Action') }}</th>
                                            @endif
                                        </tr>
                                    </thead>
                                    <tbody id="existingFilesList">
                                        <!-- Existing files will be appended here -->
                                    </tbody>
                                </table>
                            </div>
                            @if ($auditDocumentPolicy->enable_audit == 1)
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                                    <button type="button" id="uploadFileBtn"
                                        class="btn btn-primary">{{ __('locale.Save') }}</button>
                                </div>
                            @endif
                        </div>

                        <!-- Update Status Tab (Make this the active one) -->
                        <div class="tab-pane fade show active" id="edit-status" role="tabpanel"
                            aria-labelledby="edit-status-tab">
                            <select class="form-control" id="statusSelect">
                                <option value="Not Implemented">{{ __('locale.Not Implemented') }}</option>
                                <option value="Not Applicable">{{ __('locale.Not Applicable') }}</option>
                                <option value="Partially Implemented">{{ __('locale.Partially Implemented') }}</option>
                                <option value="Implemented">{{ __('locale.Implemented') }}</option>
                            </select>
                            @if ($auditDocumentPolicy->enable_audit == 1)
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                                    <button type="button" class="btn btn-primary"
                                        id="updateStatusBtn">{{ __('locale.Update Status') }}</button>
                                </div>
                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Edit File Modal -->
    <div class="modal fade" id="editFileModal" tabindex="-1" aria-labelledby="editFileModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editFileModalLabel">{{ __('locale.Edit Evidence') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editFileForm">
                        <div class="mb-3">
                            <label for="editDescription" class="form-label">{{ __('locale.Description') }}</label>
                            <input type="text" class="form-control" id="editDescription">
                        </div>
                        <div class="mb-3">
                            <label for="editFileInput" class="form-label">{{ __('locale.Replace File') }}</label>
                            <input type="file" class="form-control" id="editFileInput" accept="*">
                            <small class="text-muted">{{ __('locale.Leave blank to keep the existing file.') }}</small>
                        </div>
                        <input type="hidden" id="editFileId">
                        <input type="hidden" id="editPolicyId">
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                    <button type="button" class="btn btn-primary"
                        id="saveEditFileBtn">{{ __('locale.Save Changes') }}</button>
                </div>
            </div>
        </div>
    </div>

    <input type="hidden" id="enableAudit" value="{{ $auditDocumentPolicy->enable_audit }}">




@endsection
@section('vendor-script')

    <script src="{{ asset('js/scripts/components/components-dropdowns-font-awesome.js') }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.date.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/pickadate/picker.time.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/pickadate/legacy.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>

@endsection
@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('js/scripts/forms/pickers/form-pickers.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset('ajax-files/compliance/define-test.js') }}"></script>
    <script src="{{ asset('/js/scripts/forms/form-repeater.js') }}"></script>
    <script src="{{ asset('/vendors/js/forms/repeater/jquery.repeater.min.js') }}"></script>
    <!-- Bootstrap JS -->
    {{-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script> --}}

    <script>
        $(document).ready(function() {
            // Set the CSRF token in the AJAX setup
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            var aduitId = $('#AduitId').val();
            var table = $('#AduitDocumentpoliciesTable').DataTable({
                processing: true,
                serverSide: true,
                stateSave: true, // Preserve the state of pagination, search, etc.
                ajax: {
                    url: '{{ route('admin.governance.GetDataAduit') }}',
                    data: function(d) {
                        d.aduitId = aduitId;
                    }
                },
                columns: [{
                        data: null, // Auto-incrementing index
                        render: function(data, type, row, meta) {
                            return meta.row + meta.settings._iDisplayStart + 1;
                        }
                    },
                    {
                        data: 'policy_clause',
                        name: 'policy_clause'
                    },
                    {
                        data: 'pending_status', // Ensure your data contains the status
                        name: 'pending_status',
                        render: function(data, type, row) {
                            switch (data) {
                                case 'Not Implemented':
                                    return '<span class="badge rounded-pill badge-light-danger">{{ __('locale.Not Implemented') }}</span>';
                                case 'Not Applicable':
                                    return '<span class="badge rounded-pill badge-light-secondary">{{ __('locale.Not Applicable') }}</span>';
                                case 'Partially Implemented':
                                    return '<span class="badge rounded-pill badge-light-warning">{{ __('locale.Partially Implemented') }}</span>';
                                case 'Implemented':
                                    return '<span class="badge rounded-pill badge-light-success">{{ __('locale.Implemented') }}</span>';
                                default:
                                    return '<span class="badge rounded-pill badge-light-info">{{ __('locale.No Action') }}</span>';
                            }
                        }
                    },
                    {
                        data: 'auditer_status', // Ensure your data contains the status
                        name: 'auditer_status',
                        render: function(data, type, row) {
                            switch (data) {
                                case 'Not Implemented':
                                    return '<span class="badge rounded-pill badge-light-danger">{{ __('locale.Not Implemented') }}</span>';
                                case 'Not Applicable':
                                    return '<span class="badge rounded-pill badge-light-secondary">{{ __('locale.Not Applicable') }}</span>';
                                case 'Partially Implemented':
                                    return '<span class="badge rounded-pill badge-light-warning">{{ __('locale.Partially Implemented') }}</span>';
                                case 'Implemented':
                                    return '<span class="badge rounded-pill badge-light-success">{{ __('locale.Implemented') }}</span>';
                                default:
                                    return '<span class="badge rounded-pill badge-light-info">{{ __('locale.No Action') }}</span>';
                            }
                        }
                    },
                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });

            // Handle comment submission
            $('#saveCommentBtn').on('click', function() {
                const commentText = $('#commentInput').val();
                const policyId = $('#consolidatedModal').data('policyId');
                const documentPolicyId = $('#consolidatedModal').data('documentPolicyId');

                if (commentText.trim() === '') {
                    toastr.error('Comment cannot be empty.');
                    return;
                }

                $.ajax({
                    type: 'POST',
                    url: '{{ route('admin.governance.policies.comments.store', ['id' => ':id']) }}'
                        .replace(':id', policyId),
                    data: {
                        comment: commentText,
                        document_policy_id: documentPolicyId,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        toastr.success(response.message);
                        $('#commentInput').val('');
                        fetchComments(policyId, documentPolicyId);
                    },
                    error: function(xhr) {
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            // If backend sent a specific message
                            Swal.fire({
                                title: "Action Not Allowed",
                                text: xhr.responseJSON.message,
                                icon: "error"
                            });
                        } else {
                            // Fallback
                            toastr.error('Error adding comment.');
                        }
                    }
                });
            });


            // Handle file upload
            $('#uploadFileBtn').on('click', function() {
                const description = $('#description').val();
                const fileInput = $('#fileInput')[0];
                const policyId = $('#consolidatedModal').data('policyId');
                const documentPolicyId = $('#consolidatedModal').data('documentPolicyId');

                if (fileInput.files.length === 0) {
                    $('#fileError').text('Please select a file to upload.').show();
                    return;
                } else {
                    $('#fileError').hide();
                }

                const formData = new FormData();
                formData.append('file', fileInput.files[0]);
                formData.append('description', description);
                formData.append('document_policy_id', documentPolicyId);
                formData.append('_token', '{{ csrf_token() }}');

                $.ajax({
                    type: 'POST',
                    url: '{{ route('admin.governance.policies.files.store', ['id' => ':id']) }}'
                        .replace(':id', policyId),
                    data: formData,
                    contentType: false,
                    processData: false,
                    success: function(response) {
                        toastr.success(response.message);
                        $('#description').val('');
                        $('#fileInput').val('');
                        fetchExistingFiles(policyId, documentPolicyId);
                    },
                    error: function(xhr) {
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            Swal.fire({
                                title: "File Upload Error",
                                text: xhr.responseJSON.message,
                                icon: "error"
                            });
                        } else {
                            toastr.error('Error uploading file.');
                        }
                    }
                });
            });

            // Handle status update
            $('#updateStatusBtn').on('click', function() {
                const policyId = $('#consolidatedModal').data('policyId');
                const documentPolicyId = $('#consolidatedModal').data('documentPolicyId');
                const newStatus = $('#statusSelect').val();

                $.ajax({
                    type: 'PATCH',
                    url: '{{ route('admin.governance.policies.status.update', ['id' => ':id']) }}'
                        .replace(':id', policyId),
                    data: {
                        status: newStatus,
                        document_policy_id: documentPolicyId,
                        _token: '{{ csrf_token() }}'
                    },
                    success: function(response) {
                        toastr.success('Status updated successfully.');
                        // $('#consolidatedModal').modal('hide');
                        table.ajax.reload(null, false);
                    },
                    error: function(xhr) {
                        if (xhr.responseJSON.message === "error_evidence_required") {
                            Swal.fire({
                                title: "Action Not Completed",
                                text: "You cannot update the status until you upload evidence.",
                                icon: "error"
                            });
                        } else if (xhr.responseJSON.message ===
                            "You Can not Edit Status Because Auditer Take Action On this") {
                            Swal.fire({
                                title: "Action Not Allowed",
                                text: xhr.responseJSON.message,
                                icon: "warning"
                            });
                        } else {
                            toastr.error('Error updating status.');
                        }
                    }

                });
            });
        });

        $(document).on('click', '.open-consolidated-modal', function() {
            const policyId = $(this).data('policy-id'); // Get policy ID
            const documentPolicyId = $(this).data('document-policy-id'); // Get document policy ID
            const status = $(this).data('status'); // Get current status
            const enabled = $(this).data('enabled'); // Check if audit is enabled

            // Set data in the modal
            $('#consolidatedModal').data('policyId', policyId)
                .data('documentPolicyId', documentPolicyId)
                .data('status', status)
                .data('enabled', enabled);

            // Set the status in the dropdown
            $('#statusSelect').val(status);

            // Fetch comments and files
            fetchComments(policyId, documentPolicyId);
            fetchExistingFiles(policyId, documentPolicyId);

            // Open the modal
            $('#consolidatedModal').modal('show');
        });

        $('#consolidatedModal').on('shown.bs.modal', function() {
            var myTab = new bootstrap.Tab(document.getElementById('edit-status-tab')); // Initialize the Tab object
            myTab.show(); // Show the first tab
        });
        // Clear comment input and comment list when the consolidated modal is closed
        $('#consolidatedModal').on('hidden.bs.modal', function() {
            $('#commentInput').val('');
            $('#commentsList').empty();
        });



        // Function to fetch comments
        function fetchComments(policyId, documentPolicyId) {
            $.ajax({
                type: 'GET',
                url: '{{ route('admin.governance.policies.comments.get', ['id' => ':id']) }}'
                    .replace(':id', policyId),
                data: {
                    document_policy_id: documentPolicyId // Pass documentPolicyId as a query parameter
                },
                success: function(comments) {
                    // Clear the comment list
                    $('#commentsList').empty();

                    // Populate comments in the modal
                    comments.forEach(comment => {
                        // Format the created_at timestamp
                        const sentAt = new Date(comment.created_at).toLocaleString('en-US', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit',
                            hour12: true
                        });

                        // Append each comment with a compact layout and no extra margins
                        $('#commentsList').append(
                            '<li class="list-group-item">' + // Removed any extra margin/padding
                            '<div class="d-flex justify-content-between align-items-start">' +
                            // "Sent at" timestamp on the left
                            '<div class="text-muted small">' +
                            'Sent at: ' + sentAt +
                            '</div>' +
                            // User's name with a badge on the right
                            '<div>' +
                            '<span class="badge bg-primary">' + comment.name + '</span>' +
                            '</div>' +
                            '</div>' +
                            // Comment content below without any extra margin
                            '<div class="">' +
                            comment.comment +
                            '</div>' +
                            '</li>'
                        );
                    });
                },
                error: function() {
                    toastr.error('Error fetching comments.');
                }
            });
        }


        function openEditFileModal(fileId, policyId, description) {
            // Set the file ID and policy ID in the modal
            $('#editFileId').val(fileId);
            $('#editPolicyId').val(policyId);

            // Populate the description field
            $('#editDescription').val(description);

            // Clear the file input
            $('#editFileInput').val('');

            // Open the modal
            $('#editFileModal').modal('show');
        }
        $('#saveEditFileBtn').on('click', function() {
            const fileId = $('#editFileId').val();
            const policyId = $('#editPolicyId').val();
            const description = $('#editDescription').val();
            const fileInput = $('#editFileInput')[0];

            // Validate the description
            // if (description.trim() === '') {
            //     toastr.error('Description is required.');
            //     return;
            // }

            // Prepare form data
            const formData = new FormData();
            formData.append('description', description);
            if (fileInput.files.length > 0) {
                formData.append('file', fileInput.files[0]);
            }
            formData.append('_token', '{{ csrf_token() }}');
            formData.append('_method', 'PUT'); // Simulate a PUT request

            // Log the FormData to the console
            for (let [key, value] of formData.entries()) {
                console.log(key, value);
            }

            // Send the AJAX request
            $.ajax({
                type: 'POST',
                url: '{{ route('admin.governance.policies.files.update', ['policyId' => ':policyId', 'fileId' => ':fileId']) }}'
                    .replace(':policyId', policyId)
                    .replace(':fileId', fileId),
                data: formData,
                contentType: false, // Important for file uploads
                processData: false, // Important for file uploads
                success: function(response) {
                    toastr.success('Evidence updated successfully.');
                    $('#editFileModal').modal('hide');

                    // Access documentPolicyId directly as a plain variable
                    fetchExistingFiles(policyId, response.documentPolicyId); // Refresh the file list
                },
                error: function(xhr) {
                    let errorMessage = 'Error updating evidence.';

                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errorMessage = xhr.responseJSON.message;
                    }

                    toastr.error(errorMessage);
                    console.error(xhr.responseText); // keep logging for debugging
                }
            });
        });

        function fetchExistingFiles(policyId, documentPolicyId) {
            // Clear the existing files list
            $('#existingFilesList').empty();

            // Fetch existing files
            $.ajax({
                type: 'GET',
                url: '{{ route('admin.governance.policies.files.index', ['id' => ':id']) }}'.replace(':id',
                    policyId),
                data: {
                    document_policy_id: documentPolicyId // Pass documentPolicyId as a query parameter
                },
                success: function(response) {
                    // Assuming response is an object with a 'files' array
                    if (response.files.length > 0) {
                        response.files.forEach(file => {
                            const createdAt = new Date(file.created_at);
                            const options = {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                            };
                            const formattedDate = createdAt.toLocaleDateString('en-US', options);

                            // Prepare file link or text based on file path and name
                            let fileLink;
                            if (file.file_path && file.file_name) {
                                fileLink =
                                    '<a href="{{ route('admin.governance.policies.files.download', '') }}/' +
                                    file.file_path + '" download="' + file.file_name + '">' +
                                    file.file_name + '</a>';
                            } else {
                                fileLink = file.file_name ? file.file_name : 'No file available';
                            }

                            // Prepare delete and edit buttons
                            let actionButtons = ''; // Initialize action buttons
                            const enableAudit = $('#enableAudit').val(); // Get the enable_audit value

                            if (enableAudit != 0) { // Only show buttons if enable_audit is not 0

                                const deleteButton = `
                            <button class="btn btn-danger btn-sm" onclick="deleteFile(${file.id}, ${policyId})">
                                Delete
                            </button>
                        `;
                                const editButton = `
                            <button class="btn btn-primary btn-sm" onclick="openEditFileModal(${file.id}, ${policyId}, '${file.description}')">
                                Edit
                            </button>
                        `;
                                actionButtons = '<td>' + editButton + ' ' + deleteButton +
                                    '</td>'; // Wrap buttons in <td>
                            }

                            // Append to the table
                            $('#existingFilesList').append(
                                '<tr>' +
                                '<td>' + file.description + '</td>' +
                                '<td>' + fileLink + '</td>' +
                                '<td>' + formattedDate + '</td>' +
                                actionButtons + // Conditionally add the action buttons <td>
                                '</tr>'
                            );
                        });
                    } else {
                        $('#existingFilesList').append(
                            '<tr><td colspan="4" class="text-center">No files found.</td></tr>'
                        );
                    }
                },
                error: function() {
                    toastr.error('Error fetching existing files.');
                }
            });
        }

        // Delete file function with both fileId and policyId
        function deleteFile(fileId, policyId) {
            // Show a SweetAlert confirmation prompt
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!',
            }).then((result) => {
                if (result.isConfirmed) {
                    // Send an AJAX request to delete the file
                    $.ajax({
                        type: 'DELETE',
                        url: '{{ route('admin.governance.policies.files.destroy', ['policyId' => ':policyId', 'fileId' => ':fileId']) }}'
                            .replace(':policyId', policyId)
                            .replace(':fileId', fileId),
                        success: function(response) {
                            // Show success notification
                            toastr.success('File deleted successfully.');
                            // Reload the files list after deletion
                            fetchExistingFiles(response.policyId, response.documentPolicyId);
                        },
                        error: function(xhr) {
                            // Check for a specific error message from the backend (e.g., status "Implemented")
                            if (xhr.status === 400 && xhr.responseJSON && xhr.responseJSON.message) {
                                Swal.fire({
                                    title: 'Error!',
                                    text: xhr.responseJSON
                                        .message, // Display error message from the server
                                    icon: 'error',
                                    confirmButtonText: 'OK'
                                });
                            } else {
                                // Generic error message if no specific message is found
                                toastr.error('Error deleting the file.');
                            }
                        }
                    });
                }
            });
        }







        $('#exportButton').on('click', function(e) {
            e.preventDefault(); // Prevent default action

            // Define or retrieve documentPolicyId as needed
            var documentPolicyId = $('#audit_id').val(); // Example: Get ID from a dropdown

            // Ensure documentPolicyId is valid
            if (documentPolicyId) {
                // Create a form to submit the download request
                var form = $('<form>', {
                    action: '{{ route('admin.governance.auditDocumentPoliciesexport') }}',
                    method: 'POST',
                    target: '_blank' // Open in a new tab
                });

                // Add CSRF token
                var csrfToken = $('meta[name="csrf-token"]').attr('content');
                form.append($('<input>', {
                    type: 'hidden',
                    name: '_token',
                    value: csrfToken
                }));

                // Add document policy ID to form
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'document_policy_id',
                    value: documentPolicyId
                }));

                // Optionally add a type if needed
                // form.append($('<input>', { type: 'hidden', name: 'type', value: 'xlsx' })); // if needed

                // Submit the form
                form.appendTo('body').submit().remove(); // Submit the form and remove it
            } else {
                alert("Please select a document policy to export.");
            }
        });

        $('#importForm').on('submit', function(e) {
            e.preventDefault();

            var formData = new FormData(this);

            $.ajax({
                url: '{{ route('admin.governance.importStatusAndCommentToAudit') }}',
                method: 'POST',
                data: formData,
                contentType: false,
                processData: false,

                // Show block UI before sending the request
                beforeSend: function() {
                    $.blockUI({
                        message: '<div class="d-flex justify-content-center align-items-center"><p class="me-50 mb-0">{{ __('locale.PleaseWaitAction', ['action' => __('importing')]) }}</p> <div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                        css: {
                            backgroundColor: 'transparent',
                            color: '#fff',
                            border: '0'
                        },
                        overlayCSS: {
                            opacity: 0.5
                        }
                    });
                },

                // Unblock UI after the request is complete
                complete: function() {
                    $.unblockUI();
                },

                success: function(response) {
                    toastr.success('Action completed successfully.');
                    $('#importModal').modal('hide');
                    location.reload();
                },

                error: function(xhr, status, error) {
                    // Clear previous errors
                    $('#importModal .modal-body').find('.alert').remove();

                    // Display general error message
                    let generalErrorMessage = `
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong><i class="fas fa-exclamation-circle"></i> Oops!</strong> 
                    An issue has occurred during the manipulation of the Excel file. 
                    Kindly download the appropriate template and complete it as required.
                </div>
            `;

                    $('#importModal .modal-body').append(generalErrorMessage);

                    // Display validation errors if available
                    if (xhr.responseJSON && xhr.responseJSON.failures) {
                        let errorList = xhr.responseJSON.failures.map(failure => {
                            return `<li>Row ${failure.row}: ${failure.errors.join(', ')}</li>`;
                        }).join('');

                        let validationErrorMessage = `
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong><i class="fas fa-exclamation-triangle"></i> Validation Errors:</strong>
                        <ul>${errorList}</ul>
                    </div>
                `;
                        $('#importModal .modal-body').append(validationErrorMessage);
                    }
                }
            });
        });

        $(document).ready(function() {
            $('#SendResult').on('click', function() {
                let id = $(this).data('id'); // Get the ID from the button's data-id attribute

                // Block the UI to show loading indicator
                $.blockUI({
                    message: '<div class="d-flex justify-content-center align-items-center"><p class="me-50 mb-0">{{ __('locale.PleaseWaitAction', ['action' => __('importing')]) }}</p> <div class="spinner-grow spinner-grow-sm text-white" role="status"></div> </div>',
                    css: {
                        backgroundColor: 'transparent',
                        color: '#fff',
                        border: '0'
                    },
                    overlayCSS: {
                        opacity: 0.5
                    }
                });

                $.ajax({
                    url: "{{ route('admin.governance.sendResultAudit') }}", // Route URL
                    type: "POST", // HTTP method
                    data: {
                        _token: "{{ csrf_token() }}", // CSRF token for security
                        id: id // Sending the ID to the backend
                    },
                    success: function(response) {
                        // Handle success response
                        $('#AduitDocumentpoliciesTable').DataTable().ajax.reload();

                        toastr.success(response.message || 'Action completed successfully.');

                        // Update the icon based on checkSendResult value
                        if (response.checkSendResult) {
                            // Show check icon if result is sent
                            $('.check-send-result').html(
                                '<i class="fas fa-check mx-1 text-success"></i>');
                        } else {
                            // Show error icon if result is not sent
                            $('.check-send-result').html(
                                '<i class="fas fa-times mx-1 text-danger"></i>');
                        }

                        // Unblock the UI after success
                        $.unblockUI();
                    },
                    error: function(xhr, status, error) {
                        // Handle error response
                        if (xhr.status === 422) {
                            // Parse the error response if it's JSON
                            let errorMessage = xhr.responseJSON && xhr.responseJSON.message ?
                                xhr.responseJSON.message :
                                'An error occurred while processing your request.';

                            // Show the error message using SweetAlert or Toastr
                            if (xhr.responseJSON && xhr.responseJSON.message && xhr.responseJSON
                                .message.includes('error_evidence_required_for_')) {
                                // If it's an evidence required error, show a more specific message
                                Swal.fire({
                                    title: "Action Not Completed",
                                    text: `Evidence is required for document policy Name: ${xhr.responseJSON.message.split('_')[4]}`,
                                    icon: "error", // Correct icon for error messages
                                    buttons: true,
                                    dangerMode: true,
                                });
                            } else {
                                // Generic error handling
                                Swal.fire({
                                    title: "Action Not Completed",
                                    text: errorMessage,
                                    icon: "error", // Correct icon for error messages
                                    buttons: true,
                                    dangerMode: true,
                                });
                            }
                        } else {
                            // Generic error handler for other statuses
                            toastr.error('Error updating status.');
                        }

                        // Unblock the UI after error
                        $.unblockUI();
                    }
                });
            });
        });
    </script>
@endsection