<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RisksToAsset extends Model
{
    use HasFactory;

    public $timestamps = false;

    public $guarded = [];
    public function asset()
    {
        return $this->belongsTo(Asset::class, 'asset_id');
    }
}
