<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // For MySQL: must use raw SQL to change ENUM to VARCHAR
        // because Blueprint doesn't support changing enum columns directly

        DB::statement("ALTER TABLE change_requests MODIFY COLUMN status VARCHAR(255) NOT NULL");
        DB::statement("ALTER TABLE change_requests MODIFY COLUMN review_cycle VARCHAR(255) NOT NULL");
    }

    /**
     * Reverse the migrations.
     * 
     * Restore original ENUM values based on your original migration.
     * Update the enum values below to match your original schema exactly.
     */
    public function down(): void
    {
        DB::statement("
            ALTER TABLE change_requests 
            MODIFY COLUMN status ENUM(
                'Department-Manager-In-Review',
                'Department-Manager-Rejected',
                'Responsible-Department-In-Review',
                'Responsible-Department-Accepted',
                'Responsible-Department-Rejected'
            ) NOT NULL
        ");

        DB::statement("
            ALTER TABLE change_requests 
            MODIFY COLUMN review_cycle ENUM(
                'Department-Manager-Review',
                'Responsible-Department-Review'
            ) NOT NULL
        ");
    }
};