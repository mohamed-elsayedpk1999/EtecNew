<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('actions')->insert([
            [
                'id' => 145,
                'name' => 'policy_adoption_add',
            ],
            [
                'id' => 146,
                'name' => 'policy_adoption_update',
            ],
            [
                'id' => 147,
                'name' => 'policy_adoption_delete',
            ],
            [
                'id' => 148,
                'name' => 'policy_adoption_change_status',
            ],
        ]);
    }

    public function down(): void
    {
        DB::table('actions')
            ->whereIn('id', [145, 146, 147, 148])
            ->delete();
    }
};