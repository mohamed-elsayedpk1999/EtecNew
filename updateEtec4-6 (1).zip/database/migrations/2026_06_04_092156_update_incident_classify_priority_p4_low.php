<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('incident_classifies')
            ->where('value', 4)
            ->update([
                'priority' => 'P4 (Low)',
                'description' => 'P4 (Low): Description',
            ]);
    }

    public function down(): void
    {
        DB::table('incident_classifies')
            ->where('value', 4)
            ->update([
                'priority' => 'P1 (Critical)',
                'description' => 'P4 (Low): Description',
            ]);
    }
};