<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::table('incident_classifies')
            ->where('value', 20)
            ->update([
                'priority' => 'P1 (Critical)',
                'color' => '#ff0000',
                'description' => 'P1 (Critical): Description',
            ]);

        DB::table('incident_classifies')
            ->where('value', 14)
            ->update([
                'priority' => 'P2 (High)',
                'color' => '#ff8c00',
                'description' => 'P2 (High): Description',
            ]);

        DB::table('incident_classifies')
            ->where('value', 9)
            ->update([
                'priority' => 'P3 (Medium)',
                'color' => '#e6ca3d',
                'description' => 'P3 (Medium): Description',
            ]);

        DB::table('incident_classifies')
            ->where('value', 4)
            ->update([
                'priority' => 'P4 (Low)',
                'color' => '#00c732',
                'description' => 'P4 (Low): Description',
            ]);
    }

    public function down(): void
    {
        DB::table('incident_classifies')
            ->where('value', 20)
            ->update([
                'priority' => 'P1 (Critical)',
                'color' => '#00c732',
            ]);

        DB::table('incident_classifies')
            ->where('value', 14)
            ->update([
                'priority' => 'P2 (High)',
                'color' => '#b8b8b7',
            ]);

        DB::table('incident_classifies')
            ->where('value', 9)
            ->update([
                'priority' => 'P3 (Medium)',
                'color' => '#e6ca3d',
            ]);

        DB::table('incident_classifies')
            ->where('value', 4)
            ->update([
                'priority' => 'P1 (Critical)',
                'color' => '#ff0000',
            ]);
    }
};