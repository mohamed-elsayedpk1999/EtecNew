<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PolicyAdoptionConfig extends Model
{
    use HasFactory;

    protected $fillable = [
        'rapporteurs',
    ];

    // Relations
    public function policyAdoption()
    {
        return $this->belongsTo(PolicyAdoption::class);
    }
}