@extends('admin/layouts/contentLayoutMaster')

@section('title', __('locale.qualysAuthentication'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset('cdn/all.min.css') }}">

    {{--
<link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}"> --}}
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/base/plugins/forms/pickers/form-flat-pickr.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">

@endsection


<style>
    .qualys-auth-page .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 12px;
    }

    .qualys-auth-page .card-header .card-title {
        margin: 0;
    }

    .qualys-auth-actions {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 10px;
    }

    .qualys-auth-page label {
        font-size: 1rem !important;
        font-weight: bold;
        color: #000000;
    }

    .qualys-schedule-badge {
        background: #eef7f8;
        color: #0097a7;
        border: 1px solid #c5e6ea;
        border-radius: 999px;
        padding: 6px 12px;
        font-size: 0.85rem;
        font-weight: 600;
    }

    .qualys-auth-actions .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        height: 40px;
        padding: 0 16px;
        border-radius: 8px;
        white-space: nowrap;
        font-weight: 600;
        line-height: 1;
    }

    .qualys-auth-actions .btn i {
        font-size: 14px;
    }


    .qualys-status-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    .qualys-status-running {
        background: #fff4d6;
        color: #b78103;
    }

    .qualys-status-completed {
        background: #e7f6ec;
        color: #1b7a3d;
    }

    .qualys-status-failed {
        background: #fde8e8;
        color: #c62828;
    }

    .qualys-progress {
        display: flex;
        align-items: center;
        min-width: 160px;
    }

    .qualys-progress-bar {
        width: 100%;
        height: 10px;
        background-color: #f0f0f0;
        border-radius: 5px;
        overflow: hidden;
        margin-right: 10px;
    }

    .qualys-progress-bar > div {
        height: 100%;
    }
</style>
@section('content')
    @php
        $scheduleSummary = '';
        if (isset($schedule) && $schedule->time_schedule) {
            if ($schedule->time_schedule == 'daily') {
                $scheduleSummary = __('locale.Daily') . ' @ ' . ($schedule->due_time ?? '');
            } elseif ($schedule->time_schedule == 'weekly') {
                $scheduleSummary = __('locale.Weekly') . ' ' . ($schedule->due_weekly_day ?? '') . ' @ ' . ($schedule->due_weekly_time ?? '');
            } elseif ($schedule->time_schedule == 'monthly') {
                $scheduleSummary = __('locale.Monthly') . ' ' . ($schedule->date_monthly ?? '');
            }
        }
    @endphp
    <div class="misc-wrapper qualys-auth-page">
        <div class="misc-inner p-2 p-sm-3">
            <div class="w-100">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">{{ __('locale.qualysAuthentication') }}</h4>
                        <div class="qualys-auth-actions">
                            @if ($scheduleSummary)
                                <span class="qualys-schedule-badge">{{ $scheduleSummary }}</span>
                            @endif
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                data-bs-target="#ScheduledVulnerability">
                                <i class="fa-regular fa-clock"></i>
                                {{ __('locale.ScheduledVulnerability') }}
                            </button>
                            <button type="button" class="btn btn-primary" id="qualys-sync-assets-btn">
                                <i class="fa-solid fa-server"></i>
                                {{ __('locale.FetchQualysAssets') }}
                            </button>
                            <button type="button" class="btn btn-primary" id="qualys-sync-asset-groups-btn">
                                <i class="fa-solid fa-layer-group"></i>
                                {{ __('locale.FetchQualysAssetGroups') }}
                            </button>
                            <button type="button" class="btn btn-primary" id="qualys-sync-btn">
                                <i class="fa-solid fa-bug"></i>
                                {{ __('locale.FetchQualysVulnerabilities') }}
                            </button>
                        </div>
                    </div>
                    <form class="d-none" id="AddSyncAssets"
                        action="{{ route('admin.configure.qualysApplySyncAssets.store') }}" method="POST">
                        @csrf
                    </form>
                    <form class="d-none" id="AddSyncAssetGroups"
                        action="{{ route('admin.configure.qualysApplySyncAssetGroups.store') }}" method="POST">
                        @csrf
                    </form>
                    <form class="d-none" id="AddSync"
                        action="{{ route('admin.configure.qualysApplySync.store') }}" method="POST">
                        @csrf
                    </form>

                    <div class="card-body">
                        <form class="form form-vertical" id="add-qualys-auth-form"
                            action="{{ route('admin.configure.qualys_auth.store') }}" method="POST">
                            @csrf
                            <div class="row">


                                <div class="col-6">
                                    <div class="mb-1">
                                        <label class="form-label"
                                            for="first-name-icon">{{ __('locale.Username') }}</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="fa-solid fa-key"></i></span>
                                            <input type="text" id="qualys-username" class="form-control"
                                                name="username" placeholder="{{ __('locale.Username') }}"
                                                autocomplete="off" />
                                        </div>
                                        <span class="error error-username"></span>
                                    </div>
                                </div>
                                <input type="hidden" value="1" name='id'>
                                <div class="col-6">
                                    <div class="mb-1">
                                        <label class="form-label"
                                            for="first-name-icon">{{ __('locale.Password') }}</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text">🔐</span>
                                            <input type="password" id="qualys-password" class="form-control"
                                                name="password" placeholder="********"
                                                autocomplete="new-password" />
                                        </div>
                                        <span class="error error-password"></span>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="mb-1">
                                        <label class="form-label" for="first-name-icon">{{ __('locale.ApiUrl') }}</label>
                                        <div class="input-group input-group-merge">
                                            <span class="input-group-text"><i class="fa-solid fa-link"></i></span>
                                            <input type="text" id="first-name-icon" class="form-control" name="api_url"
                                                placeholder=" https://api.example.com/data"
                                                value="{{ $qualysAuth ? $qualysAuth->api_url : '' }}"
                                                autocomplete="false" />
                                        </div>
                                        <span class="error error-api_url"></span>
                                    </div>
                                </div>


                                {{-- for vuln with assets --}}
                                <input type="hidden" value="0" name='offset'>
                                <input type="hidden" value="500" name='end'>
                                <input type="hidden" value="1" name='total'>



                                <div class="col-12 text-center mt-1">
                                    <button type="submit"
                                        class="btn btn-primary me-1">{{ __('locale.Submit') }}</button>
                                    <button type="reset"
                                        class="btn btn-outline-secondary">{{ __('locale.Reset') }}</button>
                                </div>
                            </div>
                        </form>

                        <div class="card-datatable mt-4 qualys-history-wrap">
                            <table id="data-table" class="dt-advanced-server-search table">
                                <thead>
                                    <tr>
                                        <th>{{ __('locale.Type') }}</th>
                                        <th>{{ __('locale.CreatedAt') }}</th>
                                        <th>{{ __('locale.Percentage') }}</th>
                                    </tr>
                                </thead>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" aria-hidden="true" id="ScheduledVulnerability">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-transparent">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-2 px-md-5 pb-3">
                    <div class="text-center mb-4">
                        <h1 class="role-title">{{ __('locale.AddSchedule') }}</h1>
                    </div>
                    <!-- Evidence form -->
                    <form class="row addObjectiveToControlForm" id="AddSchedule"
                        action="{{ route('admin.configure.qualys_scedule.store') }}" method="POST"
                        onsubmit="return false" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" value="1" name='idSchedule'>

                        <div class="col-12">
                            {{-- Responsible Type --}}
                            <div class="col-12">
                                {{-- Time Schedule --}}
                                <div class="mb-1">
                                    <label for="title" class="form-label">{{ __('locale.TimeSchedule') }}</label>
                                    <div class="mb-1 demo-inline-spacing">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="time_schedule"
                                                id="daily" value="daily"
                                                {{ isset($schedule) && $schedule->time_schedule == 'daily' ? 'checked' : '' }} />
                                            <label class="form-check-label"
                                                for="daily">{{ __('locale.Daily') }}</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="time_schedule"
                                                id="weekly" value="weekly"
                                                {{ isset($schedule) && $schedule->time_schedule == 'weekly' ? 'checked' : '' }} />
                                            <label class="form-check-label"
                                                for="weekly">{{ __('locale.Weekly') }}</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="radio" name="time_schedule"
                                                id="monthly" value="monthly"
                                                {{ isset($schedule) && $schedule->time_schedule == 'monthly' ? 'checked' : '' }} />
                                            <label class="form-check-label"
                                                for="monthly">{{ __('locale.Monthly') }}</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            {{-- Daily Container --}}
                            <div class="mt-1 col-12" id="dueDailyContainer">
                                {{-- due date --}}
                                <div class="mb-0 d-flex align-items-center">
                                    <input type="time" name="due_time" class="form-control time-input"
                                        placeholder="Select Time" value="{{ $schedule->due_time ?? '' }}"
                                        step="any" />
                                    <span class="error error-due_time"></span>
                                </div>
                            </div>

                            {{-- Weekly Container --}}
                            <div class="col-12" id="dueWeakContainer">
                                <div class="mb-0 d-flex align-items-center">
                                    <select name="due_weekly_day" class="form-select me-3">
                                        <option value="">{{ __('locale.Select') }}</option>
                                        <option value="Saturday" @if (isset($schedule) && $schedule->due_weekly_day == 'Saturday') selected @endif>
                                            {{ __('locale.Saturday') }}</option>
                                        <option value="Sunday" @if (isset($schedule) && $schedule->due_weekly_day == 'Sunday') selected @endif>
                                            {{ __('locale.Sunday') }}</option>
                                        <option value="Monday" @if (isset($schedule) && $schedule->due_weekly_day == 'Monday') selected @endif>
                                            {{ __('locale.Monday') }}</option>
                                        <option value="Tuesday" @if (isset($schedule) && $schedule->due_weekly_day == 'Tuesday') selected @endif>
                                            {{ __('locale.Tuesday') }}</option>
                                        <option value="Wednesday" @if (isset($schedule) && $schedule->due_weekly_day == 'Wednesday') selected @endif>
                                            {{ __('locale.Wednesday') }}</option>
                                        <option value="Thursday" @if (isset($schedule) && $schedule->due_weekly_day == 'Thursday') selected @endif>
                                            {{ __('locale.Thursday') }}</option>
                                        <option value="Friday" @if (isset($schedule) && $schedule->due_weekly_day == 'Friday') selected @endif>
                                            {{ __('locale.Friday') }}</option>
                                    </select>
                                    <input type="time" name="due_weekly_time" class="form-control time-input"
                                        placeholder="Select Time"
                                        value="{{ isset($schedule) ? $schedule->due_weekly_time : '' }}"
                                        step="any" />

                                    <span class="error error-due_weekly_day"></span>
                                </div>
                            </div>

                        </div>
                        <div class="col-12" id="dueMonthlyContainer">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.SpecificDateAndTime') }}</label>
                                <input type="text" name="date_monthly"
                                    class="form-control flatpickr-date-time-compliance" placeholder="Select Date and Time"
                                    data-enable-time="true"
                                    value="{{ isset($schedule) ? $schedule->date_monthly : '' }}" />
                                <span class="error error-date_monthly"></span>
                            </div>
                        </div>

                        <div class="col-12 text-center mt-2">
                            <button type="Submit" class="btn btn-primary me-1"> {{ __('locale.Submit') }}</button>
                            <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                                {{ __('locale.Cancel') }}</button>
                        </div>
                    </form>
                    <!--/ Evidence form -->
                </div>
            </div>
        </div>
    </div>
    <!-- / Not authorized-->
@endsection
@section('vendor-script')
    <script src="{{ asset('cdn/jquery-3.6.4.min.js') }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
    {{-- <script src="{{ asset(mix('vendors/js/tables/datatable/buttons.html5.min.js')) }}"></script> --}}
    <script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>

    <script src="{{ asset('cdn/2.1.4toastr.min.js') }}"></script>


    <script src="{{ asset('cdn/picker.js') }}"></script>
    <script src="{{ asset('cdn/picker.date.js') }}"></script>

@endsection

@section('page-script')
    <script>
        var qualysHistoryTable = $('#data-table').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: "{{ route('admin.configure.qualysSyncHistory') }}",
                type: "POST",
                data: function(data) {
                    data._token = $('meta[name="csrf-token"]').attr('content');
                }
            },
            columns: [
                { data: 'type', name: 'type' },
                { data: 'created_at', name: 'created_at' },
                { data: 'percentage', name: 'percentage', orderable: false, searchable: false }
            ],
            order: [[1, 'desc']],
            language: {
                paginate: {
                    previous: '&nbsp;',
                    next: '&nbsp;'
                },
                emptyTable: "{{ __('locale.emptyTable') }}",
                info: "{{ __('locale.info') }}",
                infoEmpty: "{{ __('locale.infoEmpty') }}",
                infoFiltered: "{{ __('locale.infoFiltered') }}",
                lengthMenu: "{{ __('locale.lengthMenu') }}",
                loadingRecords: "{{ __('locale.loadingRecords') }}",
                search: "{{ __('locale.search') }}",
                zeroRecords: "{{ __('locale.zeroRecords') }}",
                processing: "{{ __('locale.Processing') }}"
            }
        });

        function refreshQualysSyncHistory() {
            if (qualysHistoryTable) {
                qualysHistoryTable.ajax.reload(null, false);
            }
        }

        $('#qualys-sync-assets-btn').on('click', function() {
            $('#AddSyncAssets').trigger('submit');
        });
        $('#qualys-sync-asset-groups-btn').on('click', function() {
            $('#AddSyncAssetGroups').trigger('submit');
        });
        $('#qualys-sync-btn').on('click', function() {
            $('#AddSync').trigger('submit');
        });

        $('#add-qualys-auth-form').on('submit', function(e) {
            e.preventDefault();
            var data = new FormData(this),
                url = $(this).attr('action');

            var csrfToken = $('meta[name="csrf-token"]').attr('content');
            data.set('_token', csrfToken);

            $.ajax({
                type: "post",
                url: url,
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.status === true) {
                        makeAlert('success', 'Data inserted successfully', 'Success');
                    } else {
                        makeAlert('error', response.message);
                    }
                },
                error: function() {
                    makeAlert('error', 'An error occurred during the request.');
                }
            });
        });

        function makeAlert($status, message, title) {
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false
            });
        };
    </script>
    <script>
        $('#AddSchedule').on('submit', function(e) {
            e.preventDefault();
            var data = new FormData(this),
                url = $(this).attr('action');
            $.ajax({
                type: "post",
                url: url,
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    // Check the response for success or failure
                    if (response.status === true) {
                        makeAlert('success', 'Schedule inserted successfully', 'Success');
                        $('#ScheduledVulnerability').modal('hide');
                        setTimeout(function() {
                            window.location.reload();
                        }, 800);
                    } else {
                        makeAlert('error', response.message);
                    }
                },
                error: function() {
                    // Handle error as needed
                    makeAlert('error', 'An error occurred during the request.');
                }
            });
        });
        $('#AddSync').on('submit', function(e) {
            e.preventDefault();
            var data = new FormData(this),
                url = $(this).attr('action');
            $.ajax({
                type: "POST",
                url: url,
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.status === true) {
                        makeAlert('success', response.message || 'Qualys vulnerability sync started in background', 'Success');
                        refreshQualysSyncHistory();
                    } else {
                        makeAlert('error', response.message);
                    }
                },
                error: function() {
                    makeAlert('error', 'An error occurred during the request.');
                }
            });
        });
        $('#AddSyncAssets').on('submit', function(e) {
            e.preventDefault();
            var data = new FormData(this),
                url = $(this).attr('action');
            $.ajax({
                type: "POST",
                url: url,
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.status === true) {
                        makeAlert('success', response.message || 'Qualys asset sync started in background', 'Success');
                        refreshQualysSyncHistory();
                    } else {
                        makeAlert('error', response.message);
                    }
                },
                error: function() {
                    makeAlert('error', 'An error occurred during the request.');
                }
            });
        });
        $('#AddSyncAssetGroups').on('submit', function(e) {
            e.preventDefault();
            var data = new FormData(this),
                url = $(this).attr('action');
            $.ajax({
                type: "POST",
                url: url,
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(response) {
                    if (response.status === true) {
                        makeAlert('success', response.message || 'Qualys asset group sync started in background', 'Success');
                        refreshQualysSyncHistory();
                    } else {
                        makeAlert('error', response.message);
                    }
                },
                error: function() {
                    makeAlert('error', 'An error occurred during the request.');
                }
            });
        });
        function makeAlert($status, message, title) {
            // On load Toast
            if (title == 'Success')
                title = '👋' + title;
            toastr[$status](message, title, {
                closeButton: true,
                tapToDismiss: false
            });
        };
    </script>


    <script>
        flatpickr('.flatpickr-date-time-compliance', {
            enableTime: true,
            dateFormat: "Y-m-d H:i", // Specify the date format
            onClose: function(selectedDates, dateStr, instance) {
                // Close the datepicker
                instance.close();
            }
        });
    </script>
    <script>
        $(document).ready(function() {
            // Initially hide the containers using CSS
            $('#dueDailyContainer, #dueWeakContainer, #dueMonthlyContainer').hide();

            // Function to reset values in all containers
            function resetAllContainers() {
                resetContainer($('#dueDailyContainer'));
                resetContainer($('#dueWeakContainer'));
                resetContainer($('#dueMonthlyContainer'));
            }

            // Function to reset values in the container
            function resetContainer(container) {
                container.find('input[type=text]').val('');
                container.find('input[type=time]').val('');
                container.find('select').val('');
                // Add other fields to reset if needed
            }

            // Check the radio based on the value from the database
            @if (isset($schedule->time_schedule) && $schedule->time_schedule == 'daily')
                $('#daily').prop('checked', true);
                $('#dueDailyContainer').slideDown();
            @elseif (isset($schedule->time_schedule) && $schedule->time_schedule == 'weekly')
                $('#weekly').prop('checked', true);
                $('#dueWeakContainer').slideDown();
            @elseif (isset($schedule->time_schedule) && $schedule->time_schedule == 'monthly')
                $('#monthly').prop('checked', true);
                $('#dueMonthlyContainer').slideDown();
            @endif

            // When the daily radio is clicked
            $('#daily').on('change', function() {
                if ($(this).is(':checked')) {
                    // Reset values in the other containers
                    resetContainer($('#dueWeakContainer'));
                    resetContainer($('#dueMonthlyContainer'));
                    // If checked, slide down dueDailyContainer and hide others
                    $('#dueDailyContainer').slideDown();
                    $('#dueWeakContainer, #dueMonthlyContainer').slideUp();
                }
            });

            // When the weekly radio is clicked
            $('#weekly').on('change', function() {
                if ($(this).is(':checked')) {
                    // Reset values in the other containers
                    resetContainer($('#dueDailyContainer'));
                    resetContainer($('#dueMonthlyContainer'));
                    // If checked, slide down dueWeakContainer and hide others
                    $('#dueWeakContainer').slideDown();
                    $('#dueDailyContainer, #dueMonthlyContainer').slideUp();
                }
            });

            // When the monthly radio is clicked
            $('#monthly').on('change', function() {
                if ($(this).is(':checked')) {
                    // Reset values in the other containers
                    resetContainer($('#dueDailyContainer'));
                    resetContainer($('#dueWeakContainer'));
                    // If checked, slide down dueMonthlyContainer and hide others
                    $('#dueMonthlyContainer').slideDown();
                    $('#dueDailyContainer, #dueWeakContainer').slideUp();
                }
            });
        });
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            flatpickr('.time-input', {
                enableTime: true,
                noCalendar: true,
                dateFormat: "H:i",
                time_24hr: true
            });
        });
    </script>



@endsection
