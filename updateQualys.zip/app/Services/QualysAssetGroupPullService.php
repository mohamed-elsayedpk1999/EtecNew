<?php

namespace App\Services;

use App\Jobs\SyncQualysAssetGroupsJob;
use App\Models\QualysAuth;
use App\Models\QualysSyncHistory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;

class QualysAssetGroupPullService
{
    public const DEFAULT_QUALYS_BASE_URL = 'https://qualysapi.qg1.apps.qualysksa.com';

    public const FO_ASSET_GROUP_PATH = '/api/2.0/fo/asset/group/';

    protected $baseUrl;

    protected $username;

    protected $password;

    public function __construct()
    {
        $setting = QualysAuth::first();
        $this->username = $setting ? $setting->username : null;
        $this->password = $setting ? $setting->password : null;
        $apiUrl = $setting ? trim($setting->api_url ?? '') : '';
        $this->baseUrl = $apiUrl !== '' ? rtrim($apiUrl, '/') : self::DEFAULT_QUALYS_BASE_URL;
    }

    /**
     * Controller entry: pull all Qualys asset groups, then dispatch insert.
     *
     * @return array{ok: bool, skipped?: bool, history_id?: int, message?: string}
     */
    public function start(): array
    {
        if (QualysSyncHistory::where('type', 'Asset Group')->where('status', 1)->exists()) {
            return [
                'ok' => true,
                'skipped' => true,
                'message' => 'A Qualys asset group sync is already running. Please wait until it finishes.',
            ];
        }

        $history = QualysSyncHistory::create([
            'type' => 'Asset Group',
            'processed' => 0,
            'total' => null,
            'imported' => 0,
            'failed' => 0,
            'status' => 1,
        ]);

        try {
            set_time_limit(0);
            $rows = $this->collectAll($history);
            dispatch(new SyncQualysAssetGroupsJob($history->id, $rows));
        } catch (\Throwable $e) {
            $history->update([
                'status' => 2,
                'error' => mb_substr($e->getMessage(), 0, 1000),
            ]);
            throw $e;
        }

        return [
            'ok' => true,
            'skipped' => false,
            'history_id' => $history->id,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function collectAll(QualysSyncHistory $history): array
    {
        $allRows = [];
        $lastId = 0;
        $pageSize = 100;
        $maxPages = 50000;

        for ($page = 1; $page <= $maxPages; $page++) {
            $pageData = $this->fetchPage($lastId, $pageSize);

            if ($pageData['rows'] !== []) {
                $allRows = array_merge($allRows, $pageData['rows']);
            }

            $history->update([
                'processed' => count($allRows),
                'total' => count($allRows),
            ]);

            if ($pageData['done']) {
                break;
            }
            $lastId = $pageData['last_id'];
        }

        $history->update([
            'processed' => count($allRows),
            'total' => count($allRows),
        ]);

        return $allRows;
    }

    /**
     * @return array{rows: array<int, array<string, mixed>>, last_id: int, done: bool}
     */
    protected function fetchPage(int $lastId, int $pageSize = 100): array
    {
        $idMin = $lastId > 0 ? $lastId + 1 : 1;
        $response = $this->qualysApi()->get($this->url(self::FO_ASSET_GROUP_PATH), [
            'action' => 'list',
            'truncation_limit' => $pageSize,
            'id_min' => $idMin,
            'show_attributes' => 'ALL',
        ]);

        if (!$response->successful()) {
            throw new \RuntimeException('Qualys asset group list page failed: HTTP ' . $response->status());
        }

        $xml = @simplexml_load_string($response->body());
        if ($xml === false) {
            throw new \RuntimeException('Qualys asset group list page returned invalid XML');
        }

        $empty = [
            'rows' => [],
            'last_id' => $lastId,
            'done' => true,
        ];

        if (!isset($xml->RESPONSE->ASSET_GROUP_LIST->ASSET_GROUP)) {
            return $empty;
        }

        $groups = $xml->RESPONSE->ASSET_GROUP_LIST->ASSET_GROUP;
        $groupList = isset($groups->ID) ? [$groups] : iterator_to_array($groups, false);
        if ($groupList === []) {
            return $empty;
        }

        $maxId = $lastId;
        $rows = [];
        foreach ($groupList as $group) {
            $groupId = (int) ($group->ID ?? 0);
            if ($groupId > $maxId) {
                $maxId = $groupId;
            }
            $row = $this->mapGroupToRow($group);
            if ($row !== null) {
                $rows[] = $row;
            }
        }

        return [
            'rows' => $rows,
            'last_id' => $maxId,
            'done' => $maxId <= $lastId || count($groupList) < $pageSize,
        ];
    }

    /**
     * @return array<string, mixed>|null
     */
    protected function mapGroupToRow($group): ?array
    {
        $id = $this->xmlText($group, 'ID');
        $title = $this->xmlText($group, 'TITLE');
        if ($id === '' && $title === '') {
            return null;
        }

        return [
            'qualys_id' => $id,
            'title' => $title,
            'host_ids' => $this->xmlHostIds($group),
            'ips' => $this->xmlIps($group),
            'ip_ranges' => $this->xmlIpRanges($group),
        ];
    }

    /**
     * @return array<int, string>
     */
    protected function xmlHostIds($group): array
    {
        $ids = [];
        if (!isset($group->HOST_IDS)) {
            return $ids;
        }

        $hostIds = $group->HOST_IDS;
        if (isset($hostIds->ID)) {
            foreach ($hostIds->ID as $node) {
                $id = trim((string) $node);
                if ($id !== '') {
                    $ids[] = $id;
                }
            }
        } else {
            foreach (preg_split('/\s*,\s*/', trim((string) $hostIds)) as $id) {
                if ($id !== '') {
                    $ids[] = $id;
                }
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return array<int, string>
     */
    protected function xmlIps($group): array
    {
        $ips = [];
        if (!isset($group->IP_SET->IP)) {
            return $ips;
        }

        $nodes = $group->IP_SET->IP;
        foreach ($nodes as $node) {
            $ip = trim((string) $node);
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ips[] = $ip;
            }
        }

        return array_values(array_unique($ips));
    }

    /**
     * @return array<int, array{start: string, end: string}>
     */
    protected function xmlIpRanges($group): array
    {
        $ranges = [];
        if (!isset($group->IP_SET->IP_RANGE)) {
            return $ranges;
        }

        $nodes = $group->IP_SET->IP_RANGE;
        $list = isset($nodes->START) ? [$nodes] : $nodes;
        foreach ($list as $node) {
            $start = trim((string) ($node->START ?? ''));
            $end = trim((string) ($node->END ?? ''));
            if (filter_var($start, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && filter_var($end, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
                $ranges[] = ['start' => $start, 'end' => $end];
            }
        }

        return $ranges;
    }

    protected function qualysApi(): PendingRequest
    {
        return Http::withHeaders([
            'X-Requested-With' => 'Curl Sample',
        ])
            ->withBasicAuth($this->username, $this->password)
            ->timeout(600);
    }

    protected function url(string $path): string
    {
        return $this->baseUrl . (isset($path[0]) && $path[0] === '/' ? $path : '/' . $path);
    }

    protected function xmlText($node, string $name): string
    {
        if ($node === null || !isset($node->{$name})) {
            return '';
        }

        return trim((string) $node->{$name});
    }
}
