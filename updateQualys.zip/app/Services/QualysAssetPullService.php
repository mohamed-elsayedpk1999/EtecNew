<?php

namespace App\Services;

use App\Jobs\SyncQualysAssetsJob;
use App\Models\QualysAuth;
use App\Models\QualysSyncHistory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;

class QualysAssetPullService
{
    public const DEFAULT_QUALYS_BASE_URL = 'https://qualysapi.qg1.apps.qualysksa.com';

    public const FO_HOST_LIST_PATH = '/api/2.0/fo/asset/host/';

    protected $baseUrl;

    protected $username;

    protected $password;

    public function __construct()
    {
        $setting = QualysAuth::first();
        $this->username = $setting ? $setting->username : null;
        $this->password = $setting ? $setting->password : null;
        $apiUrl = $setting ? trim($setting->api_url ?? '') : '';
        $this->baseUrl = $apiUrl !== '' ? rtrim($apiUrl, '/') : self::DEFAULT_QUALYS_BASE_URL;
    }

    /**
     * Controller / artisan entry: pull all Qualys hosts, then dispatch insert.
     *
     * @return array{ok: bool, skipped?: bool, history_id?: int, message?: string}
     */
    public function start(): array
    {
        if (QualysSyncHistory::where('type', 'Asset')->where('status', 1)->exists()) {
            return [
                'ok' => true,
                'skipped' => true,
                'message' => 'A Qualys asset sync is already running. Please wait until it finishes.',
            ];
        }

        $history = QualysSyncHistory::create([
            'type' => 'Asset',
            'processed' => 0,
            'total' => null,
            'imported' => 0,
            'failed' => 0,
            'status' => 1,
        ]);

        try {
            set_time_limit(0);
            $rows = $this->collectAll($history);
            dispatch(new SyncQualysAssetsJob($history->id, $rows));
        } catch (\Throwable $e) {
            $history->update([
                'status' => 2,
                'error' => mb_substr($e->getMessage(), 0, 1000),
            ]);
            throw $e;
        }

        return [
            'ok' => true,
            'skipped' => false,
            'history_id' => $history->id,
        ];
    }

    /**
     * Pull every Qualys host-list page and return the mapped rows.
     *
     * @return array<int, array<string, mixed>>
     */
    public function collectAll(QualysSyncHistory $history): array
    {
        $allRows = [];
        $lastId = 0;
        $pageSize = 100;
        $maxPages = 50000;

        for ($page = 1; $page <= $maxPages; $page++) {
            $pageData = $this->fetchPage($lastId, $pageSize);

            if ($history->total === null && $pageData['total_hint'] > 0) {
                $history->update(['total' => $pageData['total_hint']]);
                $history->total = $pageData['total_hint'];
            }

            if ($pageData['rows'] !== []) {
                $allRows = array_merge($allRows, $pageData['rows']);
            }

            $history->update([
                'processed' => count($allRows),
                'total' => $history->total ?: null,
            ]);

            if ($pageData['done']) {
                break;
            }
            $lastId = $pageData['last_host_id'];
        }

        $history->update([
            'processed' => count($allRows),
            'total' => $history->total ?: count($allRows),
        ]);

        return $allRows;
    }

    /**
     * Fetch one Qualys host-list page and map it to insert rows.
     *
     * @return array{rows: array<int, array<string, mixed>>, last_host_id: int, done: bool, total_hint: int}
     */
    protected function fetchPage(int $lastId, int $pageSize = 100): array
    {
        $idMin = $lastId > 0 ? $lastId + 1 : 1;
        $response = $this->qualysApi()->get($this->url(self::FO_HOST_LIST_PATH), [
            'action' => 'list',
            'truncation_limit' => $pageSize,
            'id_min' => $idMin,
            'details' => 'All',
            'show_asset_id' => 1,
        ]);

        if (!$response->successful()) {
            throw new \RuntimeException('Qualys host list page failed: HTTP ' . $response->status());
        }

        $xml = @simplexml_load_string($response->body());
        if ($xml === false) {
            throw new \RuntimeException('Qualys host list page returned invalid XML');
        }

        $empty = [
            'rows' => [],
            'last_host_id' => $lastId,
            'done' => true,
            'total_hint' => $this->extractTotalFromXml($xml),
        ];

        if (!isset($xml->RESPONSE->HOST_LIST->HOST)) {
            return $empty;
        }

        $hosts = $xml->RESPONSE->HOST_LIST->HOST;
        $hostList = isset($hosts->ID) ? [$hosts] : iterator_to_array($hosts, false);
        if ($hostList === []) {
            return $empty;
        }

        $maxHostId = $lastId;
        $rows = [];
        foreach ($hostList as $host) {
            $hostId = (int) ($host->ID ?? 0);
            if ($hostId > $maxHostId) {
                $maxHostId = $hostId;
            }
            $row = $this->mapHostToRow($host);
            if ($row !== null) {
                $rows[] = $row;
            }
        }

        return [
            'rows' => $rows,
            'last_host_id' => $maxHostId,
            'done' => $maxHostId <= $lastId || count($hostList) < $pageSize,
            'total_hint' => $this->extractTotalFromXml($xml),
        ];
    }

    protected function qualysApi(): PendingRequest
    {
        return Http::withHeaders([
            'X-Requested-With' => 'Curl Sample',
        ])
            ->withBasicAuth($this->username, $this->password)
            ->timeout(600);
    }

    protected function url(string $path): string
    {
        return $this->baseUrl . (isset($path[0]) && $path[0] === '/' ? $path : '/' . $path);
    }

    /**
     * @return array<string, mixed>|null
     */
    protected function mapHostToRow($host): ?array
    {
        $ip = $this->xmlText($host, 'IP');
        $hostId = $this->xmlText($host, 'ID');
        if ($ip === '' && $hostId === '') {
            return null;
        }

        return [
            'host_id' => $hostId,
            'qualys_asset_id' => $this->xmlText($host, 'ASSET_ID'),
            'ip' => $ip,
            'ipv6' => $this->xmlText($host, 'IPV6'),
            'tracking_method' => $this->xmlText($host, 'TRACKING_METHOD'),
            'os' => $this->xmlText($host, 'OS'),
            'dns' => $this->xmlText($host, 'DNS'),
            'netbios' => $this->xmlText($host, 'NETBIOS'),
            'hostname' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'HOSTNAME') : '',
            'domain' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'DOMAIN') : '',
            'host_fqdn' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'FQDN') : '',
        ];
    }

    protected function extractTotalFromXml($xml): int
    {
        if (isset($xml->RESPONSE->WARNING->TEXT) && preg_match('/(\d+)\s+total\s+host/i', (string) $xml->RESPONSE->WARNING->TEXT, $m)) {
            return (int) $m[1];
        }

        return 0;
    }

    protected function xmlText($node, string $name): string
    {
        if ($node === null || !isset($node->{$name})) {
            return '';
        }

        return trim((string) $node->{$name});
    }
}
