<?php

namespace App\Services;

use App\Jobs\SyncQualysJob;
use App\Models\QualysAuth;
use App\Models\QualysSyncHistory;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Facades\Http;

class QualysVulnPullService
{
    public const DEFAULT_QUALYS_BASE_URL = 'https://qualysapi.qg1.apps.qualysksa.com';

    public const FO_DETECTION_PATH = '/api/2.0/fo/asset/host/vm/detection/';

    protected $baseUrl;

    protected $username;

    protected $password;

    public function __construct()
    {
        $setting = QualysAuth::first();
        $this->username = $setting ? $setting->username : null;
        $this->password = $setting ? $setting->password : null;
        $apiUrl = $setting ? trim($setting->api_url ?? '') : '';
        $this->baseUrl = $apiUrl !== '' ? rtrim($apiUrl, '/') : self::DEFAULT_QUALYS_BASE_URL;
    }

    /**
     * Controller / artisan / schedule entry: pull all detections, then dispatch insert.
     *
     * @return array{ok: bool, skipped?: bool, history_id?: int, message?: string}
     */
    public function start(): array
    {
        if (QualysSyncHistory::where('type', 'Vulnerability')->where('status', 1)->exists()) {
            return [
                'ok' => true,
                'skipped' => true,
                'message' => 'A Qualys vulnerability sync is already running. Please wait until it finishes.',
            ];
        }

        $history = QualysSyncHistory::create([
            'type' => 'Vulnerability',
            'processed' => 0,
            'total' => null,
            'imported' => 0,
            'failed' => 0,
            'status' => 1,
        ]);

        try {
            set_time_limit(0);
            $rows = $this->collectAll($history);
            dispatch(new SyncQualysJob($history->id, $rows));
        } catch (\Throwable $e) {
            $history->update([
                'status' => 2,
                'error' => mb_substr($e->getMessage(), 0, 1000),
            ]);
            throw $e;
        }

        return [
            'ok' => true,
            'skipped' => false,
            'history_id' => $history->id,
        ];
    }

    /**
     * Pull every Qualys detection page and return the mapped rows.
     *
     * @return array<int, array<string, mixed>>
     */
    public function collectAll(QualysSyncHistory $history): array
    {
        $allRows = [];
        $lastId = 0;
        $pageSize = 100;
        $maxPages = 50000;
        $hostCount = 0;

        for ($page = 1; $page <= $maxPages; $page++) {
            $pageData = $this->fetchPage($lastId, $pageSize);

            if ($history->total === null && $pageData['total_hint'] > 0) {
                $history->update(['total' => $pageData['total_hint']]);
                $history->total = $pageData['total_hint'];
            }

            if ($pageData['rows'] !== []) {
                $allRows = array_merge($allRows, $pageData['rows']);
            }
            $hostCount += $pageData['host_count'];

            $history->update([
                'processed' => $hostCount,
                'total' => $history->total ?: null,
            ]);

            if ($pageData['done']) {
                break;
            }
            $lastId = $pageData['last_host_id'];
        }

        $history->update([
            'processed' => $hostCount,
            'total' => $history->total ?: $hostCount,
        ]);

        return $allRows;
    }

    /**
     * Fetch one Qualys detection page and map it to insert rows.
     *
     * @return array{rows: array<int, array<string, mixed>>, last_host_id: int, done: bool, total_hint: int, host_count: int}
     */
    protected function fetchPage(int $lastId, int $pageSize = 100): array
    {
        $idMin = $lastId > 0 ? $lastId + 1 : 1;
        $response = $this->qualysApi()->get($this->url(self::FO_DETECTION_PATH), [
            'action' => 'list',
            'truncation_limit' => $pageSize,
            'id_min' => $idMin,
            'show_results' => 1,
            'show_qds' => 1,
            'show_qds_factors' => 1,
            'show_tags' => 1,
            'show_asset_id' => 1,
        ]);

        if (!$response->successful()) {
            throw new \RuntimeException('Qualys detection page failed: HTTP ' . $response->status());
        }

        $xml = @simplexml_load_string($response->body());
        if ($xml === false) {
            throw new \RuntimeException('Qualys detection page returned invalid XML');
        }

        $empty = [
            'rows' => [],
            'last_host_id' => $lastId,
            'done' => true,
            'total_hint' => $this->extractTotalFromXml($xml),
            'host_count' => 0,
        ];

        if (!isset($xml->RESPONSE->HOST_LIST->HOST)) {
            return $empty;
        }

        $hosts = $xml->RESPONSE->HOST_LIST->HOST;
        $hostList = isset($hosts->ID) ? [$hosts] : iterator_to_array($hosts, false);
        if ($hostList === []) {
            return $empty;
        }

        $maxHostId = $lastId;
        $rows = [];
        foreach ($hostList as $host) {
            $hostId = (int) ($host->ID ?? 0);
            if ($hostId > $maxHostId) {
                $maxHostId = $hostId;
            }

            $detections = [];
            if (isset($host->DETECTION_LIST->DETECTION)) {
                $dets = $host->DETECTION_LIST->DETECTION;
                $detections = isset($dets->QID) ? [$dets] : iterator_to_array($dets, false);
            }

            foreach ($detections as $det) {
                $row = $this->mapHostDetectionToRow($host, $det);
                if ($row !== null) {
                    $rows[] = $row;
                }
            }
        }

        return [
            'rows' => $rows,
            'last_host_id' => $maxHostId,
            'done' => $maxHostId <= $lastId || count($hostList) < $pageSize,
            'total_hint' => $this->extractTotalFromXml($xml),
            'host_count' => count($hostList),
        ];
    }

    protected function qualysApi(): PendingRequest
    {
        return Http::withHeaders([
            'X-Requested-With' => 'Curl Sample',
        ])
            ->withBasicAuth($this->username, $this->password)
            ->timeout(600);
    }

    protected function url(string $path): string
    {
        return $this->baseUrl . (isset($path[0]) && $path[0] === '/' ? $path : '/' . $path);
    }

    /**
     * @return array<string, mixed>|null
     */
    protected function mapHostDetectionToRow($host, $det): ?array
    {
        $qid = $this->xmlText($det, 'QID');
        if ($qid === '') {
            return null;
        }

        $qdsNode = $det->QDS ?? null;
        $qdsScore = $qdsNode !== null ? trim((string) $qdsNode) : '';
        $qdsSeverity = '';
        if ($qdsNode !== null && isset($qdsNode['severity'])) {
            $qdsSeverity = trim((string) $qdsNode['severity']);
        }

        return [
            'qid' => $qid,
            'unique_vuln_id' => $this->xmlText($det, 'UNIQUE_VULN_ID'),
            'type' => $this->xmlText($det, 'TYPE'),
            'severity' => $this->xmlText($det, 'SEVERITY'),
            'port' => $this->xmlText($det, 'PORT'),
            'protocol' => $this->xmlText($det, 'PROTOCOL'),
            'ssl' => $this->xmlText($det, 'SSL'),
            'fqdn' => $this->xmlText($det, 'FQDN'),
            'instance' => $this->xmlText($det, 'INSTANCE'),
            'results' => $this->xmlText($det, 'RESULTS'),
            'status' => $this->xmlText($det, 'STATUS'),
            'first_found_datetime' => $this->xmlText($det, 'FIRST_FOUND_DATETIME'),
            'last_found_datetime' => $this->xmlText($det, 'LAST_FOUND_DATETIME'),
            'source' => $this->xmlText($det, 'SOURCE'),
            'qds' => $qdsScore,
            'qds_severity' => $qdsSeverity,
            'qds_factors' => $this->xmlQdsFactors($det),
            'times_found' => $this->xmlText($det, 'TIMES_FOUND'),
            'last_test_datetime' => $this->xmlText($det, 'LAST_TEST_DATETIME'),
            'last_update_datetime' => $this->xmlText($det, 'LAST_UPDATE_DATETIME'),
            'last_fixed_datetime' => $this->xmlText($det, 'LAST_FIXED_DATETIME'),
            'first_reopened_datetime' => $this->xmlText($det, 'FIRST_REOPENED_DATETIME'),
            'last_reopened_datetime' => $this->xmlText($det, 'LAST_REOPENED_DATETIME'),
            'times_reopened' => $this->xmlText($det, 'TIMES_REOPENED'),
            'service' => $this->xmlText($det, 'SERVICE'),
            'is_ignored' => $this->xmlText($det, 'IS_IGNORED'),
            'is_disabled' => $this->xmlText($det, 'IS_DISABLED'),
            'affect_running_kernel' => $this->xmlText($det, 'AFFECT_RUNNING_KERNEL'),
            'affect_running_service' => $this->xmlText($det, 'AFFECT_RUNNING_SERVICE'),
            'affect_exploitable_config' => $this->xmlText($det, 'AFFECT_EXPLOITABLE_CONFIG'),
            'last_processed_datetime' => $this->xmlText($det, 'LAST_PROCESSED_DATETIME'),
            'asset_cve' => $this->xmlText($det, 'ASSET_CVE'),
            'host_id' => $this->xmlText($host, 'ID'),
            'asset_id' => $this->xmlText($host, 'ASSET_ID'),
            'ip' => $this->xmlText($host, 'IP'),
            'ipv6' => $this->xmlText($host, 'IPV6'),
            'tracking_method' => $this->xmlText($host, 'TRACKING_METHOD'),
            'os' => $this->xmlText($host, 'OS'),
            'os_cpe' => $this->xmlText($host, 'OS_CPE'),
            'dns' => $this->xmlText($host, 'DNS'),
            'netbios' => $this->xmlText($host, 'NETBIOS'),
            'hostname' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'HOSTNAME') : '',
            'domain' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'DOMAIN') : '',
            'host_fqdn' => isset($host->DNS_DATA) ? $this->xmlText($host->DNS_DATA, 'FQDN') : '',
            'tags' => $this->xmlHostTags($host),
        ];
    }

    protected function extractTotalFromXml($xml): int
    {
        if (isset($xml->RESPONSE->WARNING->TEXT) && preg_match('/(\d+)\s+total\s+host/i', (string) $xml->RESPONSE->WARNING->TEXT, $m)) {
            return (int) $m[1];
        }

        return 0;
    }

    protected function xmlText($node, string $name): string
    {
        if ($node === null || !isset($node->{$name})) {
            return '';
        }

        return trim((string) $node->{$name});
    }

    /**
     * @return array<string, string>
     */
    protected function xmlQdsFactors($det): array
    {
        $factors = [];
        if (!isset($det->QDS_FACTORS->QDS_FACTOR)) {
            return $factors;
        }

        $nodes = $det->QDS_FACTORS->QDS_FACTOR;
        $list = isset($nodes['name']) ? [$nodes] : $nodes;
        foreach ($list as $factor) {
            $name = strtolower(trim((string) ($factor['name'] ?? '')));
            if ($name === '') {
                continue;
            }
            $value = trim((string) $factor);
            if ($value === '' || strcasecmp($value, 'null') === 0) {
                continue;
            }
            if (isset($factors[$name]) && $factors[$name] !== '') {
                $factors[$name] .= ',' . $value;
            } else {
                $factors[$name] = $value;
            }
        }

        return $factors;
    }

    protected function xmlHostTags($host): string
    {
        if (!isset($host->TAGS->TAG)) {
            return '';
        }

        $names = [];
        $nodes = $host->TAGS->TAG;
        $list = isset($nodes->NAME) ? [$nodes] : $nodes;
        foreach ($list as $tag) {
            $name = trim((string) ($tag->NAME ?? ''));
            if ($name !== '') {
                $names[] = $name;
            }
        }

        return implode(', ', $names);
    }
}
