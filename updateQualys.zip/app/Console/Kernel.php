<?php

namespace App\Console;

use App\Console\Commands\CheckIncidentSla;
use App\Console\Commands\EsclationAuditeesDocumentAudit;
use App\Console\Commands\EsclationObjectiveControl;
use App\Console\Commands\vulnerabilityStatus;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Asset;
use App\Models\ControlControlObjective;
use App\Models\ControlObjective;
use App\Models\NotifyAtDateModel;
use App\Models\ScheduledQualysVulnerability;
use App\Models\Vulnerability;
use App\Services\QualysVulnPullService;
use Carbon\Carbon;
use App\Repositories\SurveyRepo;
use Illuminate\Support\Facades\Schema;

class Kernel extends ConsoleKernel
{
    use NotificationHandlingTrait;

    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        // \App\Console\Commands\AdminSettingsNotify::class,
        \App\Console\Commands\VulnerabilityStatus::class,
        \App\Console\Commands\FetchQualysVulnerabilities::class,
        \App\Console\Commands\EsclationAuditeesDocumentAudit::class,
        \App\Console\Commands\EsclationObjectiveControl::class,
        \App\Console\Commands\CheckIncidentSla::class,
        \App\Console\Commands\ProcessPenetrationTestSla::class,

    ];
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $currentTime = Carbon::now()->format('H:i');
        $todayName = Carbon::now()->format('l');

        $scheduleVulnerabilityQualys = Schema::hasTable('qualys_auth_schedule')
            ? ScheduledQualysVulnerability::first()
            : null;
        if ($scheduleVulnerabilityQualys) {
            $runQualysSync = function () {
                (new QualysVulnPullService())->start();
            };

            if ($scheduleVulnerabilityQualys->time_schedule == "daily" && $scheduleVulnerabilityQualys->due_time == $currentTime) {
                $schedule->call($runQualysSync)->everyMinute();
            }

            if ($scheduleVulnerabilityQualys->time_schedule == "weekly" && $scheduleVulnerabilityQualys->due_weekly_time == $currentTime && $scheduleVulnerabilityQualys->due_weekly_day == $todayName) {
                $schedule->call($runQualysSync)->everyMinute();
            }

            if ($scheduleVulnerabilityQualys->time_schedule == "monthly" && $scheduleVulnerabilityQualys->date_monthly) {
                $convert_Month_qualys = Carbon::parse($scheduleVulnerabilityQualys->date_monthly)->format('d');
                $convert_time_qualys = Carbon::parse($scheduleVulnerabilityQualys->date_monthly)->format('H:i');
                $dayOfMonthQualys = (int) substr((string) $scheduleVulnerabilityQualys->date_monthly, 8, 2);
                $currentMonthDays = Carbon::now()->daysInMonth;
                if ($currentMonthDays <= $dayOfMonthQualys) {
                    $lastDayOfMonth = Carbon::now()->endOfMonth()->format('d');
                    $schedule->call($runQualysSync)->monthlyOn($lastDayOfMonth, $convert_time_qualys);
                } else {
                    $schedule->call($runQualysSync)->monthlyOn($convert_Month_qualys, $convert_time_qualys);
                }
            }
        }

        // Schedule asset expiration alert
        $schedule->command('asset:expirationDateAlert')->dailyAt('00:01'); // Run at the first minute of every day

        // Schedule cleanup task
        $schedule->command('cleanup:old-files')->dailyAt('00:01'); // Runs daily
        $schedule->command(EsclationObjectiveControl::class)->dailyAt('00:01'); // Runs daily

        // Schedule vulnerability status check
        $schedule->command(vulnerabilityStatus::class)->dailyAt('00:01'); // Runs daily
        $schedule->command(EsclationAuditeesDocumentAudit::class)->dailyAt('07:01'); // Runs daily

         $schedule->command(CheckIncidentSla::class)->dailyAt('07:01');
         $schedule->command('penetration-testing:process-sla')->dailyAt('07:15');

        // Auto Notification cleanup and processing
        $schedule->call(function () {
            // Get today's date
            $today = Carbon::today()->toDateString();

            // Get and process all records
            $records = NotifyAtDateModel::all();

            // Loop through each record
            foreach ($records as $record) {
                // Decode the JSON-encoded dates
                $dates = json_decode($record->notification_date, true);

                // Check if the notification_date is an empty array
                if (empty($dates)) {
                    // You can perform any additional logic here for empty arrays if needed
                    // For example, skip deletion or set default behavior
                    continue; // Skip this record and move to the next one
                }

                // Check if all dates in the array are less than today
                if (collect($dates)->every(fn($date) => $date < $today)) {
                    // Delete the record
                    $record->delete();
                }
            }


            // Additional cleanup for specific processes and models
            NotifyAtDateModel::where('proccess', 'delete')->delete();
            NotifyAtDateModel::where('model_type', 'survey')
                ->where('model->filter_status', 3)
                ->select('model')
                ->delete();
            NotifyAtDateModel::where('model_type', 'securityAwareness')
                ->where('model->status', 3)
                ->select('model')
                ->delete();
            NotifyAtDateModel::where('model_type', 'document')
                ->where('model->document_status', 3)
                ->select('model')
                ->delete();


            // Notify for pending notifications
            $pendingNotifications = NotifyAtDateModel::whereJsonContains('notification_date', $today)
                ->whereNotIn('model_type', ['Audit_Policy_Skip_Due_Date', 'esclationObjectiveNotify'])
                ->get();
            foreach ($pendingNotifications as $notification) {
                $model = json_decode($notification->model, true);
                $roles = json_decode($notification->roles, true);
                $actionId2 = $notification->action_id;
                $link = $notification->link;
                $nextDateNotify = json_decode($notification->notification_date, true);
                $this->sendNotificationForAction($actionId1 = null, $actionId2, ['link' => $link], $model, $roles, $nextDateNotify,  $modelId = null, $modelType = null, $proccess = null);
            }
        })->dailyAt('00:01'); // Runs daily
    }



    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}