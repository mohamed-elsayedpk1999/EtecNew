<?php

namespace App\Console\Commands;

use App\Services\QualysAssetPullService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class FetchQualysAssets extends Command
{
    protected $signature = 'fetch:qualys-assets';

    protected $description = 'Fetch hosts/assets from Qualys Host List API';

    public function handle()
    {
        $result = (new QualysAssetPullService())->start();

        if (!empty($result['skipped'])) {
            $this->warn($result['message'] ?? 'A Qualys asset sync is already running.');
            return 0;
        }

        if (empty($result['ok'])) {
            $this->error($result['message'] ?? 'Qualys asset sync failed.');
            Log::error('FetchQualysAssets failed', $result);

            return 1;
        }

        $this->info('Qualys asset sync dispatched.');
        Log::info('FetchQualysAssets dispatched', [
            'history_id' => $result['history_id'] ?? null,
        ]);

        return 0;
    }
}
