<?php

namespace App\Console\Commands;

use App\Services\QualysVulnPullService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;

class FetchQualysVulnerabilities extends Command
{
    protected $signature = 'fetch:qualys-vulnerabilities';

    protected $description = 'Fetch new vulnerabilities from Qualys';

    public function handle()
    {
        $result = (new QualysVulnPullService())->start();

        if (!empty($result['skipped'])) {
            $this->warn($result['message'] ?? 'A Qualys sync is already running.');
            return 0;
        }

        if (empty($result['ok'])) {
            $this->error($result['message'] ?? 'Qualys sync failed.');
            Log::error('FetchQualysVulnerabilities failed', $result);

            return 1;
        }

        $this->info('Qualys sync dispatched.');
        Log::info('FetchQualysVulnerabilities dispatched', [
            'history_id' => $result['history_id'] ?? null,
        ]);

        return 0;
    }
}
