<?php

namespace App\Http\Controllers\admin\configure;

use App\Http\Controllers\Controller;
use App\Models\QualysAuth;
use App\Models\QualysSyncHistory;
use App\Models\ScheduledQualysVulnerability;
use App\Services\QualysAssetGroupPullService;
use App\Services\QualysAssetPullService;
use App\Services\QualysVulnPullService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\Facades\DataTables;

class QualysAuthSetupController extends Controller
{

    public function index()
    {
        // Check if the user has the required permission
        if (!auth()->user()->hasPermission('qualys.list')) {
            abort(403, 'Unauthorized action.');
        }

        $qualysAuth = QualysAuth::first();
        $schedule = ScheduledQualysVulnerability::first();

        return view('admin.content.configure.qualys_auth.create', compact('qualysAuth', 'schedule'));
    }

    public function syncHistory(Request $request)
    {
        $query = QualysSyncHistory::query()->orderBy('created_at', 'desc');

        return DataTables::of($query)
            ->editColumn('created_at', function ($row) {
                return optional($row->created_at)->format('Y-m-d h:i:s A');
            })
            ->addColumn('percentage', function ($row) {
                $total = (int) ($row->total ?? 0);
                $processed = (int) ($row->processed ?? 0);
                if ((int) $row->status === 0) {
                    $percentage = 100;
                } elseif ($total > 0) {
                    $percentage = min(100, ($processed / $total) * 100);
                } else {
                    $percentage = 0;
                }
                $barColor = (int) $row->status === 2 ? '#f44336' : '#4caf50';
                $percentage = round($percentage, 2);

                return '<div class="qualys-progress">'
                    . '<div class="qualys-progress-bar"><div style="width:' . $percentage . '%;background-color:' . $barColor . ';"></div></div>'
                    . '<span>' . $percentage . '%</span></div>';
            })
            ->rawColumns(['percentage'])
            ->make(true);
    }

    public function store(Request $request)
    {

        try {
            // Define dynamic validation rules
            $rules = [
                'api_url' => 'required',
            ];

            // Check if the record exists
            $qualysAuth = QualysAuth::find($request->id);

            // If the record doesn't exist or if either key is provided, make them required
            if (!$qualysAuth && ($request->has('username') || $request->has('password'))) {
                $rules['username'] = 'required';
                $rules['password'] = 'required';
            }

            // Validate input fields
            $validator = Validator::make($request->all(), $rules);

            if ($validator->fails()) {
                // Return validation errors
                return response()->json([
                    'status' => false,
                    'message' => $validator->errors()->first(),
                ]);
            }

            // Start a database transaction
            DB::beginTransaction();

            // If the record exists and secret_key and password are empty, retrieve existing values
            if ($qualysAuth && empty($request->username) && empty($request->password)) {
                $request->merge([
                    'password' => $qualysAuth->password,
                    'username' => $qualysAuth->username,
                ]);
            }
            // Update or create the record in the database
            $qualysAuth = QualysAuth::updateOrCreate(
                ['id' => $request->id],
                [
                    'password' => $request->password,
                    'username' => $request->username,
                    'api_url' => $request->api_url,
                    'offset' => $request->offset,
                    'end' => $request->end,
                    'total' => $request->total
                ]
            );

            // Commit the transaction
            DB::commit();

            // Return success response
            return response()->json([
                'status' => true,
                'message' => __('locale.ConnectionTestSuccess') . ' Connection to SMTP/Exchange server successful.',
            ]);
        } catch (\Throwable $e) {
            // Rollback the transaction in case of error
            DB::rollBack();

            // Return error response
            return response()->json([
                'status' => false,
                'message' => __('locale.ConnectionTestFailed') . ' ' . $e->getMessage(),
            ]);
        }
    }






    public function insertSchedule(Request $request)
    {
        // Define validation rules
        $rules = [
            'time_schedule' => 'required',
        ];

        // Add conditional rules based on the selected radio button value
        if ($request->time_schedule == 'daily') {
            $rules['due_time'] = 'required';
        } elseif ($request->time_schedule == 'weekly') {
            $rules['due_weekly_day'] = 'required';
            $rules['due_weekly_time'] = 'required';
        } elseif ($request->time_schedule == 'monthly') {
            $rules['date_monthly'] = 'required';
        }

        // Validate the request data
        $validator = Validator::make($request->all(), $rules);

        // Check if the validation fails
        if ($validator->fails()) {
            return response()->json([
                'status' => false,
                'message' => $validator->errors()->first(),
            ]);
        }

        try {
            // Start a database transaction
            DB::beginTransaction();

            $va = ScheduledQualysVulnerability::updateOrCreate(
                ['id' => $request->idSchedule],
                [
                    'time_schedule' => $request->time_schedule,
                    'due_time' => $request->due_time,
                    'due_weekly_day' => $request->due_weekly_day,
                    'due_weekly_time' => $request->due_weekly_time,
                    'date_monthly' => $request->date_monthly,
                ]
            );

            // Commit the transaction
            DB::commit();

            // Return success response
            return response()->json([
                'status' => true,
                'message' => __('locale.Success') . '.',
            ]);
        } catch (\Throwable $e) {
            // Rollback the transaction in case of error
            DB::rollBack();

            // Return error response
            return response()->json([
                'status' => false,
                'message' => __('locale.Failed') . ' ' . $e->getMessage(),
            ]);
        }
    }
    public function applySync(Request $request)
    {
        Log::info('Qualys applySync started', [
            'user_id' => optional(auth()->user())->id,
        ]);

        try {
            $result = (new QualysVulnPullService())->start();

            if (!empty($result['skipped'])) {
                return response()->json([
                    'status' => false,
                    'message' => $result['message'] ?? 'A Qualys sync is already running. Please wait until it finishes.',
                ]);
            }

            Log::info('Qualys applySync dispatched', [
                'history_id' => $result['history_id'] ?? null,
            ]);

            return response()->json([
                'status' => true,
                'message' => __('locale.Success') . '. Qualys vulnerability sync started in background.',
                'history_id' => $result['history_id'] ?? null,
            ]);
        } catch (\Throwable $e) {
            Log::error('Qualys applySync exception', [
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => false,
                'message' => __('locale.Failed') . ' ' . $e->getMessage(),
            ]);
        }
    }

    public function applySyncAssets(Request $request)
    {
        Log::info('Qualys applySyncAssets started', [
            'user_id' => optional(auth()->user())->id,
        ]);

        try {
            $result = (new QualysAssetPullService())->start();

            if (!empty($result['skipped'])) {
                return response()->json([
                    'status' => false,
                    'message' => $result['message'] ?? 'A Qualys asset sync is already running. Please wait until it finishes.',
                ]);
            }

            Log::info('Qualys applySyncAssets dispatched', [
                'history_id' => $result['history_id'] ?? null,
            ]);

            return response()->json([
                'status' => true,
                'message' => __('locale.Success') . '. Qualys asset sync started in background.',
                'history_id' => $result['history_id'] ?? null,
            ]);
        } catch (\Throwable $e) {
            Log::error('Qualys applySyncAssets exception', [
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => false,
                'message' => __('locale.Failed') . ' ' . $e->getMessage(),
            ]);
        }
    }

    public function applySyncAssetGroups(Request $request)
    {
        Log::info('Qualys applySyncAssetGroups started', [
            'user_id' => optional(auth()->user())->id,
        ]);

        try {
            $result = (new QualysAssetGroupPullService())->start();

            if (!empty($result['skipped'])) {
                return response()->json([
                    'status' => false,
                    'message' => $result['message'] ?? 'A Qualys asset group sync is already running. Please wait until it finishes.',
                ]);
            }

            Log::info('Qualys applySyncAssetGroups dispatched', [
                'history_id' => $result['history_id'] ?? null,
            ]);

            return response()->json([
                'status' => true,
                'message' => __('locale.Success') . '. Qualys asset group sync started in background.',
                'history_id' => $result['history_id'] ?? null,
            ]);
        } catch (\Throwable $e) {
            Log::error('Qualys applySyncAssetGroups exception', [
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'status' => false,
                'message' => __('locale.Failed') . ' ' . $e->getMessage(),
            ]);
        }
    }
}
