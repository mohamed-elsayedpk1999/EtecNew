<?php

namespace App\Jobs;

use App\Models\Asset;
use App\Models\AssetGroup;
use App\Models\QualysSyncHistory;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SyncQualysAssetGroupsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 7200;

    protected $historyId;

    /** @var array<int, array<string, mixed>> */
    protected $rows;

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    public function __construct(int $historyId, array $rows)
    {
        $this->historyId = $historyId;
        $this->rows = $rows;
    }

    public function handle(): void
    {
        $history = QualysSyncHistory::find($this->historyId);
        if (!$history) {
            Log::error('SyncQualysAssetGroupsJob: history record not found', ['id' => $this->historyId]);
            return;
        }

        $assets = Asset::query()
            ->get(['id', 'ip', 'details']);

        $assetsByIp = [];
        $assetsByHostId = [];
        foreach ($assets as $asset) {
            if (!empty($asset->ip)) {
                $assetsByIp[$asset->ip][] = (int) $asset->id;
            }
            if (!empty($asset->details) && preg_match_all('/Qualys host ID:\s*(\d+)/', (string) $asset->details, $matches)) {
                foreach ($matches[1] as $hostId) {
                    $assetsByHostId[$hostId][] = (int) $asset->id;
                }
            }
        }

        $totalImported = 0;
        $totalFailed = 0;
        $totalProcessed = 0;

        foreach ($this->rows as $row) {
            ++$totalProcessed;
            try {
                DB::beginTransaction();
                $group = $this->upsertAssetGroup($row);
                if ($group) {
                    $assetIds = $this->matchAssetIds($row, $assetsByIp, $assetsByHostId, $assets);
                    if ($assetIds !== []) {
                        $group->assets()->syncWithoutDetaching($assetIds);
                    }
                    ++$totalImported;
                }
                DB::commit();
            } catch (\Throwable $e) {
                DB::rollBack();
                ++$totalFailed;
                Log::error('SyncQualysAssetGroupsJob: failed to store group', [
                    'qualys_id' => $row['qualys_id'] ?? '',
                    'title' => $row['title'] ?? '',
                    'error' => $e->getMessage(),
                ]);
            }
        }

        $history->update([
            'status' => 0,
            'processed' => $totalProcessed,
            'imported' => $totalImported,
            'failed' => $totalFailed,
            'total' => $history->total ?: $totalProcessed,
        ]);
    }

    /**
     * @param array<string, mixed> $row
     */
    protected function upsertAssetGroup(array $row): ?AssetGroup
    {
        $title = trim((string) ($row['title'] ?? ''));
        $qualysId = trim((string) ($row['qualys_id'] ?? ''));
        if ($title === '' && $qualysId === '') {
            return null;
        }

        $base = mb_substr($title !== '' ? $title : 'Qualys Asset Group', 0, 100);
        $existing = AssetGroup::where('name', $base)->first();
        if ($existing) {
            return $existing;
        }

        if ($qualysId !== '') {
            $withId = mb_substr($base . ' (' . $qualysId . ')', 0, 100);
            $existing = AssetGroup::where('name', $withId)->first();
            if ($existing) {
                return $existing;
            }
        }

        try {
            return AssetGroup::create(['name' => $base]);
        } catch (\Throwable $e) {
            if ($qualysId === '') {
                throw $e;
            }

            return AssetGroup::firstOrCreate([
                'name' => mb_substr($base . ' (' . $qualysId . ')', 0, 100),
            ]);
        }
    }

    /**
     * @param array<string, mixed> $row
     * @param array<string, array<int, int>> $assetsByIp
     * @param array<string, array<int, int>> $assetsByHostId
     * @return array<int, int>
     */
    protected function matchAssetIds(array $row, array $assetsByIp, array $assetsByHostId, $assets): array
    {
        $ids = [];

        foreach (($row['ips'] ?? []) as $ip) {
            if (isset($assetsByIp[$ip])) {
                $ids = array_merge($ids, $assetsByIp[$ip]);
            }
        }

        foreach (($row['host_ids'] ?? []) as $hostId) {
            $hostId = (string) $hostId;
            if (isset($assetsByHostId[$hostId])) {
                $ids = array_merge($ids, $assetsByHostId[$hostId]);
            }
        }

        foreach (($row['ip_ranges'] ?? []) as $range) {
            $start = ip2long((string) ($range['start'] ?? ''));
            $end = ip2long((string) ($range['end'] ?? ''));
            if ($start === false || $end === false) {
                continue;
            }
            if ($start > $end) {
                [$start, $end] = [$end, $start];
            }
            foreach ($assets as $asset) {
                if (empty($asset->ip)) {
                    continue;
                }
                $n = ip2long((string) $asset->ip);
                if ($n !== false && $n >= $start && $n <= $end) {
                    $ids[] = (int) $asset->id;
                }
            }
        }

        $ids = array_values(array_unique(array_map('intval', $ids)));

        return $ids;
    }
}
