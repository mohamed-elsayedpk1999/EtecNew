<?php

namespace App\Jobs;

use App\Models\Asset;
use App\Models\QualysSyncHistory;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SyncQualysAssetsJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 7200;

    protected $historyId;

    /** @var array<int, array<string, mixed>> */
    protected $rows;

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    public function __construct(int $historyId, array $rows)
    {
        $this->historyId = $historyId;
        $this->rows = $rows;
    }

    public function handle(): void
    {
        $history = QualysSyncHistory::find($this->historyId);
        if (!$history) {
            Log::error('SyncQualysAssetsJob: history record not found', ['id' => $this->historyId]);
            return;
        }

        $totalImported = 0;
        $totalFailed = 0;
        $totalProcessed = 0;

        foreach ($this->rows as $row) {
            ++$totalProcessed;
            try {
                DB::beginTransaction();
                $asset = $this->upsertAsset($row);
                DB::commit();
                if ($asset) {
                    ++$totalImported;
                }
            } catch (\Throwable $e) {
                DB::rollBack();
                ++$totalFailed;
                Log::error('SyncQualysAssetsJob: failed to store host', [
                    'ip' => $row['ip'] ?? '',
                    'host_id' => $row['host_id'] ?? '',
                    'error' => $e->getMessage(),
                ]);
            }
        }

        $history->update([
            'status' => 0,
            'processed' => $totalProcessed,
            'imported' => $totalImported,
            'failed' => $totalFailed,
            'total' => $history->total ?: $totalProcessed,
        ]);
    }

    /**
     * @param array<string, mixed> $row
     */
    protected function upsertAsset(array $row): ?Asset
    {
        $ip = $this->ipv4((string) ($row['ip'] ?? ''));
        $name = $this->assetDisplayName($row);
        if ($ip === null && $name === '') {
            return null;
        }

        $existing = null;
        if ($ip !== null) {
            $existing = Asset::where('ip', $ip)->first();
        }
        if (!$existing && $name !== '') {
            $existing = Asset::where('name', $name)->first();
        }

        $details = $this->assetDetails($row);
        $osVersion = $this->str($row['os'] ?? '');
        $osVersion = $osVersion !== '' ? mb_substr($osVersion, 0, 255) : null;

        if ($existing) {
            $updates = [];
            if ($ip !== null && empty($existing->ip)) {
                $updates['ip'] = $ip;
            }
            if ($osVersion && empty($existing->os_version)) {
                $updates['os_version'] = $osVersion;
            }
            if ($details && empty($existing->details)) {
                $updates['details'] = $details;
            }
            if ($updates !== []) {
                $existing->update($updates);
            }

            return $existing;
        }

        return Asset::create([
            'name' => $this->uniqueAssetName($name !== '' ? $name : 'Qualys Host', (string) ($row['host_id'] ?? $ip ?? '')),
            'ip' => $ip,
            'os_version' => $osVersion,
            'details' => $details,
            'verified' => 0,
        ]);
    }

    /**
     * @param array<string, mixed> $row
     */
    protected function assetDisplayName(array $row): string
    {
        foreach (['dns', 'host_fqdn', 'hostname', 'netbios', 'ip', 'host_id'] as $key) {
            if (($row[$key] ?? '') !== '') {
                return mb_substr((string) $row[$key], 0, 200);
            }
        }

        return '';
    }

    protected function uniqueAssetName(string $name, string $suffix): string
    {
        $name = mb_substr(trim($name) !== '' ? $name : 'Qualys Host', 0, 200);
        if (!Asset::where('name', $name)->exists()) {
            return $name;
        }

        $withSuffix = mb_substr($name . '-' . $suffix, 0, 200);
        if ($suffix !== '' && !Asset::where('name', $withSuffix)->exists()) {
            return $withSuffix;
        }

        return mb_substr($name . '-' . uniqid(), 0, 200);
    }

    /**
     * @param array<string, mixed> $row
     */
    protected function assetDetails(array $row): ?string
    {
        $parts = [];
        foreach ([
            'host_id' => 'Qualys host ID',
            'qualys_asset_id' => 'Qualys asset ID',
            'tracking_method' => 'Tracking',
            'ipv6' => 'IPv6',
            'os' => 'OS',
        ] as $key => $label) {
            if (($row[$key] ?? '') !== '') {
                $parts[] = $label . ': ' . $row[$key];
            }
        }

        return $parts !== [] ? implode("\n", $parts) : null;
    }

    protected function ipv4(string $ip): ?string
    {
        $ip = trim($ip);

        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ?: null;
    }

    protected function str($value): string
    {
        if ($value === null) {
            return '';
        }

        return trim((string) $value);
    }
}
