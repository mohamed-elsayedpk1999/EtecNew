<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class EmptyAssetsVulnsAssetGroupsSeeder extends Seeder
{
    public function run(): void
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        $tables = [
            'asset_vulnerabilities',
            'team_vulnerabilities',
            'asset_asset_groups',
            'risks_to_assets',
            'risks_to_asset_groups',
            'assessment_answers_to_assets',
            'assessment_answers_to_asset_groups',
            'asset_host_region',
            'incident_assets',
            'asset_comments',
            'asset_comment_readers',
            'assets',
            'vulnerabilities',
            'asset_groups',
            'qualys_sync_histories',
        ];

        foreach ($tables as $table) {
            if (Schema::hasTable($table)) {
                DB::table($table)->truncate();
            }
        }

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}
