<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

class DropTenableTables extends Migration
{
    public function up()
    {
        Schema::dropIfExists('tenable_histories');
        Schema::dropIfExists('tenable_async_histories');
        Schema::dropIfExists('tenable_auth_schedule');
        Schema::dropIfExists('tenable_auth');
    }

    public function down()
    {
        // Tenable integration was removed; tables are not recreated.
    }
}
