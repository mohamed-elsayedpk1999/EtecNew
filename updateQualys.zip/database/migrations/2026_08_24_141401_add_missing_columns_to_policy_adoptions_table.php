<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMissingColumnsToPolicyAdoptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('policy_adoptions', function (Blueprint $table) {
            if (!Schema::hasColumn('policy_adoptions', 'description')) {
                $table->longText('description')->nullable();
            }
            if (!Schema::hasColumn('policy_adoptions', 'introduction_content2')) {
                $table->longText('introduction_content2')->nullable();
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('policy_adoptions', function (Blueprint $table) {
            if (Schema::hasColumn('policy_adoptions', 'description')) {
                $table->dropColumn('description');
            }
            if (Schema::hasColumn('policy_adoptions', 'introduction_content2')) {
                $table->dropColumn('introduction_content2');
            }
        });
    }
}
