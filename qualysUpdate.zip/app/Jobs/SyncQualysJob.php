<?php

namespace App\Jobs;

use App\Models\Asset;
use App\Models\QualysSyncHistory;
use App\Models\Vulnerability;
use Carbon\Carbon;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class SyncQualysJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $timeout = 7200;

    protected $historyId;

    /** @var array<int, array<string, mixed>> */
    protected $rows;

    protected $isLast;

    /**
     * @param array<int, array<string, mixed>> $rows
     */
    public function __construct(int $historyId, array $rows, bool $isLast = true)
    {
        $this->historyId = $historyId;
        $this->rows = $rows;
        $this->isLast = $isLast;
    }

    public function handle(): void
    {
        $history = QualysSyncHistory::find($this->historyId);
        if (!$history) {
            Log::error('SyncQualysJob: history record not found', ['id' => $this->historyId]);
            return;
        }

        $totalImported = 0;
        $totalFailed = 0;
        $totalProcessed = 0;

        foreach ($this->rows as $row) {
            ++$totalProcessed;
            $result = $this->insertDetection($row);
            if ($result === 'saved') {
                ++$totalImported;
            } elseif ($result === 'failed') {
                ++$totalFailed;
            }
        }

        $history->increment('imported', $totalImported);
        $history->increment('failed', $totalFailed);

        if ($this->isLast) {
            $history->refresh();
            $history->update([
                'status' => 0,
                'processed' => $history->processed ?: $totalProcessed,
                'total' => $history->total ?: max((int) $history->processed, $totalProcessed),
            ]);
        }
    }

    /**
     * @param array<string, mixed> $raw
     * @return 'saved'|'skipped'|'failed'
     */
    protected function insertDetection(array $raw): string
    {
        $row = $this->normalizeDetectionRow($raw);
        $qid = $row['qid'];
        if ($qid === '') {
            return 'skipped';
        }

        try {
            DB::beginTransaction();

            $asset = $this->findOrCreateAsset($row);
            if (!$asset) {
                DB::rollBack();

                return 'skipped';
            }

            $model = $this->findExistingVulnerability($row, $asset->id);
            $wasExisting = $model !== null;
            if (!$model) {
                $model = new Vulnerability();
            }

            $values = $this->mapDetectionToAttributes($row, $wasExisting ? $model : null);
            if (!$wasExisting) {
                $values['created_by'] = $this->defaultCreatedBy();
                $values['recommendation'] = $values['recommendation'] ?? '';
                $values['plan'] = $values['plan'] ?? '';
                if (($values['description'] ?? null) === null) {
                    $values['description'] = $row['results'] !== '' ? $row['results'] : ('QID ' . $qid);
                }
            }

            $model->fill($values);
            $model->save();
            $asset->vulnerabilities()->syncWithoutDetaching([$model->id]);

            DB::commit();

            return 'saved';
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('SyncQualysJob: failed to store row', [
                'qid' => $qid,
                'error' => $e->getMessage(),
            ]);

            return 'failed';
        }
    }

    protected function defaultCreatedBy(): int
    {
        $userId = DB::table('users')->orderBy('id')->value('id');

        return $userId ? (int) $userId : 1;
    }

    /**
     * @param array<string, mixed> $v
     * @return array<string, mixed>
     */
    protected function normalizeDetectionRow(array $v): array
    {
        $factors = $v['qds_factors'] ?? [];
        if (is_string($factors)) {
            $decoded = json_decode($factors, true);
            $factors = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($factors)) {
            $factors = [];
        }

        return [
            'qid' => $this->str($v['qid'] ?? ''),
            'unique_vuln_id' => $this->str($v['unique_vuln_id'] ?? ''),
            'type' => $this->str($v['type'] ?? ''),
            'severity' => $this->str($v['severity'] ?? ''),
            'port' => $this->str($v['port'] ?? ''),
            'protocol' => $this->str($v['protocol'] ?? ''),
            'ssl' => $this->str($v['ssl'] ?? ''),
            'fqdn' => $this->str($v['fqdn'] ?? $v['host_fqdn'] ?? ''),
            'instance' => $this->str($v['instance'] ?? ''),
            'results' => $this->str($v['results'] ?? ''),
            'status' => $this->str($v['status'] ?? ''),
            'first_found_datetime' => $this->str($v['first_found_datetime'] ?? ''),
            'last_found_datetime' => $this->str($v['last_found_datetime'] ?? ''),
            'source' => $this->str($v['source'] ?? ''),
            'qds' => $this->str($v['qds'] ?? ''),
            'qds_severity' => $this->str($v['qds_severity'] ?? ''),
            'qds_factors' => $factors,
            'times_found' => $this->str($v['times_found'] ?? ''),
            'last_test_datetime' => $this->str($v['last_test_datetime'] ?? ''),
            'last_update_datetime' => $this->str($v['last_update_datetime'] ?? ''),
            'last_fixed_datetime' => $this->str($v['last_fixed_datetime'] ?? ''),
            'first_reopened_datetime' => $this->str($v['first_reopened_datetime'] ?? ''),
            'last_reopened_datetime' => $this->str($v['last_reopened_datetime'] ?? ''),
            'times_reopened' => $this->str($v['times_reopened'] ?? ''),
            'service' => $this->str($v['service'] ?? ''),
            'is_ignored' => $this->str($v['is_ignored'] ?? ''),
            'is_disabled' => $this->str($v['is_disabled'] ?? ''),
            'affect_running_kernel' => $this->str($v['affect_running_kernel'] ?? ''),
            'affect_running_service' => $this->str($v['affect_running_service'] ?? ''),
            'affect_exploitable_config' => $this->str($v['affect_exploitable_config'] ?? ''),
            'last_processed_datetime' => $this->str($v['last_processed_datetime'] ?? ''),
            'asset_cve' => $this->str($v['asset_cve'] ?? ''),
            'host_id' => $this->str($v['host_id'] ?? ''),
            'qualys_asset_id' => $this->str($v['asset_id'] ?? ''),
            'ip' => $this->str($v['ip'] ?? ''),
            'ipv6' => $this->str($v['ipv6'] ?? ''),
            'tracking_method' => $this->str($v['tracking_method'] ?? ''),
            'os' => $this->str($v['os'] ?? ''),
            'os_cpe' => $this->str($v['os_cpe'] ?? ''),
            'dns' => $this->str($v['dns'] ?? ''),
            'netbios' => $this->str($v['netbios'] ?? ''),
            'hostname' => $this->str($v['hostname'] ?? ''),
            'domain' => $this->str($v['domain'] ?? ''),
            'host_fqdn' => $this->str($v['host_fqdn'] ?? ''),
            'tags' => $this->str($v['tags'] ?? ''),
        ];
    }

    /**
     * Find an existing asset by IP or name, otherwise create it from the Qualys host fields.
     *
     * @param array<string, mixed> $row
     */
    protected function findOrCreateAsset(array $row): ?Asset
    {
        $ip = $this->ipv4($row['ip'] ?? '');
        $name = $this->assetDisplayName($row);
        if ($ip === null && ($name === '' || $name === 'Qualys Host')) {
            return null;
        }

        $existing = null;
        if ($ip !== null) {
            $existing = Asset::where('ip', $ip)->first();
        }
        if (!$existing && $name !== '' && $name !== 'Qualys Host') {
            $existing = Asset::where('name', $name)->first();
        }

        $details = $this->assetDetails($row);
        $osVersion = $this->str($row['os'] ?? '');
        $osVersion = $osVersion !== '' ? mb_substr($osVersion, 0, 255) : null;

        if ($existing) {
            $updates = [];
            if ($ip !== null && empty($existing->ip)) {
                $updates['ip'] = $ip;
            }
            if ($osVersion && empty($existing->os_version)) {
                $updates['os_version'] = $osVersion;
            }
            if ($details && empty($existing->details)) {
                $updates['details'] = $details;
            }
            if ($updates !== []) {
                $existing->update($updates);
            }

            return $existing;
        }

        return Asset::create([
            'name' => $this->uniqueAssetName($name !== '' && $name !== 'Qualys Host' ? $name : 'Qualys Host', (string) ($row['host_id'] ?? $ip ?? '')),
            'ip' => $ip,
            'os_version' => $osVersion,
            'details' => $details,
            'verified' => 0,
        ]);
    }

    protected function uniqueAssetName(string $name, string $suffix): string
    {
        $name = mb_substr(trim($name) !== '' ? $name : 'Qualys Host', 0, 200);
        if (!Asset::where('name', $name)->exists()) {
            return $name;
        }

        $withSuffix = mb_substr($name . '-' . $suffix, 0, 200);
        if ($suffix !== '' && !Asset::where('name', $withSuffix)->exists()) {
            return $withSuffix;
        }

        return mb_substr($name . '-' . uniqid(), 0, 200);
    }

    /**
     * @param array<string, mixed> $row
     */
    protected function assetDetails(array $row): ?string
    {
        $parts = [];
        foreach ([
            'host_id' => 'Qualys host ID',
            'qualys_asset_id' => 'Qualys asset ID',
            'tracking_method' => 'Tracking',
            'ipv6' => 'IPv6',
            'os' => 'OS',
        ] as $key => $label) {
            if (($row[$key] ?? '') !== '') {
                $parts[] = $label . ': ' . $row[$key];
            }
        }

        return $parts !== [] ? implode("\n", $parts) : null;
    }

    /**
     * @param array<string, mixed> $row
     */
    protected function findExistingVulnerability(array $row, int $assetId): ?Vulnerability
    {
        $uniqueId = $row['unique_vuln_id'];
        if ($uniqueId !== '') {
            $byUnique = Vulnerability::where('bid', $uniqueId)->first();
            if ($byUnique) {
                return $byUnique;
            }
        }

        $pluginId = $row['qid'];
        $port = $this->portInt($row['port']);
        $firstDiscovered = $this->parseQualysDate($row['first_found_datetime']);

        $query = DB::table('vulnerabilities as v')
            ->join('asset_vulnerabilities as av', 'v.id', '=', 'av.vulnerability_id')
            ->where('v.plugin_id', $pluginId)
            ->where('av.asset_id', $assetId);

        if ($port === null) {
            $query->whereNull('v.port');
        } else {
            $query->where('v.port', $port);
        }

        if ($firstDiscovered === null) {
            $query->whereNull('v.first_discovered');
        } else {
            $query->where('v.first_discovered', $firstDiscovered);
        }

        $match = $query->select('v.id')->first();

        return $match ? Vulnerability::find($match->id) : null;
    }

    /**
     * @param array<string, mixed> $v
     * @return array<string, mixed>
     */
    protected function mapDetectionToAttributes(array $v, ?Vulnerability $existing): array
    {
        $qid = $v['qid'];
        $port = $this->portInt($v['port']);
        $ip = $this->ipv4($v['ip']);
        $firstDiscovered = $this->parseQualysDate($v['first_found_datetime']);
        $lastObserved = $this->parseQualysDate($v['last_found_datetime']);
        if ($existing && $lastObserved !== null) {
            $lastObserved = $this->maxDateTimeString($existing->last_observed, $lastObserved);
        }

        $factors = $v['qds_factors'];
        $cvssVersion = strtolower((string) ($factors['cvss_version'] ?? ''));
        $cvssScore = $this->nullIfEmpty($factors['cvss'] ?? $factors['base_score'] ?? null);
        $isClosed = $this->isQualysClosed($v['status']);

        $row = [
            'name' => mb_substr('QID ' . $qid, 0, 255),
            'cve' => $this->nullIfEmpty($v['asset_cve']),
            'description' => $this->nullIfEmpty($v['results']) ?: $existing?->description ?: ('QID ' . $qid),
            'recommendation' => $existing?->recommendation ?: '',
            'plan' => $existing?->plan ?: '',
            'severity' => $this->normalizeQualysSeverity($v['severity']),
            'plugin_id' => $qid,
            'protocol' => $this->nullIfEmpty($v['protocol']),
            'port' => $port,
            'ip_address' => $ip,
            'dns_name' => $this->nullIfEmpty($v['dns'] ?: $v['host_fqdn'] ?: $v['fqdn']),
            'netbios_name' => $this->nullIfEmpty($v['netbios']),
            'first_discovered' => $existing ? $existing->first_discovered : $firstDiscovered,
            'last_observed' => $lastObserved,
            'plugin_output' => $this->nullIfEmpty($v['results']),
            'plugin_modification_date' => $this->parseQualysDate($v['last_update_datetime']),
            'check_type' => $this->nullIfEmpty($v['type']),
            'service' => $this->nullIfEmpty($v['service'] ?: $v['status']),
            'agent_id' => $this->nullIfEmpty($v['qualys_asset_id'] ?: $v['host_id']),
            'version' => $this->nullIfEmpty($v['times_found']),
            'see_also' => $this->nullIfEmpty($v['tags']),
            'cpe' => $this->nullIfEmpty($v['os_cpe'] ?: $v['os']),
            'bid' => $this->nullIfEmpty($v['unique_vuln_id']),
            'family' => 'Qualys',
            'vuln_priority_rating' => $this->nullIfEmpty($v['qds']),
            'stig_severity' => $this->nullIfEmpty($v['qds_severity']),
            'cvss_v2_temporal_score' => $this->nullIfEmpty($factors['temporal_score'] ?? null),
            'cvss_v2_vector' => $this->nullIfEmpty($factors['cvss_vector'] ?? null),
            'exploit_ease' => $this->nullIfEmpty($factors['exploit_maturity'] ?? $factors['rti'] ?? null),
            'exploit_framework' => $this->nullIfEmpty($factors['exploit_available'] ?? null),
            'exploit' => $this->exploitYesNo($factors['exploit_available'] ?? ''),
            'cross_reference' => $this->nullIfEmpty($v['source']),
            'system' => $this->nullIfEmpty($v['os']),
            'steps_to_remediate' => $this->stepsFromFlags($v),
            'tenable_status' => $isClosed ? 'Closed' : 'Open',
        ];

        if ($cvssVersion === 'v3') {
            $row['cvss_v3'] = $cvssScore;
        } else {
            $row['cvss_v2'] = $cvssScore;
        }

        if ($existing === null || ($existing->status ?? '') !== 'Overdue') {
            $row['status'] = $isClosed ? 'Closed' : 'Open';
        }

        if ($existing) {
            $always = ['last_observed', 'status', 'tenable_status', 'plugin_output'];
            $row = array_filter($row, function ($val, $key) use ($always) {
                return in_array($key, $always, true) || ($val !== null && $val !== '');
            }, ARRAY_FILTER_USE_BOTH);
        }

        return $row;
    }

    /**
     * @param array<string, mixed> $row
     */
    protected function assetDisplayName(array $row): string
    {
        foreach (['dns', 'host_fqdn', 'hostname', 'netbios', 'ip', 'host_id'] as $key) {
            if (($row[$key] ?? '') !== '') {
                return mb_substr((string) $row[$key], 0, 200);
            }
        }

        return 'Qualys Host';
    }

    /**
     * @param array<string, mixed> $v
     */
    protected function stepsFromFlags(array $v): ?string
    {
        $lines = [];
        if ($v['is_disabled'] !== '') {
            $lines[] = 'disabled: ' . $v['is_disabled'];
        }
        if ($v['is_ignored'] !== '') {
            $lines[] = 'ignored: ' . $v['is_ignored'];
        }
        if ($v['ssl'] !== '') {
            $lines[] = 'ssl: ' . $v['ssl'];
        }
        if ($v['instance'] !== '') {
            $lines[] = 'instance: ' . $v['instance'];
        }
        if ($v['times_reopened'] !== '') {
            $lines[] = 'times_reopened: ' . $v['times_reopened'];
        }
        if ($v['last_fixed_datetime'] !== '') {
            $lines[] = 'last_fixed: ' . $v['last_fixed_datetime'];
        }
        if ($v['last_reopened_datetime'] !== '') {
            $lines[] = 'last_reopened: ' . $v['last_reopened_datetime'];
        }
        if ($v['last_test_datetime'] !== '') {
            $lines[] = 'last_test: ' . $v['last_test_datetime'];
        }

        return $lines !== [] ? implode("\n", $lines) : null;
    }

    protected function isQualysClosed(string $status): bool
    {
        $s = strtolower(trim($status));

        return $s === 'fixed' || $s === 'closed';
    }

    protected function exploitYesNo(string $raw): ?string
    {
        $v = strtolower(trim($raw));
        if ($v === '' || $v === 'null' || $v === '0' || $v === 'no' || $v === 'false') {
            return $v === '' || $v === 'null' ? null : 'no';
        }

        return 'yes';
    }

    protected function ipv4(string $ip): ?string
    {
        $ip = trim($ip);

        return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) ?: null;
    }

    protected function portInt(string $port): ?int
    {
        $port = trim($port);

        return ($port !== '' && is_numeric($port)) ? (int) $port : null;
    }

    protected function str($value): string
    {
        if ($value === null) {
            return '';
        }

        return trim((string) $value);
    }

    protected function nullIfEmpty(?string $s): ?string
    {
        if ($s === null) {
            return null;
        }
        $t = trim($s);

        return $t === '' ? null : $t;
    }

    protected function parseQualysDate(?string $s): ?string
    {
        if ($s === null || trim($s) === '') {
            return null;
        }
        try {
            return Carbon::parse($s)->format('Y-m-d H:i:s');
        } catch (\Throwable $e) {
            return null;
        }
    }

    protected function maxDateTimeString($current, string $candidate): string
    {
        if ($current === null || $current === '') {
            return $candidate;
        }
        try {
            $a = Carbon::parse($current);
            $b = Carbon::parse($candidate);

            return $b->greaterThan($a) ? $candidate : $current;
        } catch (\Throwable $e) {
            return $candidate;
        }
    }

    protected function normalizeQualysSeverity(string $raw): string
    {
        $s = trim($raw);
        if ($s === '') {
            return 'Low';
        }
        $byNumber = [
            '1' => 'Informational',
            '2' => 'Low',
            '3' => 'Medium',
            '4' => 'High',
            '5' => 'Critical',
        ];
        if (isset($byNumber[$s])) {
            return $byNumber[$s];
        }
        $lower = strtolower($s);
        $byWord = [
            'informational' => 'Informational',
            'info' => 'Informational',
            'low' => 'Low',
            'medium' => 'Medium',
            'high' => 'High',
            'critical' => 'Critical',
            'severe' => 'Critical',
        ];

        return $byWord[$lower] ?? 'Low';
    }
}
