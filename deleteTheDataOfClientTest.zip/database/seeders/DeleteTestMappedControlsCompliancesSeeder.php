<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestMappedControlsCompliancesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::transaction(function () {

            $complianceIds = DB::table('mapped_controls_compliances')
                ->where('name', 'test 1')
                ->pluck('id');

            if ($complianceIds->isEmpty()) {
                return;
            }

            // Delete related control documents
            DB::table('control_compliance_documents')
                ->whereIn('mapped_controls_compliance_id', $complianceIds)
                ->delete();

            // Delete compliance records
            DB::table('mapped_controls_compliances')
                ->whereIn('id', $complianceIds)
                ->delete();
        });
    }
}