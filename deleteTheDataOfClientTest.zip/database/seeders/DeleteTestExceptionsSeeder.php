<?php

namespace Database\Seeders;

use App\Models\Exception;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestExceptionsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $names = [
            'test',
            'risk Exception',
            'Policy Exception',
            'سياسة أمن الشبكات',
            'Policy Exception test',
            'Policy Exception11',
        ];

        DB::transaction(function () use ($names) {

            $exceptionIds = Exception::query()
                ->whereIn('name', $names)
                ->pluck('id');

            if ($exceptionIds->isEmpty()) {
                return;
            }

            DB::table('exception_policy')
                ->whereIn('exception_id', $exceptionIds)
                ->delete();

            DB::table('control_exception')
                ->whereIn('exception_id', $exceptionIds)
                ->delete();

            DB::table('exception_risk')
                ->whereIn('exception_id', $exceptionIds)
                ->delete();

            Exception::query()
                ->whereIn('id', $exceptionIds)
                ->delete();
        });
    }
}