<?php

namespace Database\Seeders;

use App\Models\Nda;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestNdasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::transaction(function () {

            $ndaIds = Nda::query()
                ->where(function ($query) {
                    $query->where('name_ar', 'تجربه')
                          ->orWhere('name_en', 'تجربه');
                })
                ->pluck('id');

            if ($ndaIds->isEmpty()) {
                return;
            }

            // Delete NDA results
            DB::table('nda_results')
                ->whereIn('nda_id', $ndaIds)
                ->delete();

            // Delete NDA receivers
            DB::table('nda_receivers')
                ->whereIn('nda_id', $ndaIds)
                ->delete();

            // Delete NDAs
            Nda::query()
                ->whereIn('id', $ndaIds)
                ->delete();
        });
    }
}