<?php

namespace Database\Seeders;

use App\Models\Risk;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DeleteTestRisksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::transaction(function () {

            $riskIds = range(1, 10);

            // Get mitigation ids
            $mitigationIds = DB::table('mitigations')
                ->whereIn('risk_id', $riskIds)
                ->pluck('id');

            /*
            |--------------------------------------------------------------------------
            | Delete Files Directories
            |--------------------------------------------------------------------------
            */
            foreach ($riskIds as $riskId) {
                Storage::deleteDirectory("risk/{$riskId}");
            }

            foreach ($mitigationIds as $mitigationId) {
                Storage::deleteDirectory("risk_mitigation/{$mitigationId}");
            }

            /*
            |--------------------------------------------------------------------------
            | Files
            |--------------------------------------------------------------------------
            */
            DB::table('files')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Management Reviews
            |--------------------------------------------------------------------------
            */
            DB::table('mgmt_reviews')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Residual Risk Scoring History
            |--------------------------------------------------------------------------
            */
            DB::table('residual_risk_scoring_histories')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Risk Scoring
            |--------------------------------------------------------------------------
            */
            DB::table('risk_scorings')
                ->whereIn('id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Risk Locations
            |--------------------------------------------------------------------------
            */
            DB::table('risk_to_locations')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Risk Teams
            |--------------------------------------------------------------------------
            */
            DB::table('risk_to_teams')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Risk Technologies
            |--------------------------------------------------------------------------
            */
            DB::table('risk_to_technologies')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Additional Stakeholders
            |--------------------------------------------------------------------------
            */
            DB::table('risk_to_additional_stakeholders')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Tags (Morph Relation)
            |--------------------------------------------------------------------------
            */
            DB::table('taggables')
                ->where('taggable_type', Risk::class)
                ->whereIn('taggable_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Mitigation Relations
            |--------------------------------------------------------------------------
            */
            DB::table('mitigation_to_controls')
                ->whereIn('mitigation_id', $mitigationIds)
                ->delete();

            DB::table('mitigation_to_teams')
                ->whereIn('mitigation_id', $mitigationIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Mitigations
            |--------------------------------------------------------------------------
            */
            DB::table('mitigations')
                ->whereIn('risk_id', $riskIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Risks
            |--------------------------------------------------------------------------
            */
            DB::table('risks')
                ->whereIn('id', $riskIds)
                ->delete();
        });
    }
}