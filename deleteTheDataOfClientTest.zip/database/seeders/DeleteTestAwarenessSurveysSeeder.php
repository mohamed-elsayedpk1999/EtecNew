<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestAwarenessSurveysSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::transaction(function () {

            $surveyIds = DB::table('awareness_surveys')
                ->where('name', 'فثسف')
                ->pluck('id');

            if ($surveyIds->isEmpty()) {
                return;
            }

            $questionIds = DB::table('survey_questions')
                ->whereIn('survey_id', $surveyIds)
                ->pluck('id');

            // Answers submitted by users
            DB::table('answer_question_surveys')
                ->whereIn('survey_id', $surveyIds)
                ->delete();

            // Question choices/options
            DB::table('survey_question_answers')
                ->whereIn('question_id', $questionIds)
                ->delete();

            // Survey responses
            DB::table('survey_responses')
                ->whereIn('survey_id', $surveyIds)
                ->delete();

            // Questions
            DB::table('survey_questions')
                ->whereIn('survey_id', $surveyIds)
                ->delete();

            // Survey
            DB::table('awareness_surveys')
                ->whereIn('id', $surveyIds)
                ->delete();
        });
    }
}