<?php

namespace Database\Seeders;

use App\Models\Task;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class DeleteTestTasksSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::transaction(function () {

            $tasks = Task::query()
                ->where('title', 'مهمة التزام - تجربة')
                ->get();

            foreach ($tasks as $task) {

                // Delete uploaded files directory
                Storage::deleteDirectory('task/' . $task->id);

                // Delete file records
                DB::table('file_tasks')
                    ->where('task_id', $task->id)
                    ->delete();

                // Delete task
                $task->delete();
            }
        });
    }
}