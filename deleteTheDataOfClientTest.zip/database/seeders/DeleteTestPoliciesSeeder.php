<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DeleteTestPoliciesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::transaction(function () {

            // Get Policy IDs by JSON name (EN or AR)
            $policyIds = DB::table('center_policies')
                ->whereIn(
                    DB::raw('JSON_UNQUOTE(JSON_EXTRACT(policy_name, "$.en"))'),
                    [
                        'test',
                        'بند تجريبي',
                        'بند تجريبي 1',
                    ]
                )
                ->orWhereIn(
                    DB::raw('JSON_UNQUOTE(JSON_EXTRACT(policy_name, "$.ar"))'),
                    [
                        'test',
                        'بند تجريبي',
                        'بند تجريبي 1',
                    ]
                )
                ->pluck('id');

            if ($policyIds->isEmpty()) {
                return;
            }

            // Get Document Policies
            $documentPolicyIds = DB::table('document_policies')
                ->whereIn('policy_id', $policyIds)
                ->pluck('id');

            /*
            |--------------------------------------------------------------------------
            | Audit Relations
            |--------------------------------------------------------------------------
            */

            DB::table('audit_document_policy_policy_document')
                ->whereIn('policy_document_id', $documentPolicyIds)
                ->delete();

            DB::table('audit_document_policy_statuses')
                ->whereIn('document_policy_id', $documentPolicyIds)
                ->delete();

            DB::table('audit_document_policy_comments')
                ->whereIn('document_policy_id', $documentPolicyIds)
                ->delete();

            DB::table('audit_document_policy_files')
                ->whereIn('document_policy_id', $documentPolicyIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Document Policies
            |--------------------------------------------------------------------------
            */

            DB::table('document_policies')
                ->whereIn('id', $documentPolicyIds)
                ->delete();

            /*
            |--------------------------------------------------------------------------
            | Center Policies
            |--------------------------------------------------------------------------
            */

            DB::table('center_policies')
                ->whereIn('id', $policyIds)
                ->delete();
        });
    }
}