<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Subgroup;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ControlMappingPermissionSeeder extends Seeder
{
    /**
     * Add the control mapping permission under the Controls group.
     *
     * @return void
     */
    public function run()
    {
        $subgroup = Subgroup::where('name', 'Controls')->first();

        if (!$subgroup) {
            $this->command->error('Controls subgroup was not found. Mapping permission was not added.');
            return;
        }

        $permission = Permission::firstOrCreate(
            ['key' => 'control.mapping'],
            [
                'name' => 'mapping',
                'subgroup_id' => $subgroup->id,
            ]
        );

        if ((int) $permission->subgroup_id !== (int) $subgroup->id) {
            $permission->update([
                'name' => 'mapping',
                'subgroup_id' => $subgroup->id,
            ]);
        }

        DB::table('role_responsibilities')->updateOrInsert(
            [
                'role_id' => 1,
                'permission_id' => $permission->id,
            ],
            [
                'role_id' => 1,
                'permission_id' => $permission->id,
            ]
        );
    }
}
