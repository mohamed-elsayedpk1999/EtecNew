<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/katex.min.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/monokai-sublime.min.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/quill.snow.css')) }}">
<link rel="stylesheet" href="{{ asset(mix('vendors/css/editors/quill/quill.bubble.css')) }}">
<style>
    body {
        background-color: #f4f4f4;
    }

    .form-container {
        max-width: 100%;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .form-label {
        color: #333;
        font-weight: bold;
    }

    .form-control,
    .form-select {
        background-color: #f9f9fa;
        border: 1px solid #ced4da;
        border-radius: 4px;
        color: #495057;
    }

    .form-control:disabled,
    .form-select:disabled {
        background-color: #f1f3f5;
    }

    .form-check-input:checked {
        background-color: #007bff;
        border-color: #007bff;
    }

    .form-check-label {
        color: #333;
    }

    .btn-primary {
        background-color: #007bff;
        border-color: #007bff;
        color: #fff;
    }

    .btn-primary:hover {
        background-color: #0056b3;
        border-color: #004085;
    }

    .btn-outline-primary {
        color: #007bff;
        border-color: #007bff;
    }

    .btn-outline-primary:hover {
        color: #0056b3;
        border-color: #004085;
    }

    .error {
        color: #dc3545;
    }

    .text-muted {
        color: #6c757d;
    }

    .btn-guide {
        display: inline-block;
        padding: 8px 16px;
        font-size: 14px;
        font-weight: 500;
        color: #fff;
        background-color: #17a2b8;
        border-radius: 4px;
        text-align: center;
        cursor: pointer;
        text-decoration: none;
        border: 1px solid #17a2b8;
    }

    .btn-guide:hover {
        background-color: #138496;
        border-color: #117a8b;
    }

    .btn-guide:focus {
        outline: none;
    }

    .clickable-link {
        color: #007bff;
        text-decoration: underline;
        cursor: pointer;
    }

    .clickable-link:hover {
        color: #0056b3;
        text-decoration: none;
    }

    .clickable-link i {
        font-size: 16px;
        color: #007bff;
    }

    /* Custom searchable select styles */
    .custom-select-wrapper {
        position: relative;
    }

    .custom-select-wrapper .search-input-wrapper {
        position: relative;
    }

    .custom-select-wrapper .search-input-wrapper input {
        width: 100%;
        cursor: pointer;
        background-color: #f9f9fa;
    }

    .custom-select-wrapper .search-input-wrapper .arrow-icon {
        position: absolute;
        right: 10px;
        top: 50%;
        transform: translateY(-50%);
        pointer-events: none;
        color: #6c757d;
        font-size: 12px;
        transition: transform 0.2s;
    }

    .custom-select-wrapper .search-input-wrapper .arrow-icon.open {
        transform: translateY(-50%) rotate(180deg);
    }

    .custom-dropdown-list {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        z-index: 9999;
        background: #fff;
        border: 1px solid #ced4da;
        border-top: none;
        border-radius: 0 0 4px 4px;
        max-height: 200px;
        overflow-y: auto;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }

    .custom-dropdown-list.show {
        display: block;
    }

    .custom-dropdown-list .dropdown-item-custom {
        padding: 8px 12px;
        cursor: pointer;
        font-size: 14px;
        color: #495057;
        border-bottom: 1px solid #f1f1f1;
    }

    .custom-dropdown-list .dropdown-item-custom:hover,
    .custom-dropdown-list .dropdown-item-custom.active {
        background-color: #007bff;
        color: #fff;
    }

    .custom-dropdown-list .dropdown-item-custom.no-results {
        color: #6c757d;
        cursor: default;
        font-style: italic;
    }

    .custom-dropdown-list .dropdown-item-custom.no-results:hover {
        background-color: #fff;
        color: #6c757d;
    }
</style>

<div>
    <div class="container-fluid mt-4">
        <div class="form-container">
            <form class="audit-update" id="submit-audit-update"
                action="{{ route('admin.compliance.ajax.aduit-details.updateCurrentAduit') }}" method="POST">
                @csrf
                <input type="hidden" name="id" value="{{ $id }}">
                <input type="hidden" value="{{ $existingUserOrTeam->responsible_type }}" name="responsible_type"
                    id="responsible_type">

                <div class="row gy-3">
                    <!-- Summary -->
                    <div class="col-12">
                        <div class="form-group">
                            <label class="form-label" for="summary">{{ __('locale.Summary') }}</label>
                            <textarea class="form-control" id="summary" rows="3" name="summary"
                                placeholder="{{ __('locale.Enter summary here...') }}" {{ $editable ? '' : 'disabled' }}>{{ $frameworkControlTestResult->summary }}</textarea>
                            <span class="text-danger error error-summary"></span>
                        </div>
                    </div>

                    <!-- Remediation Needed -->
                    <div class="col-12">
                        <label class="form-label d-block">{{ __('locale.Remediation Needed?') }}</label>
                        <div class="d-inline-block me-3">
                            <input class="form-check-input" type="radio" name="remediation" id="remediation_yes"
                                value="1" {{ $frameworkControlTestResult->remediation == '1' ? 'checked' : '' }}
                                {{ $editable ? '' : 'disabled' }}>
                            <label class="form-check-label ms-2" for="remediation_yes">{{ __('locale.Yes') }}</label>
                        </div>
                        <div class="d-inline-block">
                            <input class="form-check-input" type="radio" name="remediation" id="remediation_no"
                                value="0" {{ $frameworkControlTestResult->remediation == '0' ? 'checked' : '' }}
                                {{ $editable ? '' : 'disabled' }}>
                            <label class="form-check-label ms-2" for="remediation_no">{{ __('locale.No') }}</label>
                        </div>
                        @if ($frameworkControlTestResult->remediation != '0')
                            <span class="clickable-link ms-3" data-bs-toggle="modal" data-bs-target="#remediationModal">
                                <i class="fas fa-arrow-right me-2"></i>{{ __('locale.Remediation Details') }}
                            </span>
                        @endif
                    </div>

                    <!-- Action Dropdown -->
                    <div class="col-xl-6 col-md-6 col-12">
                        <div class="form-group">
                            <label class="form-label" for="action_status">{{ __('compliance.AuditStatus') }}</label>
                            <select class="form-select" id="action_status" name="action_status"
                                {{ $editable ? '' : 'disabled' }}>
                                <option value="0" {{ $frameworkControlTestAudit->action_status == 0 ? 'selected' : '' }}>
                                    {{ __('locale.Open') }}
                                </option>
                                <option value="1" {{ $frameworkControlTestAudit->action_status == 1 ? 'selected' : '' }}>
                                    {{ __('locale.Closed') }}
                                </option>
                            </select>
                            <span class="text-danger error error-action_status"></span>
                        </div>
                    </div>

                    <!-- Teams -->
                    <div class="col-xl-6 col-md-6 col-12">
                        <div class="mb-1">
                            @php
                                $label = $existingUserOrTeam->responsible_type == 'users'
                                    ? __('locale.Users')
                                    : __('locale.Teams');
                            @endphp
                            <label class="form-label" for="teams">{{ $label }}</label>
                            <select class="form-select multiple-select2" name="teams[]" id="teams"
                                multiple="multiple" {{ $editable ? '' : 'disabled' }}>
                                <option select disabled value="">{{ __('locale.select-option') }}</option>
                                @foreach ($teams as $team)
                                    <option value="{{ $team->id }}" {{ optionMultiSelect($team->id, $testTeams) }}>
                                        {{ $team->name }}
                                    </option>
                                @endforeach
                            </select>
                            <span class="error error-teams"></span>
                        </div>
                    </div>

                    @if ($editable)
                        <div class="col-12 d-flex justify-content-end mt-4">
                            <button type="button" class="btn btn-primary me-2" data-bs-toggle="modal"
                                data-bs-target="#remediationModal">
                                {{ __('locale.Remediation Details') }}
                            </button>
                            <button type="button" id="submit-audit" class="btn btn-primary">
                                {{ __('locale.Submit') }}
                            </button>
                        </div>
                    @endif
                </div>
            </form>
        </div>
    </div>
</div>


<!-- Modal for Remediation Details -->
<div class="modal fade" id="remediationModal" tabindex="-1" aria-labelledby="remediationModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">{{ __('locale.Remediation Details') }}</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form id="remediationForm">
                    @csrf
                    <div class="row">

                        <!-- Select User with Custom Searchable Dropdown -->
                        <div class="col-xl-6 col-md-6 col-12">
                            <div class="mb-1">
                                <label class="form-label">{{ __('locale.Responsible User') }}</label>

                                <!-- Hidden actual select for form submission -->
                                <select id="responsible_user" name="responsible_user" style="display:none;">
                                    <option value="">{{ __('locale.select-option') }}</option>
                                    @foreach ($enabledUsers as $user)
                                        <option value="{{ $user->id }}"
                                            {{ (isset($remediationDetails) && $remediationDetails->responsible_user == $user->id) || $user->id == $controlOwner ? 'selected' : '' }}>
                                            {{ $user->name }}
                                        </option>
                                    @endforeach
                                </select>

                                <!-- Custom visible searchable dropdown -->
                                <div class="custom-select-wrapper" id="user-select-wrapper">
                                    <div class="search-input-wrapper">
                                        <input type="text" id="responsible_user_display"
                                            class="form-control"
                                            placeholder="{{ __('locale.Search users...') }}"
                                            autocomplete="off"
                                            {{ $editable ? '' : 'disabled' }}
                                            readonly>
                                        <span class="arrow-icon" id="user-arrow-icon">&#9660;</span>
                                    </div>
                                    <div class="custom-dropdown-list" id="user-dropdown-list">
                                        <!-- Options rendered by JS -->
                                    </div>
                                </div>

                            </div>
                        </div>

                        <!-- Budgetary -->
                        <div class="col-xl-6 col-md-6 col-12">
                            <div class="mb-1">
                                <label class="form-label" for="budgetary">{{ __('locale.Budgetary') }}</label>
                                <input type="number" class="form-control" id="budgetary" name="budgetary" disabled
                                    value="{{ isset($remediationDetails) ? $remediationDetails->budgetary : '' }}">
                            </div>
                        </div>

                        <input type="hidden" name="controlTestId" value="{{ $id }}">

                        <!-- Status -->
                        <div class="col-xl-6 col-md-6 col-12">
                            <div class="mb-1">
                                <label class="form-label" for="status">{{ __('locale.Status') }}</label>
                                <select class="form-select" id="status" name="status" disabled>
                                    <option value="" disabled>{{ __('locale.select-option') }}</option>
                                    <option value="1" {{ isset($remediationDetails) && $remediationDetails->status == 1 ? 'selected' : '' }}>
                                        {{ __('locale.Approved') }}
                                    </option>
                                    <option value="2" {{ isset($remediationDetails) && $remediationDetails->status == 2 ? 'selected' : '' }}>
                                        {{ __('locale.Rejected') }}
                                    </option>
                                </select>
                            </div>
                        </div>

                        <!-- Due Date -->
                        <div class="col-xl-6 col-md-6 col-12">
                            <div class="mb-1">
                                <label class="form-label" for="due_date">{{ __('locale.Due Date') }}</label>
                                <input type="date" class="form-control flatpickr-date-time-compliance"
                                    id="due_date" name="due_date"
                                    value="{{ isset($remediationDetails) ? $remediationDetails->due_date : '' }}">
                            </div>
                        </div>

                        <!-- Comments -->
                        <div class="col-12">
                            <div class="mb-1">
                                <label class="form-label" for="comments">{{ __('locale.Comments') }}</label>
                                <textarea class="form-control" id="comments" name="comments" rows="2">{{ isset($remediationDetails) ? $remediationDetails->comments : '' }}</textarea>
                            </div>
                        </div>

                        <!-- Corrective Action Plan -->
                        <div class="mb-1 col-12">
                            <label class="form-label">{{ __('locale.Corrective') }}</label>
                            <div id="corrective_action_plan_editor" style="height:100px;">
                                {!! isset($remediationDetails) ? $remediationDetails->corrective_action_plan : '' !!}
                            </div>
                        </div>
                        <input type="hidden" name="corrective_action_plan" id="corrective_action_plan_hidden">

                    </div>
                </form>
            </div>

            @if ($editable)
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                    <button type="button" class="btn btn-primary" id="saveChangesBtnRemidation">{{ __('locale.Save Changes') }}</button>
                </div>
            @endif
        </div>
    </div>
</div>

<script src="{{ asset('cdn/jquery6.js') }}"></script>
<script src="{{ asset(mix('vendors/js/editors/quill/quill.min.js')) }}"></script>

<script>
    let quill = null;

    // ─── Build users array from hidden select ───────────────────────────────────
    function getUserOptions() {
        const select = document.getElementById('responsible_user');
        return Array.from(select.options)
            .filter(o => o.value !== '')
            .map(o => ({ value: o.value, text: o.text.trim() }));
    }

    // ─── Render dropdown list items ─────────────────────────────────────────────
    function renderDropdownItems(filter = '') {
        const list = document.getElementById('user-dropdown-list');
        const users = getUserOptions();
        const filtered = filter
            ? users.filter(u => u.text.toLowerCase().includes(filter.toLowerCase()))
            : users;

        list.innerHTML = '';

        if (filtered.length === 0) {
            list.innerHTML = '<div class="dropdown-item-custom no-results">{{ __('locale.No results found') }}</div>';
            return;
        }

        const currentVal = document.getElementById('responsible_user').value;

        filtered.forEach(function (user) {
            const item = document.createElement('div');
            item.className = 'dropdown-item-custom' + (user.value === currentVal ? ' active' : '');
            item.textContent = user.text;
            item.dataset.value = user.value;
            item.addEventListener('mousedown', function (e) {
                e.preventDefault(); // prevent blur before click
                selectUser(user.value, user.text);
            });
            list.appendChild(item);
        });
    }

    // ─── Select a user ───────────────────────────────────────────────────────────
    function selectUser(value, text) {
        document.getElementById('responsible_user').value = value;
        document.getElementById('responsible_user_display').value = text;
        closeUserDropdown();
    }

    // ─── Open dropdown ───────────────────────────────────────────────────────────
    function openUserDropdown() {
        const display = document.getElementById('responsible_user_display');
        display.readOnly = false;
        display.select();
        renderDropdownItems('');
        document.getElementById('user-dropdown-list').classList.add('show');
        document.getElementById('user-arrow-icon').classList.add('open');
    }

    // ─── Close dropdown ──────────────────────────────────────────────────────────
    function closeUserDropdown() {
        const select = document.getElementById('responsible_user');
        const display = document.getElementById('responsible_user_display');
        // Restore display to currently selected text
        const selected = Array.from(select.options).find(o => o.value === select.value);
        if (selected) display.value = selected.text.trim();
        display.readOnly = true;
        document.getElementById('user-dropdown-list').classList.remove('show');
        document.getElementById('user-arrow-icon').classList.remove('open');
    }

    document.addEventListener('DOMContentLoaded', function () {
        const remediationYes    = document.getElementById('remediation_yes');
        const remediationModal  = document.getElementById('remediationModal');
        const modalInstance     = new bootstrap.Modal(remediationModal);
        const displayInput      = document.getElementById('responsible_user_display');

        // Open modal when remediation Yes is selected
        remediationYes.addEventListener('change', function () {
            if (this.checked) modalInstance.show();
        });

        // ── Set initial display value ──────────────────────────────────────────
        remediationModal.addEventListener('shown.bs.modal', function () {

            // Set display input to currently selected user name
            const select   = document.getElementById('responsible_user');
            const selected = Array.from(select.options).find(o => o.value === select.value);
            if (selected) displayInput.value = selected.text.trim();

            // Initialize Quill
            if (!quill) {
                quill = new Quill('#corrective_action_plan_editor', {
                    theme: 'snow',
                    modules: {
                        toolbar: [
                            [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
                            ['bold', 'italic', 'underline', 'strike'],
                            [{ 'list': 'ordered' }, { 'list': 'bullet' }],
                            [{ 'indent': '-1' }, { 'indent': '+1' }],
                            [{ 'direction': 'rtl' }],
                            ['clean'],
                        ],
                    },
                });
            }
        });

        // ── Cleanup on modal close ─────────────────────────────────────────────
        remediationModal.addEventListener('hide.bs.modal', function () {
            closeUserDropdown();
            if (quill) quill = null;
        });

        // ── Toggle dropdown on click ───────────────────────────────────────────
        displayInput.addEventListener('click', function () {
            const isOpen = document.getElementById('user-dropdown-list').classList.contains('show');
            if (isOpen) {
                closeUserDropdown();
            } else {
                openUserDropdown();
            }
        });

        // ── Filter on typing ───────────────────────────────────────────────────
        displayInput.addEventListener('input', function () {
            renderDropdownItems(this.value);
            document.getElementById('user-dropdown-list').classList.add('show');
            document.getElementById('user-arrow-icon').classList.add('open');
        });

        // ── Close when clicking outside ────────────────────────────────────────
        document.addEventListener('click', function (e) {
            const wrapper = document.getElementById('user-select-wrapper');
            if (wrapper && !wrapper.contains(e.target)) {
                closeUserDropdown();
            }
        });
    });


    $(document).ready(function () {

        $('#saveChangesBtnRemidation').on('click', function () {
            var correctiveActionPlan = quill.root.innerHTML;
            $('#corrective_action_plan_hidden').val(correctiveActionPlan);

            var formData = $('#remediationForm').serialize();

            $.ajax({
                url: "{{ route('admin.compliance.ajax.remediation-details.store') }}",
                type: 'POST',
                data: formData,
                success: function (response) {
                    if (response.success) {
                        makeAlert('success', response.message, "{{ __('locale.Success') }}");
                        $('#remediationModal').modal('hide');
                    } else {
                        showError(response.errors);
                    }
                },
                error: function (response) {
                    var responseData = response.responseJSON;
                    makeAlert('error', responseData.message, "{{ __('locale.Error') }}");
                    showError(responseData.errors);
                }
            });
        });

        $('#submit-audit').on('click', function (e) {
            e.preventDefault();

            var form = $('#submit-audit-update');
            var data = new FormData(form[0]);
            var url  = form.attr('action');

            $.ajax({
                url: url,
                type: 'POST',
                data: data,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (response) {
                    makeAlert('success', response.message, "{{ __('locale.Success') }}");
                },
                error: function (xhr) {
                    var responseData = xhr.responseJSON;
                    makeAlert('error', responseData.message || "{{ __('locale.Error') }}", "{{ __('locale.Error') }}");

                    $('.text-danger.error').text('');

                    if (responseData.errors) {
                        $.each(responseData.errors, function (key, value) {
                            var errorSpan = $('.error-' + key);
                            if (errorSpan.length) {
                                errorSpan.text(value[0]);
                            }
                        });
                    }
                }
            });
        });
    });
</script>