<?php

namespace App\Console\Commands;

use App\Models\Asset;
use App\Models\QualysSyncHistory;
use App\Services\QualysVulnPullService;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Http\Client\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

/**
 * Runs the real Qualys vulnerability sync against fake Qualys API responses
 * (Detection API + KnowledgeBase API), for local testing only.
 */
class FakeQualysSync extends Command
{
    protected $signature = 'qualys:fake-sync {--hosts=60 : Number of fake hosts} {--seed=42 : Random seed}';

    protected $description = 'Test the Qualys vulnerability sync with fake Qualys API responses';

    /** @var array<int, array<string, mixed>> */
    protected $catalog = [
        38167 => ['title' => 'SSL Certificate - Expired', 'category' => 'General remote services', 'sev' => 4, 'cves' => [], 'cvss3' => '7.5', 'patch' => false, 'port' => 443, 'proto' => 'tcp'],
        38739 => ['title' => 'Deprecated SSH Cryptographic Settings', 'category' => 'General remote services', 'sev' => 4, 'cves' => ['CVE-2008-5161'], 'cvss3' => '5.9', 'patch' => false, 'port' => 22, 'proto' => 'tcp'],
        38913 => ['title' => 'OpenSSH Remote Code Execution Vulnerability (regreSSHion)', 'category' => 'General remote services', 'sev' => 5, 'cves' => ['CVE-2024-6387'], 'cvss3' => '8.1', 'patch' => true, 'port' => 22, 'proto' => 'tcp'],
        91975 => ['title' => 'Microsoft Windows Security Update for October 2024', 'category' => 'Windows', 'sev' => 5, 'cves' => ['CVE-2024-43572', 'CVE-2024-43573', 'CVE-2024-43583'], 'cvss3' => '9.8', 'patch' => true, 'port' => null, 'proto' => null],
        92102 => ['title' => 'Microsoft Windows Remote Desktop Licensing Service RCE', 'category' => 'Windows', 'sev' => 5, 'cves' => ['CVE-2024-38077'], 'cvss3' => '9.8', 'patch' => true, 'port' => 3389, 'proto' => 'tcp'],
        91540 => ['title' => 'Microsoft SMBv1 Server Enabled', 'category' => 'Windows', 'sev' => 4, 'cves' => ['CVE-2017-0144'], 'cvss3' => '8.1', 'patch' => true, 'port' => 445, 'proto' => 'tcp'],
        376209 => ['title' => 'Apache Log4j Remote Code Execution (Log4Shell)', 'category' => 'Local', 'sev' => 5, 'cves' => ['CVE-2021-44228', 'CVE-2021-45046'], 'cvss3' => '10.0', 'patch' => true, 'port' => 8080, 'proto' => 'tcp'],
        379421 => ['title' => 'Oracle Java SE Critical Patch Update - July 2024', 'category' => 'Local', 'sev' => 4, 'cves' => ['CVE-2024-21147', 'CVE-2024-21145'], 'cvss3' => '7.4', 'patch' => true, 'port' => null, 'proto' => null],
        11827 => ['title' => 'HTTP TRACE / TRACK Methods Enabled', 'category' => 'CGI', 'sev' => 4, 'cves' => ['CVE-2004-2320'], 'cvss3' => '5.3', 'patch' => false, 'port' => 80, 'proto' => 'tcp'],
        150004 => ['title' => 'Path-Relative Stylesheet Import (PRSSI) Vulnerability', 'category' => 'Web Application', 'sev' => 4, 'cves' => [], 'cvss3' => '6.1', 'patch' => false, 'port' => 443, 'proto' => 'tcp'],
        150123 => ['title' => 'Apache HTTP Server Multiple Vulnerabilities (2.4.59)', 'category' => 'Web server', 'sev' => 5, 'cves' => ['CVE-2024-38476', 'CVE-2024-38474'], 'cvss3' => '9.8', 'patch' => true, 'port' => 443, 'proto' => 'tcp'],
        6000134 => ['title' => 'Ubuntu Security Notification for Linux Kernel (USN-6950-1)', 'category' => 'Ubuntu', 'sev' => 4, 'cves' => ['CVE-2024-26925', 'CVE-2024-36016'], 'cvss3' => '7.8', 'patch' => true, 'port' => null, 'proto' => null],
        6000211 => ['title' => 'Ubuntu Security Notification for OpenSSL (USN-6937-1)', 'category' => 'Ubuntu', 'sev' => 4, 'cves' => ['CVE-2024-5535'], 'cvss3' => '9.1', 'patch' => true, 'port' => null, 'proto' => null],
        105489 => ['title' => 'Microsoft Windows Unquoted Service Path Enumeration', 'category' => 'Security Policy', 'sev' => 4, 'cves' => [], 'cvss3' => '7.8', 'patch' => false, 'port' => null, 'proto' => null],
        19824 => ['title' => 'MySQL Server Multiple Vulnerabilities (CPU Jul 2024)', 'category' => 'Database', 'sev' => 4, 'cves' => ['CVE-2024-21171'], 'cvss3' => '6.5', 'patch' => true, 'port' => 3306, 'proto' => 'tcp'],
        730865 => ['title' => 'VMware ESXi Authentication Bypass Vulnerability (VMSA-2024-0013)', 'category' => 'Hardware', 'sev' => 5, 'cves' => ['CVE-2024-37085'], 'cvss3' => '7.2', 'patch' => true, 'port' => 443, 'proto' => 'tcp'],
        48118 => ['title' => 'Default or Weak Credentials Detected on Remote Service', 'category' => 'Information gathering', 'sev' => 5, 'cves' => [], 'cvss3' => '9.8', 'patch' => false, 'port' => 23, 'proto' => 'tcp'],
        43542 => ['title' => 'Cisco IOS XE Web UI Privilege Escalation', 'category' => 'Cisco', 'sev' => 5, 'cves' => ['CVE-2023-20198'], 'cvss3' => '10.0', 'patch' => true, 'port' => 443, 'proto' => 'tcp'],
    ];

    /** @var array<int, array<string, mixed>> */
    protected $hosts = [];

    public function handle(): int
    {
        mt_srand((int) $this->option('seed'));
        $this->buildHosts(max(1, (int) $this->option('hosts')));

        Http::fake(function (Request $request) {
            parse_str((string) parse_url($request->url(), PHP_URL_QUERY), $query);
            $path = (string) parse_url($request->url(), PHP_URL_PATH);

            if (strpos($path, 'knowledge_base') !== false) {
                return Http::response($this->knowledgeBaseXml($query), 200);
            }
            if (strpos($path, 'vm/detection') !== false) {
                return Http::response($this->detectionXml($query, $request->url()), 200);
            }
            if (preg_match('#/fo/asset/host/?$#', $path)) {
                return Http::response($this->hostIdListXml(), 200);
            }

            return Http::response('Not faked', 404);
        });

        QualysSyncHistory::where('type', 'Vulnerability')->where('status', 1)->update(['status' => 2, 'error' => 'Replaced by fake sync']);
        $history = QualysSyncHistory::create([
            'type' => 'Vulnerability',
            'processed' => 0,
            'total' => null,
            'imported' => 0,
            'failed' => 0,
            'status' => 1,
        ]);

        $this->info('Running the Qualys sync with ' . count($this->hosts) . ' fake hosts...');
        (new QualysVulnPullService())->collectAndDispatch($history);
        $history->refresh();

        $this->table(['Result', 'Value'], [
            ['History status', $history->status === 0 ? 'Completed' : ($history->status === 2 ? 'Failed' : 'Running')],
            ['Detections imported', $history->imported],
            ['Detections failed', $history->failed],
            ['Vulnerabilities (Qualys)', DB::table('vulnerabilities')->where('family', 'Qualys')->count()],
            ['Unique QIDs', DB::table('vulnerabilities')->where('family', 'Qualys')->distinct()->count('qualys_qid')],
            ['Assets', Asset::count()],
            ['KnowledgeBase entries', DB::table('qualys_knowledge_base')->count()],
        ]);

        return $history->status === 0 ? 0 : 1;
    }

    protected function buildHosts(int $count): void
    {
        $profiles = [
            ['prefix' => 'srv-app', 'subnet' => 10, 'os' => 'Ubuntu 22.04.4 LTS', 'qids' => [38167, 38739, 38913, 376209, 379421, 150123, 6000134, 6000211, 11827, 150004]],
            ['prefix' => 'srv-db', 'subnet' => 11, 'os' => 'Red Hat Enterprise Linux 8.9', 'qids' => [38739, 38913, 19824, 379421, 48118]],
            ['prefix' => 'ws', 'subnet' => 20, 'os' => 'Windows 11 Enterprise 23H2', 'qids' => [91975, 91540, 105489, 379421, 92102]],
            ['prefix' => 'srv-win', 'subnet' => 12, 'os' => 'Windows Server 2019 Datacenter', 'qids' => [91975, 92102, 91540, 105489, 38167]],
            ['prefix' => 'dmz-web', 'subnet' => 30, 'os' => 'Ubuntu 20.04.6 LTS', 'qids' => [38167, 150123, 11827, 150004, 376209, 6000211]],
            ['prefix' => 'net', 'subnet' => 40, 'os' => 'Cisco IOS XE 17.3', 'qids' => [43542, 48118, 38739]],
            ['prefix' => 'esx', 'subnet' => 50, 'os' => 'VMware ESXi 7.0 U3', 'qids' => [730865, 38167]],
        ];

        $counters = [];
        for ($i = 0; $i < $count; $i++) {
            $profile = $profiles[$i % count($profiles)];
            $n = ($counters[$profile['prefix']] = ($counters[$profile['prefix']] ?? 0) + 1);
            $hostname = sprintf('%s-%02d', $profile['prefix'], $n);
            $this->hosts[] = [
                'id' => 200001 + $i,
                'asset_id' => 9000001 + $i,
                'ip' => sprintf('10.20.%d.%d', $profile['subnet'], 10 + $n),
                'hostname' => $hostname,
                'fqdn' => $hostname . '.lab.local',
                'netbios' => strtoupper(str_replace('-', '', $hostname)),
                'os' => $profile['os'],
                'tags' => [ucfirst(explode('-', $profile['prefix'])[0]), 'Fake Data'],
                'detections' => $this->buildDetections(200001 + $i, $profile['qids']),
            ];
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    protected function buildDetections(int $hostId, array $qids): array
    {
        shuffle($qids);
        $picked = array_slice($qids, 0, mt_rand(2, count($qids)));
        $now = Carbon::now();
        $detections = [];

        foreach ($picked as $index => $qid) {
            $kb = $this->catalog[$qid];
            $first = $now->copy()->subDays(mt_rand(3, 420))->subMinutes(mt_rand(0, 1440));
            $roll = mt_rand(1, 100);
            $status = $roll <= 15 ? 'New' : ($roll <= 70 ? 'Active' : ($roll <= 80 ? 'Re-Opened' : 'Fixed'));
            if ($status === 'New') {
                $first = $now->copy()->subDays(mt_rand(0, 6));
            }
            $lastFixed = null;
            $lastFound = $now->copy()->subDays(mt_rand(0, 3));
            if ($status === 'Fixed') {
                $lastFixed = $first->copy()->addDays(mt_rand(1, max(1, $first->diffInDays($now))));
                $lastFound = $lastFixed->copy()->subDays(mt_rand(1, 5));
                if ($lastFound->lessThan($first)) {
                    $lastFound = $first->copy();
                }
            }
            $qds = $kb['sev'] === 5 ? mt_rand(72, 100) : mt_rand(35, 89);

            $detections[] = [
                'unique_vuln_id' => $hostId * 100 + $index,
                'qid' => $qid,
                'type' => mt_rand(1, 100) <= 80 ? 'Confirmed' : 'Potential',
                'severity' => $kb['sev'],
                'port' => $kb['port'],
                'protocol' => $kb['proto'],
                'ssl' => $kb['port'] === 443 ? 1 : 0,
                'results' => $this->fakeResults($qid, $kb),
                'status' => $status,
                'first' => $first,
                'last' => $lastFound,
                'last_fixed' => $lastFixed,
                'times_found' => mt_rand(1, 60),
                'times_reopened' => $status === 'Re-Opened' ? mt_rand(1, 3) : 0,
                'qds' => $qds,
                'qds_severity' => $qds >= 90 ? 'CRITICAL' : ($qds >= 70 ? 'HIGH' : ($qds >= 40 ? 'MEDIUM' : 'LOW')),
                'cvss' => $kb['cvss3'],
            ];
        }

        return $detections;
    }

    protected function fakeResults(int $qid, array $kb): string
    {
        if ($kb['category'] === 'Ubuntu' || $kb['category'] === 'Local') {
            return "Package\tInstalled Version\tRequired Version\nlibexample\t1.2.3-1ubuntu1\t1.2.3-1ubuntu1.4";
        }
        if ($qid === 38167) {
            return "Certificate #0 CN=app.lab.local expired on " . Carbon::now()->subDays(mt_rand(5, 90))->format('M d Y') . ' GMT';
        }
        if ($kb['category'] === 'Windows') {
            return 'KB5044284 is not installed%windir%\\System32\\ntoskrnl.exe Version is 10.0.20348.2700';
        }

        return 'Vulnerable service detected: ' . $kb['title'];
    }

    protected function detectionXml(array $query, string $requestUrl): string
    {
        $idMin = (int) ($query['id_min'] ?? 1);
        $limit = max(1, (int) ($query['truncation_limit'] ?? 1000));
        $severities = $this->parseSeverities((string) ($query['severities'] ?? '1-5'));
        $statuses = isset($query['status']) ? explode(',', (string) $query['status']) : ['New', 'Active', 'Re-Opened'];

        $remaining = array_values(array_filter($this->hosts, function ($host) use ($idMin) {
            return $host['id'] >= $idMin;
        }));
        $page = array_slice($remaining, 0, $limit);
        $next = $remaining[$limit] ?? null;

        $xml = '<?xml version="1.0" encoding="UTF-8" ?>' . "\n<HOST_LIST_VM_DETECTION_OUTPUT><RESPONSE>";
        $xml .= '<DATETIME>' . Carbon::now()->toIso8601ZuluString() . '</DATETIME><HOST_LIST>';

        foreach ($page as $host) {
            $detections = array_filter($host['detections'], function ($d) use ($severities, $statuses) {
                return in_array($d['severity'], $severities, true) && in_array($d['status'], $statuses, true);
            });
            if ($detections === []) {
                continue;
            }

            $xml .= '<HOST><ID>' . $host['id'] . '</ID><ASSET_ID>' . $host['asset_id'] . '</ASSET_ID>'
                . '<IP>' . $host['ip'] . '</IP><TRACKING_METHOD>IP</TRACKING_METHOD>'
                . '<OS>' . $this->cdata($host['os']) . '</OS><DNS>' . $this->cdata($host['fqdn']) . '</DNS>'
                . '<DNS_DATA><HOSTNAME>' . $this->cdata($host['hostname']) . '</HOSTNAME><DOMAIN>' . $this->cdata('lab.local') . '</DOMAIN>'
                . '<FQDN>' . $this->cdata($host['fqdn']) . '</FQDN></DNS_DATA>'
                . '<NETBIOS>' . $this->cdata($host['netbios']) . '</NETBIOS>'
                . '<LAST_SCAN_DATETIME>' . Carbon::now()->subDays(1)->toIso8601ZuluString() . '</LAST_SCAN_DATETIME><TAGS>';
            foreach ($host['tags'] as $tag) {
                $xml .= '<TAG><NAME>' . $this->cdata($tag) . '</NAME></TAG>';
            }
            $xml .= '</TAGS><DETECTION_LIST>';

            foreach ($detections as $d) {
                $xml .= '<DETECTION>'
                    . '<UNIQUE_VULN_ID>' . $d['unique_vuln_id'] . '</UNIQUE_VULN_ID>'
                    . '<QID>' . $d['qid'] . '</QID><TYPE>' . $d['type'] . '</TYPE><SEVERITY>' . $d['severity'] . '</SEVERITY>'
                    . ($d['port'] ? '<PORT>' . $d['port'] . '</PORT><PROTOCOL>' . $d['protocol'] . '</PROTOCOL>' : '')
                    . '<SSL>' . $d['ssl'] . '</SSL>'
                    . '<RESULTS>' . $this->cdata($d['results']) . '</RESULTS>'
                    . '<STATUS>' . $d['status'] . '</STATUS>'
                    . '<FIRST_FOUND_DATETIME>' . $d['first']->toIso8601ZuluString() . '</FIRST_FOUND_DATETIME>'
                    . '<LAST_FOUND_DATETIME>' . $d['last']->toIso8601ZuluString() . '</LAST_FOUND_DATETIME>'
                    . '<QDS severity="' . $d['qds_severity'] . '">' . $d['qds'] . '</QDS>'
                    . '<QDS_FACTORS><QDS_FACTOR name="CVSS">' . $d['cvss'] . '</QDS_FACTOR>'
                    . '<QDS_FACTOR name="CVSS_version">v3</QDS_FACTOR>'
                    . '<QDS_FACTOR name="RTI">' . ($d['severity'] === 5 ? 'Active_Attacks,Public_Exploit' : 'Easy_Exploit') . '</QDS_FACTOR></QDS_FACTORS>'
                    . '<TIMES_FOUND>' . $d['times_found'] . '</TIMES_FOUND>'
                    . '<LAST_TEST_DATETIME>' . $d['last']->toIso8601ZuluString() . '</LAST_TEST_DATETIME>'
                    . '<LAST_UPDATE_DATETIME>' . $d['last']->toIso8601ZuluString() . '</LAST_UPDATE_DATETIME>'
                    . ($d['last_fixed'] ? '<LAST_FIXED_DATETIME>' . $d['last_fixed']->toIso8601ZuluString() . '</LAST_FIXED_DATETIME>' : '')
                    . ($d['times_reopened'] ? '<TIMES_REOPENED>' . $d['times_reopened'] . '</TIMES_REOPENED>'
                        . '<LAST_REOPENED_DATETIME>' . $d['last']->toIso8601ZuluString() . '</LAST_REOPENED_DATETIME>' : '')
                    . '<IS_IGNORED>0</IS_IGNORED><IS_DISABLED>0</IS_DISABLED>'
                    . '<LAST_PROCESSED_DATETIME>' . $d['last']->toIso8601ZuluString() . '</LAST_PROCESSED_DATETIME>'
                    . '</DETECTION>';
            }
            $xml .= '</DETECTION_LIST></HOST>';
        }

        $xml .= '</HOST_LIST>';
        if ($next !== null) {
            $base = strtok($requestUrl, '?');
            $nextQuery = http_build_query(array_merge($query, ['id_min' => $next['id']]));
            $xml .= '<WARNING><CODE>1980</CODE><TEXT>' . $limit . ' record limit exceeded. Use URL to get next batch of results.</TEXT>'
                . '<URL>' . $this->cdata($base . '?' . $nextQuery) . '</URL></WARNING>';
        }

        return $xml . '</RESPONSE></HOST_LIST_VM_DETECTION_OUTPUT>';
    }

    /**
     * Host list with details=None: IDs only, compressed into ID / ID_RANGE like Qualys does.
     */
    protected function hostIdListXml(): string
    {
        $ids = array_column($this->hosts, 'id');
        sort($ids);

        $nodes = '';
        $count = count($ids);
        for ($i = 0; $i < $count; $i++) {
            $start = $ids[$i];
            while ($i + 1 < $count && $ids[$i + 1] === $ids[$i] + 1) {
                $i++;
            }
            $nodes .= $start === $ids[$i] ? '<ID>' . $start . '</ID>' : '<ID_RANGE>' . $start . '-' . $ids[$i] . '</ID_RANGE>';
        }

        return '<?xml version="1.0" encoding="UTF-8"?><HOST_LIST_OUTPUT><RESPONSE><DATETIME>'
            . Carbon::now()->toIso8601ZuluString() . '</DATETIME><ID_SET>' . $nodes . '</ID_SET></RESPONSE></HOST_LIST_OUTPUT>';
    }

    protected function knowledgeBaseXml(array $query): string
    {
        $ids = array_filter(array_map('intval', explode(',', (string) ($query['ids'] ?? ''))));
        $xml = '<?xml version="1.0" encoding="UTF-8" ?>' . "\n<KNOWLEDGE_BASE_VULN_LIST_OUTPUT><RESPONSE>";
        $xml .= '<DATETIME>' . Carbon::now()->toIso8601ZuluString() . '</DATETIME><VULN_LIST>';

        foreach ($ids as $qid) {
            if (!isset($this->catalog[$qid])) {
                continue;
            }
            $kb = $this->catalog[$qid];
            $xml .= '<VULN><QID>' . $qid . '</QID><VULN_TYPE>Vulnerability</VULN_TYPE>'
                . '<SEVERITY_LEVEL>' . $kb['sev'] . '</SEVERITY_LEVEL>'
                . '<TITLE>' . $this->cdata($kb['title']) . '</TITLE>'
                . '<CATEGORY>' . $this->cdata($kb['category']) . '</CATEGORY>'
                . '<LAST_SERVICE_MODIFICATION_DATETIME>' . Carbon::now()->subDays(20)->toIso8601ZuluString() . '</LAST_SERVICE_MODIFICATION_DATETIME>'
                . '<PUBLISHED_DATETIME>' . Carbon::now()->subDays(200 + $qid % 300)->toIso8601ZuluString() . '</PUBLISHED_DATETIME>'
                . '<PATCHABLE>' . ($kb['patch'] ? 1 : 0) . '</PATCHABLE>'
                . '<DIAGNOSIS>' . $this->cdata('<p>' . $kb['title'] . ' was detected on the target host.</p><p>An attacker could exploit this weakness remotely without authentication.</p>') . '</DIAGNOSIS>'
                . '<CONSEQUENCE>' . $this->cdata('<p>Successful exploitation could allow an attacker to compromise the confidentiality, integrity and availability of the affected system.</p>') . '</CONSEQUENCE>'
                . '<SOLUTION>' . $this->cdata($kb['patch']
                    ? '<p>The vendor has released a patch. Apply the latest security updates.</p><ul><li>Download the update from the vendor advisory.</li><li>Restart the affected service.</li></ul>'
                    : '<p>Reconfigure the affected service to remove the weakness and follow vendor hardening guidance.</p>') . '</SOLUTION>';
            if ($kb['cves'] !== []) {
                $xml .= '<CVE_LIST>';
                foreach ($kb['cves'] as $cve) {
                    $xml .= '<CVE><ID>' . $this->cdata($cve) . '</ID><URL>' . $this->cdata('https://nvd.nist.gov/vuln/detail/' . $cve) . '</URL></CVE>';
                }
                $xml .= '</CVE_LIST>';
            }
            $xml .= '<CVSS><BASE source="service">' . number_format(max(0, (float) $kb['cvss3'] - 0.6), 1) . '</BASE></CVSS>'
                . '<CVSS_V3><BASE>' . $kb['cvss3'] . '</BASE></CVSS_V3></VULN>';
        }

        return $xml . '</VULN_LIST></RESPONSE></KNOWLEDGE_BASE_VULN_LIST_OUTPUT>';
    }

    /**
     * @return array<int, int>
     */
    protected function parseSeverities(string $value): array
    {
        if (preg_match('/^(\d)-(\d)$/', $value, $m)) {
            return range((int) $m[1], (int) $m[2]);
        }

        return array_map('intval', explode(',', $value));
    }

    protected function cdata(string $value): string
    {
        return '<![CDATA[' . str_replace(']]>', ']]]]><![CDATA[>', $value) . ']]>';
    }
}
