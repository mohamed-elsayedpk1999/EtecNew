<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddQualysFieldsToVulnerabilitiesTable extends Migration
{
    public function up()
    {
        $this->addColumn('qualys_qid', function (Blueprint $table) {
            $table->unsignedBigInteger('qualys_qid')->nullable()->index();
        });
        $this->addColumn('qualys_severity', function (Blueprint $table) {
            $table->unsignedTinyInteger('qualys_severity')->nullable()->index();
        });
        $this->addColumn('qualys_status', function (Blueprint $table) {
            $table->string('qualys_status', 20)->nullable()->index();
        });
        $this->addColumn('qualys_type', function (Blueprint $table) {
            $table->string('qualys_type', 40)->nullable()->index();
        });
        $this->addColumn('qualys_title', function (Blueprint $table) {
            $table->string('qualys_title', 500)->nullable();
        });
        $this->addColumn('qualys_category', function (Blueprint $table) {
            $table->string('qualys_category', 255)->nullable()->index();
        });
        $this->addColumn('qds', function (Blueprint $table) {
            $table->unsignedSmallInteger('qds')->nullable()->index();
        });
        $this->addColumn('qds_severity', function (Blueprint $table) {
            $table->string('qds_severity', 20)->nullable();
        });
        $this->addColumn('times_found', function (Blueprint $table) {
            $table->unsignedInteger('times_found')->nullable();
        });
        $this->addColumn('last_fixed', function (Blueprint $table) {
            $table->timestamp('last_fixed')->nullable();
        });
        $this->addColumn('last_tested', function (Blueprint $table) {
            $table->timestamp('last_tested')->nullable();
        });
        $this->addColumn('last_reopened', function (Blueprint $table) {
            $table->timestamp('last_reopened')->nullable();
        });
        $this->addColumn('times_reopened', function (Blueprint $table) {
            $table->unsignedInteger('times_reopened')->nullable();
        });
        $this->addColumn('qualys_patchable', function (Blueprint $table) {
            $table->boolean('qualys_patchable')->nullable()->index();
        });
        $this->addColumn('qualys_host_id', function (Blueprint $table) {
            $table->string('qualys_host_id', 40)->nullable()->index();
        });
        $this->addColumn('qualys_os', function (Blueprint $table) {
            $table->string('qualys_os', 255)->nullable();
        });

        if (Schema::hasTable('qualys_knowledge_base')) {
            return;
        }

        Schema::create('qualys_knowledge_base', function (Blueprint $table) {
            $table->unsignedBigInteger('qid')->primary();
            $table->string('title', 500)->nullable();
            $table->string('vuln_type', 60)->nullable();
            $table->unsignedTinyInteger('severity_level')->nullable();
            $table->string('category', 255)->nullable();
            $table->longText('diagnosis')->nullable();
            $table->longText('consequence')->nullable();
            $table->longText('solution')->nullable();
            $table->text('cve_list')->nullable();
            $table->string('cvss_base', 20)->nullable();
            $table->string('cvss3_base', 20)->nullable();
            $table->boolean('patchable')->nullable();
            $table->timestamp('published_at')->nullable();
            $table->timestamp('modified_at')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('qualys_knowledge_base');

        $columns = [
            'qualys_qid',
            'qualys_severity',
            'qualys_status',
            'qualys_type',
            'qualys_title',
            'qualys_category',
            'qds',
            'qds_severity',
            'times_found',
            'last_fixed',
            'last_tested',
            'last_reopened',
            'times_reopened',
            'qualys_patchable',
            'qualys_host_id',
            'qualys_os',
        ];

        $existing = array_values(array_filter($columns, function ($column) {
            return Schema::hasColumn('vulnerabilities', $column);
        }));

        if ($existing) {
            Schema::table('vulnerabilities', function (Blueprint $table) use ($existing) {
                $table->dropColumn($existing);
            });
        }
    }

    private function addColumn(string $column, callable $define): void
    {
        if (Schema::hasColumn('vulnerabilities', $column)) {
            return;
        }

        Schema::table('vulnerabilities', function (Blueprint $table) use ($define) {
            $define($table);
        });
    }
}
