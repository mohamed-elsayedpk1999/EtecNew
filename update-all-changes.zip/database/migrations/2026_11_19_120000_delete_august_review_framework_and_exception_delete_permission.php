<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class DeleteAugustReviewFrameworkAndExceptionDeletePermission extends Migration
{
    /**
     * Delete the "مراجعه دورية لشهر اغسطس" framework and its related rows,
     * and add the exception.delete permission for the Administrator role.
     *
     * @return void
     */
    public function up()
    {
        $this->deleteAugustReviewFramework();
        $this->addExceptionDeletePermission();
    }

    /**
     * @return void
     */
    public function down()
    {
        $permission = DB::table('permissions')->where('key', 'exception.delete')->first();
        if (!$permission) {
            return;
        }

        DB::table('role_responsibilities')->where('permission_id', $permission->id)->delete();
        DB::table('permissions')->where('id', $permission->id)->delete();
    }

    private function deleteAugustReviewFramework(): void
    {
        if (!Schema::hasTable('frameworks')) {
            return;
        }

        $target = $this->normalizeArabic('مراجعه دورية لشهر اغسطس');
        $frameworks = DB::table('frameworks')->get(['id', 'name']);

        foreach ($frameworks as $framework) {
            if (mb_strpos($this->normalizeArabic($framework->name), $target) === false) {
                continue;
            }

            DB::statement('SET FOREIGN_KEY_CHECKS=0');
            try {
                $this->deleteFrameworkRelations($framework->id);
                DB::table('frameworks')->where('id', $framework->id)->delete();
            } finally {
                DB::statement('SET FOREIGN_KEY_CHECKS=1');
            }
        }
    }

    private function deleteFrameworkRelations($frameworkId): void
    {
        $columns = DB::select(
            "SELECT TABLE_NAME, DATA_TYPE
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME <> 'frameworks'
               AND COLUMN_NAME = 'framework_id'"
        );

        foreach ($columns as $column) {
            $table = $column->TABLE_NAME;
            if (!Schema::hasTable($table)) {
                continue;
            }

            $numeric = in_array($column->DATA_TYPE, ['int', 'bigint', 'smallint', 'mediumint', 'tinyint'], true);
            if ($numeric) {
                DB::table($table)->where('framework_id', $frameworkId)->delete();
                continue;
            }

            $this->stripIdFromListColumn($table, 'framework_id', $frameworkId, true);
        }

        $this->stripIdFromListColumn('documents', 'framework_ids', $frameworkId, false);
        $this->stripIdFromListColumn('control_objectives', 'framework_id', $frameworkId, true);
    }

    private function stripIdFromListColumn(string $table, string $column, $frameworkId, bool $deleteWhenEmpty): void
    {
        if (!Schema::hasTable($table) || !Schema::hasColumn($table, $column) || !Schema::hasColumn($table, 'id')) {
            return;
        }

        $rows = DB::table($table)
            ->whereNotNull($column)
            ->where($column, 'like', '%' . $frameworkId . '%')
            ->get(['id', $column]);

        foreach ($rows as $row) {
            $parts = preg_split('/\s*,\s*/', (string) $row->{$column}, -1, PREG_SPLIT_NO_EMPTY);
            $remaining = array_values(array_filter($parts, function ($part) use ($frameworkId) {
                return (string) $part !== (string) $frameworkId;
            }));

            if (count($remaining) === count($parts)) {
                continue;
            }

            if ($deleteWhenEmpty && count($remaining) === 0) {
                DB::table($table)->where('id', $row->id)->delete();
                continue;
            }

            DB::table($table)->where('id', $row->id)->update([
                $column => count($remaining) ? implode(',', $remaining) : null,
            ]);
        }
    }

    private function addExceptionDeletePermission(): void
    {
        if (!Schema::hasTable('permissions') || !Schema::hasTable('subgroups')) {
            return;
        }

        $permission = DB::table('permissions')->where('key', 'exception.delete')->first();
        if (!$permission) {
            $subgroup = DB::table('subgroups')->where('name', 'Exceptions')->first();
            if (!$subgroup) {
                return;
            }

            $permissionId = DB::table('permissions')->insertGetId([
                'key' => 'exception.delete',
                'name' => 'delete',
                'subgroup_id' => $subgroup->id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        } else {
            $permissionId = $permission->id;
        }

        if (!Schema::hasTable('roles') || !Schema::hasTable('role_responsibilities')) {
            return;
        }

        $roleIds = DB::table('roles')
            ->where('id', 1)
            ->orWhere('name', 'Administrator')
            ->pluck('id');

        foreach ($roleIds as $roleId) {
            $exists = DB::table('role_responsibilities')
                ->where('role_id', $roleId)
                ->where('permission_id', $permissionId)
                ->exists();

            if (!$exists) {
                DB::table('role_responsibilities')->insert([
                    'role_id' => $roleId,
                    'permission_id' => $permissionId,
                ]);
            }
        }
    }

    private function normalizeArabic($value): string
    {
        $value = html_entity_decode(strip_tags((string) $value), ENT_QUOTES, 'UTF-8');
        $value = str_replace(
            ['أ', 'إ', 'آ', 'ى', 'ة', 'ؤ', 'ئ'],
            ['ا', 'ا', 'ا', 'ي', 'ه', 'و', 'ي'],
            $value
        );
        $value = preg_replace('/\s+/u', ' ', $value);

        return trim($value);
    }
}
