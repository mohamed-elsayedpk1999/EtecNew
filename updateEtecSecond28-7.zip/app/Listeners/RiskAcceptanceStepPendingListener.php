<?php

namespace App\Listeners;

use App\Events\RiskAcceptanceStepPending;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;

class RiskAcceptanceStepPendingListener
{
    use NotificationHandlingTrait;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  \App\Events\RiskAcceptanceStepPending  $event
     * @return void
     */
    public function handle(RiskAcceptanceStepPending $event)
    {
        // Get the action ID for Risk_Acceptance_Approval
        $action1 = Action::where('name', 'Risk_Acceptance_Approval')->first();
        if (!$action1) {
            return;
        }
        $actionId1 = $action1['id'];

        // Get the approval/step/risk objects from the event
        $approval = $event->approval->loadMissing('risk.owner');
        $step = $event->step->loadMissing('assignedUser');
        $risk = $approval->risk;

        if (!$risk || !$step->assigned_user_id) {
            return;
        }

        // Define the roles array for notification
        $roles = [
            'Acceptance_Approver' => [$step->assigned_user_id],
            'creator' => [$risk->owner_id ?? null],
        ];

        // Define the link for redirection after clicking the system notification
        $link = ['link' => route('admin.risk_management.show', ['id' => $risk->id])];

        // Set the properties on the model for notification message variables
        // each variable MUST be assigned to model like this to show it in the message properly
        $risk->Risk_Name = $risk->subject ?? '';
        $risk->Risk_ID = ($risk->id + 1000);
        $risk->Acceptance_Step = $step->label;
        $risk->Acceptance_Approver = optional($step->assignedUser)->name;
        $risk->Owner = optional($risk->owner)->name;
        $risk->subject = $risk->subject ?? '';

        // Call the function to handle different kinds of notifications
        $actionId2 = null;
        $nextDateNotify = null;
        $modelId = null;
        $modelType = null;
        $proccess = null;
        // handling different kinds of notifications using "sendNotificationForAction" function from "NotificationHandlingTrait"
        $this->sendNotificationForAction($actionId1, $actionId2 = null, $link, $risk, $roles, $nextDateNotify = null, $modelId = null, $modelType = null, $proccess = null);
    }
}
