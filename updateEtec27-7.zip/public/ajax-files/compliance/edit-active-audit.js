/**
 * Active audit - Test Result load + submit (AJAX)
 * Loaded after jquery6.js so handlers are not wiped.
 */
(function ($) {
    if (!$ || !$.fn) {
        console.error('edit-active-audit.js: jQuery is not available');
        return;
    }

    function showAuditAlert(status, message, title) {
        title = title || (status === 'success' ? 'Success' : 'Error');
        if (typeof window.makeAlert === 'function') {
            window.makeAlert(status, message, title);
        } else if (typeof window.toastr !== 'undefined') {
            toastr[status](message, title, { closeButton: true, tapToDismiss: false });
        } else {
            alert(message);
        }
    }

    function getCsrfToken() {
        return $('meta[name="csrf-token"]').attr('content') ||
            $('#form-audit-update input[name="_token"]').val() ||
            '';
    }

    function populateTestResults(response, selectedTestResult) {
        var $select = $('#test_result');
        if (!$select.length) {
            return;
        }

        var placeholder = (typeof lang !== 'undefined' && lang.selectOption) ? lang.selectOption : 'Select option';
        $select.empty();
        $select.append('<option value="" disabled ' + (!selectedTestResult ? 'selected' : '') + '>' + placeholder + '</option>');

        $.each(response || [], function (index, testResult) {
            var selectedAttr = String(testResult.id) === String(selectedTestResult) ? ' selected' : '';
            $select.append(
                '<option value="' + testResult.id + '"' + selectedAttr + '>' + testResult.name + '</option>'
            );
        });

        $('.error-test_result').text('');
    }

    function fetchTestResults() {
        var selectedTestResult = $('#selectedTestResult').data('selected');
        var frameworkControlTestAuditId = $('#frameworkControlTestAuditId').val();
        if (!frameworkControlTestAuditId) {
            return;
        }

        $.ajax({
            url: $('#test_result').data('fetch-url') || window.fetchTestResultsUrl,
            method: 'POST',
            data: {
                framework_control_test_audit_id: frameworkControlTestAuditId,
                _token: getCsrfToken()
            },
            success: function (response) {
                populateTestResults(response, selectedTestResult);
            },
            error: function () {
                $('.error-test_result').text('Failed to load test results.');
            }
        });
    }

    function submitAuditResult() {
        var $form = $('#form-audit-update');
        if (!$form.length) {
            return;
        }

        var testResult = $form.find('#test_result').val();
        if (!testResult) {
            var selectMsg = (typeof lang !== 'undefined' && lang.selectOption) ? lang.selectOption : 'Please select a test result';
            var errorTitle = (typeof lang !== 'undefined' && lang.error) ? lang.error : 'Error';
            showAuditAlert('error', selectMsg, errorTitle);
            $('.error-test_result').text(selectMsg);
            return;
        }

        var $btn = $('#submit-audit-result-btn');
        $btn.prop('disabled', true);

        $.ajax({
            url: $form.attr('action'),
            type: 'POST',
            data: $form.serialize(),
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            },
            success: function (data) {
                $btn.prop('disabled', false);
                $('.error-test_result').text('');

                if (data && (data.status === true || data.status === 1)) {
                    var successTitle = (typeof lang !== 'undefined' && lang.success) ? lang.success : 'Success';
                    showAuditAlert('success', data.message || 'Updated successfully', successTitle);

                    // Keep selected value in sync without page reload
                    if (data.test_result) {
                        $('#selectedTestResult').attr('data-selected', data.test_result).data('selected', data.test_result);
                        $('#test_result').val(String(data.test_result));
                    }

                    // Refresh charts / related audit data
                    if (typeof window.fetchAuditData === 'function') {
                        window.fetchAuditData();
                    }

                    // Refresh test result options list
                    fetchTestResults();
                } else {
                    if (data && data.errors && typeof showError === 'function') {
                        showError(data.errors, 'form-audit-update');
                    }
                    var failTitle = (typeof lang !== 'undefined' && lang.error) ? lang.error : 'Error';
                    showAuditAlert('error', (data && data.message) ? data.message : 'Error', failTitle);
                }
            },
            error: function (xhr) {
                $btn.prop('disabled', false);
                var responseData = xhr.responseJSON || {};
                var errTitle = (typeof lang !== 'undefined' && lang.error) ? lang.error : 'Error';
                showAuditAlert('error', responseData.message || 'Error', errTitle);
            }
        });
    }

    $(function () {
        // Load options on focus / first open
        $(document).off('focus.auditResult click.auditResult', '#test_result')
            .on('focus.auditResult click.auditResult', '#test_result', function () {
                if ($('#test_result option').length <= 1) {
                    fetchTestResults();
                }
            });

        // Prefetch once so options are ready
        if ($('#form-audit-update').length) {
            fetchTestResults();
        }

        // Submit via button click
        $(document).off('click.auditResultSubmit', '#submit-audit-result-btn')
            .on('click.auditResultSubmit', '#submit-audit-result-btn', function (e) {
                e.preventDefault();
                e.stopPropagation();
                submitAuditResult();
            });

        // Enter key in form
        $(document).off('submit.auditResult', '#form-audit-update')
            .on('submit.auditResult', '#form-audit-update', function (e) {
                e.preventDefault();
                e.stopPropagation();
                submitAuditResult();
                return false;
            });
    });

    // Optional Quill init
    if (document.querySelector('#risk_addational_notes_submit') && typeof Quill !== 'undefined') {
        new Quill('#risk_addational_notes_submit', {
            theme: 'snow',
            modules: {
                toolbar: [
                    [{ header: [1, 2, 3, 4, 5, 6, false] }],
                    ['bold', 'italic', 'underline', 'strike'],
                    [{ list: 'ordered' }, { list: 'bullet' }],
                    [{ indent: '-1' }, { indent: '+1' }],
                    [{ direction: 'rtl' }],
                    ['clean']
                ]
            }
        });
    }
})(window.jQuery);
