<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('risk_acceptance_flow_configs', function (Blueprint $table) {
            $table->id();
            $table->unsignedTinyInteger('step_order')->unique();
            $table->string('step_key', 50)->unique();
            $table->string('label_en');
            $table->string('label_ar');
            $table->unsignedBigInteger('user_id')->nullable();
            $table->boolean('use_risk_owner')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->foreign('user_id', 'ra_flow_cfg_user_fk')
                ->references('id')->on('users')->nullOnDelete();
        });

        Schema::create('risk_acceptance_approvals', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('risk_id');
            $table->unsignedBigInteger('mitigation_id')->nullable();
            $table->string('status', 30)->default('pending'); // pending|approved|rejected|cancelled
            $table->unsignedTinyInteger('current_step')->default(1);
            $table->unsignedBigInteger('started_by')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['risk_id', 'status'], 'ra_appr_risk_status_idx');
            $table->foreign('risk_id', 'ra_appr_risk_fk')
                ->references('id')->on('risks')->cascadeOnDelete();
            $table->foreign('mitigation_id', 'ra_appr_mitigation_fk')
                ->references('id')->on('mitigations')->nullOnDelete();
            $table->foreign('started_by', 'ra_appr_started_by_fk')
                ->references('id')->on('users')->nullOnDelete();
        });

        Schema::create('risk_acceptance_approval_steps', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('risk_acceptance_approval_id');
            $table->unsignedTinyInteger('step_order');
            $table->string('step_key', 50);
            $table->string('label_en')->nullable();
            $table->string('label_ar')->nullable();
            $table->unsignedBigInteger('assigned_user_id')->nullable();
            $table->string('status', 30)->default('waiting'); // waiting|pending|approved|rejected|skipped
            $table->unsignedBigInteger('acted_by')->nullable();
            $table->timestamp('acted_at')->nullable();
            $table->text('comments')->nullable();
            $table->timestamps();

            $table->unique(['risk_acceptance_approval_id', 'step_order'], 'ra_step_unique');
            $table->foreign('risk_acceptance_approval_id', 'ra_step_approval_fk')
                ->references('id')->on('risk_acceptance_approvals')->cascadeOnDelete();
            $table->foreign('assigned_user_id', 'ra_step_assigned_fk')
                ->references('id')->on('users')->nullOnDelete();
            $table->foreign('acted_by', 'ra_step_acted_by_fk')
                ->references('id')->on('users')->nullOnDelete();
        });

        // Seed default 3-step cycle
        DB::table('risk_acceptance_flow_configs')->insert([
            [
                'step_order' => 1,
                'step_key' => 'grc_manager',
                'label_en' => 'Governance, Risk & Compliance Manager',
                'label_ar' => 'مدير إدارة الحوكمة والمخاطر والالتزام',
                'user_id' => null,
                'use_risk_owner' => false,
                'is_active' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'step_order' => 2,
                'step_key' => 'risk_owner',
                'label_en' => 'Risk Owner',
                'label_ar' => 'مالك الخطر',
                'user_id' => null,
                'use_risk_owner' => true,
                'is_active' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'step_order' => 3,
                'step_key' => 'cybersecurity_gm',
                'label_en' => 'Cybersecurity General Manager',
                'label_ar' => 'المدير العام للأمن السيبراني',
                'user_id' => null,
                'use_risk_owner' => false,
                'is_active' => true,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);

        // Notification action
        if (!DB::table('actions')->where('id', 162)->exists()) {
            DB::table('actions')->insert([
                'id' => 162,
                'name' => 'Risk_Acceptance_Approval',
            ]);
        }
    }

    public function down()
    {
        Schema::dropIfExists('risk_acceptance_approval_steps');
        Schema::dropIfExists('risk_acceptance_approvals');
        Schema::dropIfExists('risk_acceptance_flow_configs');
        DB::table('actions')->where('id', 162)->delete();
    }
};
