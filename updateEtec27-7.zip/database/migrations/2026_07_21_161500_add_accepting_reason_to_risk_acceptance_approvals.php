<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('risk_acceptance_approvals', function (Blueprint $table) {
            $table->text('accepting_reason')->nullable()->after('status');
        });
    }

    public function down()
    {
        Schema::table('risk_acceptance_approvals', function (Blueprint $table) {
            $table->dropColumn('accepting_reason');
        });
    }
};
