<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        // Child table first (FK to objective_comments)
        if (Schema::hasTable('objective_comment_readers')) {
            DB::table('objective_comment_readers')->truncate();
        }

        if (Schema::hasTable('objective_comments')) {
            DB::table('objective_comments')->truncate();
        }

        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        // Data truncation cannot be reversed
    }
};
