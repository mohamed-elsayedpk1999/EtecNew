<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::table('risk_acceptance_flow_configs', function (Blueprint $table) {
            $table->unsignedBigInteger('department_id')->nullable()->after('step_key');
            $table->foreign('department_id', 'ra_flow_cfg_dept_fk')
                ->references('id')->on('departments')->nullOnDelete();
        });

        Schema::table('risk_acceptance_approval_steps', function (Blueprint $table) {
            $table->unsignedBigInteger('department_id')->nullable()->after('step_key');
            $table->foreign('department_id', 'ra_step_dept_fk')
                ->references('id')->on('departments')->nullOnDelete();
        });

        // Best-effort map existing configs to departments by Arabic name keywords
        $map = [
            'grc_manager' => ['الحوكمة', 'المخاطر', 'الالتزام'],
            'cybersecurity_gm' => ['أمن المعلومات', 'الامن السيبراني', 'الأمن السيبراني'],
        ];

        $departments = DB::table('departments')->select('id', 'name')->get();
        $configs = DB::table('risk_acceptance_flow_configs')->get();

        foreach ($configs as $config) {
            $deptId = null;
            $keywords = $map[$config->step_key] ?? [];
            foreach ($departments as $dept) {
                foreach ($keywords as $keyword) {
                    if (mb_stripos($dept->name, $keyword) !== false) {
                        $deptId = $dept->id;
                        break 2;
                    }
                }
            }

            if ($deptId) {
                $deptName = optional($departments->firstWhere('id', $deptId))->name;
                DB::table('risk_acceptance_flow_configs')->where('id', $config->id)->update([
                    'department_id' => $deptId,
                    'label_en' => $deptName,
                    'label_ar' => $deptName,
                ]);
            }
        }
    }

    public function down()
    {
        Schema::table('risk_acceptance_approval_steps', function (Blueprint $table) {
            $table->dropForeign('ra_step_dept_fk');
            $table->dropColumn('department_id');
        });

        Schema::table('risk_acceptance_flow_configs', function (Blueprint $table) {
            $table->dropForeign('ra_flow_cfg_dept_fk');
            $table->dropColumn('department_id');
        });
    }
};
