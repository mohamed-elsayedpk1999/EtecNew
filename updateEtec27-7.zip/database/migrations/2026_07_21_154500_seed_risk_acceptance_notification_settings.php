<?php

use App\Models\Action;
use App\Models\MailSetting;
use App\Models\NotificationRole;
use App\Models\SystemNotificationSetting;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up()
    {
        $action = Action::firstOrCreate(
            ['id' => 162],
            ['name' => 'Risk_Acceptance_Approval']
        );

        $system = SystemNotificationSetting::firstOrCreate(
            ['action_id' => $action->id],
            [
                'message' => '<p>Your approval is required for risk "{Risk_Name}" (#{Risk_ID}) at step: {Acceptance_Step}</p>',
                'status' => 1,
            ]
        );
        $system->update(['status' => 1]);
        if (!$system->roles()->where('role', 'Acceptance_Approver')->exists()) {
            $system->roles()->save(new NotificationRole(['role' => 'Acceptance_Approver']));
        }

        $mail = MailSetting::firstOrCreate(
            ['action_id' => $action->id],
            [
                'subject' => 'Risk acceptance approval required #{Risk_ID}',
                'body' => '<p>Your approval is required for risk "{Risk_Name}" (#{Risk_ID}) at step: {Acceptance_Step}</p><p>Approver: {Acceptance_Approver}</p>',
                'status' => 1,
            ]
        );
        $mail->update(['status' => 1]);
        if (!$mail->roles()->where('role', 'Acceptance_Approver')->exists()) {
            $mail->roles()->save(new NotificationRole(['role' => 'Acceptance_Approver']));
        }
    }

    public function down()
    {
        // keep notification settings
    }
};
