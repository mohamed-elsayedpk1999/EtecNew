<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('mgmt_reviews', function (Blueprint $table) {
            if (!Schema::hasColumn('mgmt_reviews', 'rejection_justification')) {
                $table->text('rejection_justification')->nullable()->after('comments');
            }
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('mgmt_reviews', function (Blueprint $table) {
            if (Schema::hasColumn('mgmt_reviews', 'rejection_justification')) {
                $table->dropColumn('rejection_justification');
            }
        });
    }
};
