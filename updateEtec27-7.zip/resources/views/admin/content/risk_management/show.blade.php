@extends('admin/layouts/contentLayoutMaster')

@section('title', __('risk.ViewRisk'))
@section('vendor-style')
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/pickadate/pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-pickadate.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/forms/pickers/form-flat-pickr.css')) }}">
    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"> --}}
    <style>
        @media (max-width: 576px) {
            .text-sm-only-center {
                text-align: center
            }



        }

        .basic-wizard .stepper-horizontal {
            overflow: hidden !important;
        }

        .text-label {
            font-size: 1.1rem;
            font-weight: 900;
        }

        #edit-mitigation-form span.error {
            display: block;
            margin-top: 0.25rem;
            font-size: 0.857rem;
            color: #ea5455;
        }

        #edit-mitigation-form textarea.is-invalid,
        #edit-mitigation-form input.is-invalid,
        #edit-mitigation-form select.is-invalid {
            border-color: #ea5455 !important;
        }

        .cursor-pointer {
            cursor: pointer;
        }

        #impact-detail-btn svg,
        #likelihood-detail-btn svg,
        .delete_supporting_documentation svg {
            width: 25px;
            height: 25px;
        }

        .highcharts-credits {
            display: none;
        }

        #editRiskModal .modal-row>div {
            position: initial !important;
        }

        <style>.nav-pills {
            display: flex;
            justify-content: space-between;
            width: 100%;
        }

        .main-color {
            color: #44225c;

        }

        .nav-pills .nav-item {
            flex: 1;
            text-align: center;
            background-color: #f2f2f2;
            border-inline: 1px solid white;
        }

        .feather,
        [data-feather] {
            height: 1.5rem;
            width: 1.5rem;
        }

        .nav-pills .nav-link {
            width: 100%;
            border-radius: 0;


        }

        .container-tab {

            margin: 25px 1px 10px;
            border-radius: 10px;
        }


        .dropdown-toggle::after {

            vertical-align: 0px !important;
            margin-inline: 7px
        }

        .custom-span {
            padding: 0px 8px;
            font-size: 9px;
            font-weight: 800;
            position: relative;
            display: inline-flex;
            align-items: center;
        }

        .span-red {
            color: #c96f62;
            border: 1px solid #c96f62;
            background: #fff2ea;
        }

        .span-yellow {
            color: #ebc204;
            border: 1px solid #ebc204;
            background: #fcf9f8;
            margin-left: 0.5rem;
        }

        .custom-span::before {
            content: "•";
            color: currentColor;
            font-size: 14px;
            margin-right: 5px;
            display: inline-block;
        }

        .custom-p {
            color: #44225c;
            font-weight: 900;
            font-size: 18px;
        }

        .card.risk-session {
            padding: 14px;
        }

        .nav-link:hover {
            color: #44225c !important;
        }

        .nav-link.active:hover {
            color: #fff !important;
        }

        .accordion-button {
            background: #44225c !important;
            color: #fff !important;
            border: none;
        }

        .fas.fa-chevron-down {
            right: 0;
            margin-inline: 20px
        }

        .accordion-button:not(.collapsed) {
            background: #44225c !important;
            color: #fff !important;
            box-shadow: none;
        }

        .accordion-button:focus,
        .accordion-button:hover {
            background: #44225c !important;
            color: #fff !important;
            box-shadow: none;
        }

        .nav-pills .nav-link {
            padding: 0.786rem 1.5rem;
            font-size: 1rem;
            line-height: 1rem;
            border: 1px solid transparent;
            color: #5e5873;
            height: 75px;
        }

        .nav-pills .nav-link {

            height: 50px;
        }

        /* Rotate the icon when the accordion is expanded */
        .accordion-button:not(.collapsed) #chevronIcon {
            transform: rotate(180deg);
            transition: transform 0.3s ease;
            /* Smooth transition */
        }

        /* Default state (collapsed) */
        /* Default state: Icon is up (collapsed) */
        #chevronIcon {
            transform: rotate(180deg);
            /* Rotate up by default */
            transition: transform 0.3s ease;
            /* Smooth transition */
        }

        /* Expanded state: Icon is down */
        .accordion-button:not(.collapsed) #chevronIcon {
            transform: rotate(0deg);
            /* Rotate down when expanded */
        }

        /* Ensure the icon is positioned at the end of the button */
        .accordion-button {
            position: relative;
            /* Required for absolute positioning of the icon */
        }

        #chevronIcon {
            position: absolute;
            /* Position the icon at the end */
            right: 1rem;
            /* Adjust spacing from the right */
        }

        .ql-toolbar.ql-snow+.ql-container.ql-snow {
            border-top: 0px;
            height: 150px;
        }

        .btn-green {
            background-color: #03781d !important;
            border-color: #03781d !important;
            color: #fff !important;
        }

        .ql-toolbar.ql-snow {
            width: 600px;
        }

        .ql-toolbar.ql-snow+.ql-container.ql-snow {

            width: 600px;
        }

        .badge-step {
            background-color: #c30c0c;
            color: white;
            border-radius: 50%;
            width: 40px;
            height: 40px;


        }

        .bg-custom {
            background: #f2f2f2;
            padding: 12px;
        }

        .rounded-p {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 50px;
            height: 50px;
            color: #93312b;
            background: #fff2ea;
            font-weight: 800;
            margin: 0 !important;
        }

        .risk-title {
            font-size: 0.85rem;
            line-height: 1.2;
            text-align: center;
            white-space: normal;
            word-break: break-word;
            max-width: 100%;
        }

        @media (max-width: 768px) {
            .nav-pills .nav-link {
                height: 70px;
            }
        }

        /* ── Banner ── */
        .smv-banner {
            display: flex;
            align-items: center;
            gap: .9rem;
            border-radius: 10px;
            border: 1px solid;
            border-left: 4px solid;
            padding: .8rem 1.1rem;
        }

        .smv-banner-icon {
            font-size: 1.4rem;
            line-height: 1;
        }

        .smv-banner-info {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: .1rem;
        }

        .smv-banner-label {
            font-size: .68rem;
            font-weight: 700;
            letter-spacing: .1em;
            text-transform: uppercase;
        }

        .smv-banner-value {
            font-size: .95rem;
            font-weight: 600;
            color: #1e293b;
        }

        .smv-banner-badge {
            font-size: .62rem;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
            padding: .25rem .7rem;
            border-radius: 20px;
            color: #fff;
            white-space: nowrap;
        }

        /* ── Grid ── */
        .smv-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: .65rem;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 1rem;
        }

        /* ── Field Card ── */
        .smv-field {
            display: flex;
            align-items: flex-start;
            gap: .6rem;
            background: #fff;
            border: 1px solid #e8edf4;
            border-radius: 8px;
            padding: .7rem .85rem;
            transition: box-shadow .2s ease, border-color .2s ease;
        }

        .smv-field:hover {
            border-color: #93c5fd;
            box-shadow: 0 2px 10px rgba(59, 130, 246, .1);
        }

        .smv-field--wide {
            grid-column: span 2;
        }

        @media (max-width: 576px) {
            .smv-field--wide {
                grid-column: span 1;
            }
        }

        .smv-field-icon {
            font-size: 1.1rem;
            line-height: 1;
            margin-top: .1rem;
        }

        .smv-field-body {
            display: flex;
            flex-direction: column;
            gap: .2rem;
            flex: 1;
            min-width: 0;
        }

        .smv-field-label {
            font-size: .68rem;
            font-weight: 700;
            letter-spacing: .07em;
            text-transform: uppercase;
            color: #64748b;
        }

        .smv-field-value {
            font-size: .875rem;
            font-weight: 500;
            color: #1e293b;
            word-break: break-word;
        }

        .smv-none {
            font-size: .8rem;
            color: #94a3b8;
            font-style: italic;
        }

        /* Tags */
        .smv-tag {
            display: inline-block;
            font-size: .72rem;
            font-weight: 600;
            padding: .2rem .55rem;
            border-radius: 5px;
            background: #e0e7ff;
            color: #3730a3;
            margin-right: .25rem;
            margin-bottom: .2rem;
        }

        .smv-tag--file {
            background: #f1f5f9;
            color: #475569;
            border: 1px solid #e2e8f0;
        }

        .smv-tag--control {
            background: #dcfce7;
            color: #166534;
        }

        /* Progress */
        .smv-progress-wrap {
            display: flex;
            align-items: center;
            gap: .6rem;
            margin-top: .2rem;
        }

        .smv-progress-bar {
            flex: 1;
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
        }

        .smv-progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #3b82f6, #60a5fa);
            border-radius: 3px;
        }

        .smv-progress-pct {
            font-size: .8rem;
            font-weight: 700;
            color: #3b82f6;
            white-space: nowrap;
            min-width: 32px;
            text-align: right;
        }

        /* ── Text Blocks ── */
        .smv-text-block {
            background: #fff;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: .75rem;
        }

        .smv-text-block:last-child {
            margin-bottom: 0;
        }

        .smv-tb-header {
            display: flex;
            align-items: center;
            gap: .5rem;
            padding: .6rem .9rem;
            background: #f8fafc;
            border-bottom: 1px solid #e2e8f0;
        }

        .smv-tb-label {
            font-size: .68rem;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: #64748b;
        }

        .smv-tb-content {
            padding: .75rem .9rem;
            font-size: .875rem;
            color: #334155;
            max-height: 130px;
            overflow-y: auto;
            line-height: 1.6;
        }

        .smv-tb-content--rich {
            max-height: none;
            min-height: 80px;
        }

        .smv-tb-content::-webkit-scrollbar {
            width: 4px;
        }

        .smv-tb-content::-webkit-scrollbar-track {
            background: #f1f5f9;
        }

        .smv-tb-content::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 2px;
        }
    </style>
@endsection
@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-sm-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- start tab -->
    <div class="container-tab">
        <div class="row">
            <div class="col-12">
                <div class=" risk-session">
                    <!-- start tab -->
                    <div class="card p-4">
                        <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-home" type="button" role="tab"
                                    aria-controls="pills-home"
                                    aria-selected="true">{{ __('locale.RiskIdentification') }}</button>
                            </li>
                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link" id="pills-analysis-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-analysis" type="button" role="tab"
                                    aria-controls="pills-home"
                                    aria-selected="true">{{ __('locale.RiskAnalysis') }}</button>
                            </li>

                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link" id="pills-evalution-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-evalution" type="button" role="tab"
                                    aria-controls="pills-evalution"
                                    aria-selected="false">{{ __('locale.RiskEvaluationAndTreatment') }}</button>
                            </li>
                            <li class="nav-item mb-2 mb-md-0" role="presentation">
                                <button class="nav-link" id="pills-review-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-review" type="button" role="tab"
                                    aria-controls="pills-review"
                                    aria-selected="false">{{ __('locale.RiskReviewingAndMonitoring') }}</button>
                            </li>
                            <li class="nav-item mb-2 mb-md-0" role="presentation">

                                <button class="nav-link" id="pills-comment-trail-tab" data-bs-toggle="pill"
                                    data-bs-target="#pills-comment-trail" type="button" role="tab"
                                    aria-controls="pills-comment-trail" aria-selected="false">
                                    <div class="d-flex justify-content-center align-items-center">
                                        <p class="badge-step d-flex justify-content-center align-items-center mb-0">
                                            {{ count($data['comments']) }}
                                        </p>
                                        <p class="mb-0 ms-2">{{ __('locale.CommentAndTrail') }}</p>
                                    </div>
                                </button>
                            </li>
                        </ul>
                        <div class="row align-items-center">
                            <!-- Left Side: ID, Subject, Status -->
                            <div class="col-12 col-md-7 col-lg-8 d-flex justify-content-start align-items-center">
                                <div class="col-2 col-lg-4">{{ __('locale.ID') }} #: {{ __($data['id']) }}</div>
                                <div class="col-4 col-lg-4">{{ __('locale.Subject') }}: {{ $data['subject'] }}</div>
                                <div class="col-6 col-lg-4">
                                    {{ __('locale.Status') }}:
                                    <span class="custom-span span-red rounded-pill">{{ __($data['status']) }}</span>
                                </div>
                            </div>

                            <!-- Right Side: Edit Subject, Change Status Button, Dropdown -->
                            <div class="col-12 col-md-5 col-lg-4 d-flex justify-content-end align-items-center">
                                <!-- Edit Subject Icon and Form -->
                                @if (auth()->user()->hasPermission('riskmanagement.update'))
                                    {{-- <span id="edit-subject" class="display-9 me-2" style="cursor: pointer">
                                    <i data-feather="edit" style="width: 20px; color: #44225c; height: 20px;"></i>
                                </span> --}}
                                    <form id="edit-subject-form" method="post" action="/" class="px-0 d-none"
                                        id="edit-subject-container">
                                        @csrf
                                        <div class="row align-items-center">
                                            <div class="col-8">
                                                <input type="text" class="form-control"
                                                    value="{{ $data['subject'] }}" name="subject">
                                                <span class="error error-subject"></span>
                                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                            </div>
                                            <div class="col-4">
                                                <button id="cancel-edit-subject" class="btn btn-danger btn-sm"
                                                    type="button">
                                                    {{ __('locale.Cancel') }}
                                                </button>
                                                <button id="submit-edit-subject" class="btn btn-success btn-sm"
                                                    type="button">
                                                    {{ __('locale.Submit') }}
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                @endif

                                <!-- Change Status Button -->
                                <button type="button" class="btn btn-outline-primary me-2" data-bs-toggle="modal"
                                    data-bs-target="#changeRiskStatusModal">
                                    {{ __('locale.ChangeStatus') }}
                                </button>


                                <!-- Actions Dropdown -->
                                <div class="btn-group">
                                    <select class="form-control dt-input dt-select select20" id="risk-actions"
                                        data-column="3" data-column-index="2" data-id="{{ $data['id'] }}">
                                        <option class="step-default-option" selected value="">
                                            {{ __('locale.Actions') }}
                                        </option>
                                        @if ($data['status'] == 'Closed')
                                            <option class="step-1-option" value="ReopenRisk" style="display: none;">
                                                {{ __('risk.ReopenRisk') }}
                                            </option>
                                        @else
                                            @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
                                                <option class="step-1-option" value="CloseRisk"
                                                    style="display: none;">{{ __('risk.CloseRisk') }}</option>
                                            @endif
                                        @endif
                                        @if (auth()->user()->hasPermission('riskmanagement.update'))
                                            <option class="step-1-option" value="EditRisk" style="display: none;">
                                                {{ __('risk.EditRisk') }}
                                            </option>
                                        @endif
                                        @if (auth()->user()->hasPermission('riskmanagement.update'))
                                            <option class="step-2-option" value="EditRisk2" style="display: none;">
                                                {{ __('risk.EditRisk') }}
                                            </option>
                                        @endif

                                        {{-- <option class="step-1-option" value="ChangeStatus" style="display: none;">
                                        {{ __('locale.ChangeStatus') }}</option> --}}
                                        @if (auth()->user()->hasPermission('plan_mitigation.create'))
                                            <option class="step-3-option" value="ResetMitigations"
                                                style="display: none;">{{ __('risk.ResetMitigations') }}</option>
                                        @endif
                                        @if (auth()->user()->hasPermission('perform_reviews.create'))
                                            <option class="step-4-option" value="PerformAReview"
                                                style="display: none;">{{ __('risk.PerformAReview') }}</option>
                                            <option class="step-4-option" value="ResetReviews"
                                                style="display: none;">{{ __('risk.ResetReviews') }}</option>
                                        @endif

                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content" id="pills-tabContent">
                        <!-- step 1 -->
                        <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
                            aria-labelledby="pills-home-tab">



                            <!-- cards -->
                            <div class="col-12">
                                <div class="row g-2">
                                    <div class="col-12 col-md-4">
                                        <div class="card">
                                            <div class="row text-center align-items-center m-0"
                                                style="font-size: 1rem">

                                                {{-- Inherent Risk --}}
                                                <div class="col-4 my-4">
                                                    <div class="text-black py-2 d-flex flex-column justify-content-center align-items-center"
                                                        style="background-color:#fff2ea; min-height:130px">
                                                        <p class="m-0"><i data-feather="alert-triangle"></i></p>

                                                        <p class="m-0 risk-title">
                                                            {{ __('risk.InherentRisk') }}
                                                        </p>

                                                        <p class="m-0" id="inherent_risk_score">
                                                            {{ $data['calculated_risk'] }}
                                                        </p>

                                                        <p class="m-0" style="color:#ea6155">
                                                            {{ $data['calculated_risk_data']['name'] }}
                                                        </p>
                                                    </div>
                                                </div>

                                                {{-- Residual Risk Before Treatment --}}
                                                <div class="col-4 my-4">
                                                    <div class="text-black py-2 d-flex flex-column justify-content-center align-items-center"
                                                        style="background-color:#ecfdf3; min-height:130px">
                                                        <p class="m-0"><i data-feather="check-circle"></i></p>

                                                        <p class="m-0 risk-title">
                                                            {{ __('risk.ResidualRiskAfterTreatment') }}
                                                        </p>

                                                        <p class="m-0" id="residual_risk_before_score">
                                                            {{ $data['residual_risk_befor_treatment']['residual_risk'] }}
                                                        </p>

                                                        <p class="m-0" style="color:#1bb573">
                                                            {{ $data['residual_risk_befor_treatment_data']['name'] }}
                                                        </p>

                                                        <p class="m-0 text-muted" style="font-size:0.8rem">
                                                            {{ __('risk.Effectiveness') }}:
                                                            <strong>
                                                                {{ $data['residual_risk_befor_treatment']['effectiveness_text'] }}
                                                            </strong>
                                                        </p>
                                                    </div>
                                                </div>

                                                {{-- Residual Risk --}}
                                                <div class="col-4 my-4">
                                                    <div class="text-black py-2 d-flex flex-column justify-content-center align-items-center"
                                                        style="background-color:#ecfdf3; min-height:130px">
                                                        <p class="m-0"><i data-feather="check-circle"></i></p>

                                                        <p class="m-0 risk-title">
                                                            {{ __('risk.ResidualRisk') }}
                                                        </p>

                                                        <p class="m-0" id="residual_risk_score">
                                                            {{ $data['residual_risk'] }}
                                                        </p>

                                                        <p class="m-0" style="color:#1bb573">
                                                            {{ $data['residual_risk_data']['name'] }}
                                                        </p>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-12 col-md-8">
                                        <div class="card p-4">
                                            <div class="d-flex justify-content-between">
                                                <p class="custom-p">{{ __('locale.ClassicRiskScoring') }}</p>
                                                <div>
                                                    @if (auth()->user()->hasPermission('riskmanagement.update'))
                                                        <span id="UpdateClassicScoreShowBtn" class="display-9"
                                                            style="cursor: pointer">
                                                            <i data-feather="edit"
                                                                style="width: 20px; color: #44225c; height: 20px;"></i>
                                                        </span>
                                                    @endif
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-start mt-3">
                                                <div class="custom-div me-5">
                                                    {{ __('locale.Impact') }}:
                                                    <span class="custom-span rounded-pill span-yellow">
                                                        [{{ $data['impact']['id'] }}] {{ $data['impact']['name'] }}
                                                    </span>
                                                </div>
                                                <div>
                                                    {{ __('risk.Likelihood') }}: [{{ $data['likelihood']['id'] }}]
                                                    {{ $data['likelihood']['name'] }}
                                                </div>
                                            </div>
                                            <p class="fw-bolder mt-3 mb-0  ">

                                            <p class="fw-bolder mt-3 mb-0">
                                                {{ $riskModel->name }} = {{ $data['calculated_risk'] }}
                                            </p>
                                            </p>
                                        </div>


                                        <!-- Form for Updating Risk Scoring -->
                                        @if (auth()->user()->hasPermission('riskmanagement.update'))
                                            <form class="row px-0" id="edit-risk-scoring-form" method="post"
                                                action="/" style="display: none">
                                                @csrf
                                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                                <div class="row mx-0">
                                                    <div class="col-12 col-md-6 mb-1">
                                                        {{-- Current Likelihood --}}
                                                        <div class="mb-1 row">
                                                            <div class="col-11">
                                                                <label
                                                                    class="form-label">{{ __('risk.CurrentLikelihood') }}</label>
                                                                <select class="select2 form-select d-inline"
                                                                    name="current_likelihood_id">
                                                                    <option value="" disabled hidden selected>
                                                                        {{ __('locale.select-option') }}
                                                                    </option>
                                                                    @foreach ($riskLikelihoods as $riskLikelihood)
                                                                        <option value="{{ $riskLikelihood->id }}"
                                                                            {{ $data['likelihood']['id'] == $riskLikelihood->id ? 'selected' : '' }}>
                                                                            {{ $riskLikelihood->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div id="likelihood-detail-btn"
                                                                class="col-1 cursor-pointer"
                                                                style="margin-top: 2.2rem !important;">
                                                                <i data-feather='info' class="text-danger"></i>
                                                            </div>
                                                            <span class="error error-current_likelihood_id"></span>
                                                        </div>
                                                        {{-- Current Impact --}}
                                                        <div class="mb-1 row">
                                                            <div class="col-11">
                                                                <label
                                                                    class="form-label">{{ __('risk.CurrentImpact') }}</label>
                                                                <select class="select2 form-select"
                                                                    name="current_impact_id">
                                                                    <option value="" disabled hidden selected>
                                                                        {{ __('locale.select-option') }}
                                                                    </option>
                                                                    @foreach ($impacts as $impact)
                                                                        <option value="{{ $impact->id }}"
                                                                            {{ $data['impact']['id'] == $impact->id ? 'selected' : '' }}>
                                                                            {{ $impact->name }}
                                                                        </option>
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                            <div id="impact-detail-btn" class="col-1 cursor-pointer"
                                                                style="margin-top: 2.2rem !important;">
                                                                <i data-feather='info' class="text-danger"></i>
                                                            </div>
                                                            <span class="error error-current_impact_id"></span>
                                                        </div>
                                                        <button id="update-edit-risk-scoring" type="button"
                                                            class="btn btn-success me-1">{{ __('locale.Update') }}</button>
                                                        <button id="cancel-edit-risk-scoring"
                                                            class="button btn btn-danger"
                                                            type="button">{{ __('locale.Cancel') }}</button>
                                                    </div>
                                                    <div class="col-12 col-md-6 mb-1">
                                                        <div id="impact-detail" style="display: none">
                                                            <!-- Impact details here -->
                                                        </div>
                                                        <div id="likelihood-detail" style="display: none">
                                                            <!-- Likelihood details here -->
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <!-- start accordion -->
                            <div class="accordion mb-5" id="accordionExample">

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                            aria-expanded="false" aria-controls="collapseOne"
                                            id="RiskScoreOverTimeBtn">
                                            {{ __('locale.RiskScoringHistory') }}
                                            <i id="chevronIcon"
                                                class="fas fa-chevron-down ms-2 position-absolute end-0"></i>
                                            <!-- Icon for toggle -->
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse"
                                        aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <!-- Placeholder for dynamically loaded content -->
                                            <div id="RiskScoreOverTime">
                                                <!-- Content will be loaded here dynamically -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                            aria-expanded="false" aria-controls="collapseTwo">
                                            {{ __('locale.OtherInformation') }}
                                            <i class="fas fa-chevron-down position-absolute "
                                                style="transform: rotate(180deg); "></i>
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse"
                                        aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <div class="row">
                                                <!-- First Column -->
                                                <div class="col-12 col-md-4">
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('risk.RiskMapping') }}:
                                                        </p>
                                                        <ul style="list-style: disc; padding-left: 20px;">
                                                            @foreach ($data['riskCatalogs'] as $riskCatalogs)
                                                                <span
                                                                    class="badge bg-secondary">{{ $riskCatalogs['name'] }}</span>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('locale.SiteLocation') }}:
                                                        </p>
                                                        <p class="mb-1">
                                                            @foreach ($data['locations'] as $location)
                                                                <span
                                                                    class="badge bg-secondary">{{ $location['name'] }}</span>
                                                            @endforeach
                                                        </p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">{{ __('locale.Owner') }}:
                                                        </p>
                                                        <p class="mb-1">{{ $data['owner']['name'] ?? 'N/A' }}</p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('locale.OwnerDepartment') }}:
                                                        </p>
                                                        <p class="mb-1">
                                                            {{ $data['owner']['department']['name'] ?? 'N/A' }}</p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('locale.Owner Manager Department') }}:
                                                        </p>
                                                        <p class="mb-1">
                                                            @if (!empty($data['owner_manager']['name']))
                                                                {{ $data['owner_manager']['name'] }}
                                                                @if (!empty($data['owner_manager']['department']['name']))
                                                                    ---
                                                                    {{ $data['owner_manager']['department']['name'] }}
                                                                @endif
                                                            @else
                                                                N/A
                                                            @endif
                                                        </p>
                                                    </div>
                                                </div>

                                                <!-- Second Column -->
                                                <div class="col-12 col-md-4">
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('risk.ThreatMapping') }}:
                                                        </p>
                                                        <ul style="list-style: disc; padding-left: 20px;">
                                                            @foreach ($data['threatCatalogs'] as $threatCatalog)
                                                                <span
                                                                    class="badge bg-secondary">{{ $threatCatalog['name'] }}</span>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">{{ __('locale.Team') }}:
                                                        </p>
                                                        <p class="mb-1">
                                                            @php
                                                                $selectedTeams = [];
                                                                if (isset($data['team_ids'])) {
                                                                    foreach ($teams as $team) {
                                                                        if (in_array($team->id, $data['team_ids'])) {
                                                                            $selectedTeams[] = $team->name;
                                                                        }
                                                                    }
                                                                }
                                                                echo !empty($selectedTeams)
                                                                    ? implode(', ', $selectedTeams)
                                                                    : 'N/A';
                                                            @endphp
                                                        </p>
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('locale.AdditionalStakeholders') }}:
                                                        </p>
                                                        <p class="mb-1">
                                                            @if (isset($data['additionalStakeholder_ids']) && count($enabledUsers) > 0)
                                                                @php
                                                                    $selectedStakeholders = [];
                                                                    foreach ($enabledUsers as $additionalStakeholder) {
                                                                        if (
                                                                            in_array(
                                                                                $additionalStakeholder->id,
                                                                                $data['additionalStakeholder_ids'],
                                                                            )
                                                                        ) {
                                                                            $selectedStakeholders[] =
                                                                                $additionalStakeholder->name;
                                                                        }
                                                                    }
                                                                    echo implode(', ', $selectedStakeholders);
                                                                @endphp
                                                            @else
                                                                N/A
                                                            @endif
                                                        </p>
                                                    </div>
                                                </div>

                                                <!-- Third Column -->
                                                <div class="col-12 col-md-4">
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('locale.Category') }}:
                                                        </p>

                                                        @if (!empty($data['categories']) && count($data['categories']) > 0)
                                                            @foreach ($data['categories'] as $category)
                                                                <p class="mb-1">{{ $category['name'] ?? 'N/A' }}</p>
                                                            @endforeach
                                                        @else
                                                            <p class="mb-1">N/A</p>
                                                        @endif
                                                    </div>
                                                    <div class="mb-3">
                                                        <p class="fw-bold mb-1 main-color">
                                                            {{ __('locale.OwnersManager') }}:
                                                        </p>
                                                        <p class="mb-1">
                                                            {{ $data['owner_manager']['name'] ?? 'N/A' }}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-6 mb-1">
                                                    <label class="text-label">{{ __('locale.Description') }}:</label>
                                                    <div id="risk_description_editor">
                                                        {!! $data['risk_description'] !!}
                                                    </div>
                                                </div>
                                                <input type="hidden" name="risk_description_hidden"
                                                    id="risk_description_hidden">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Change Status Modal -->
                        <div class="modal fade" id="changeRiskStatusModal" tabindex="-1"
                            aria-labelledby="changeRiskStatusModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="changeRiskStatusModalLabel">
                                            {{ __('locale.SetRiskStatusTo') }}
                                        </h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                                            aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <form class="row px-0" id="change-risk-status-form" method="post"
                                            action="{{ route('admin.risk_management.ajax.update') }}">
                                            @csrf
                                            @method('put')
                                            <input type="hidden" name="id" value="{{ $data['id'] }}">
                                            <div class="col-12">
                                                <select class="select2 form-select" name="status">
                                                    <option value="" selected>{{ __('locale.select-option') }}
                                                    </option>
                                                    @foreach ($statuses as $status)
                                                        @if ($status->name == 'Closed')
                                                            @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
                                                                <option value="{{ $status->id }}">
                                                                    {{ __('risk.CloseRisk') }}
                                                                </option>
                                                            @endif
                                                        @else
                                                            <option value="{{ $status->id }}">{{ $status->name }}
                                                            </option>
                                                        @endif
                                                    @endforeach
                                                </select>
                                                <span class="error error-status"></span>
                                            </div>
                                            <div class="col-12 text-center mt-2">
                                                <button id="submit-change-risk-status" type="button"
                                                    class="btn btn-primary me-1">
                                                    {{ __('locale.Update') }}
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-analysis" role="tabpanel"
                            aria-labelledby="pills-analysis-tab">

                            <!-- Content for Step 2 -->
                            <section id="basic-tabs-components-step2" class="main-containers-step2">
                                <div class="row match-height">
                                    <!-- Basic Tabs starts -->
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <div class="tab-content">
                                                    {{-- Details tab --}}
                                                    <div class="tab-pane active" id="details"
                                                        aria-labelledby="details-tab" role="tabpanel">
                                                        <div class="row" id="static-details">

                                                            <!-- Submitted By -->
                                                            <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('locale.SubmittedBy') }}</label>
                                                                :
                                                                {{ $data['submitted_by']['name'] ?? '' }}
                                                            </div>

                                                            <!-- Risk Source -->
                                                            <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('risk.ImpactScope') }}</label>
                                                                :
                                                                {{ $data['source']['name'] ?? '' }}
                                                            </div>
                                                            <!-- Current Likelihood -->
                                                            <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('risk.CurrentLikelihood') }}</label>
                                                                :
                                                                {{ $data['likelihood']['name'] ?? '' }}
                                                            </div>
                                                            <!-- Current Impact -->
                                                            <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('risk.CurrentImpact') }}</label>
                                                                :
                                                                {{ $data['impact']['name'] ?? '' }}
                                                            </div>


                                                            {{-- <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('risk.RiskDriver') }}</label>
                                                                :
                                                                {{ $data['risk_driver'] ?? '' }}
                                                            </div> --}}
                                                            <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('report.potentialImpact') }}</label>
                                                                :
                                                                {{ $data['potential_impact'] ?? '' }}
                                                            </div>
                                                            <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('report.ExistControl') }}</label>
                                                                :
                                                                {{ $data['exist_control'] ?? '' }}
                                                            </div>

                                                            {{-- <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('locale.Type') }}</label>
                                                                :
                                                                {{ $data['type'] ?? '' }}
                                                            </div> --}}


                                                            <!-- Risk Assessment -->
                                                            {{-- <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __('risk.ResponsiblePart') }}</label>
                                                                :
                                                                <div style="max-height: 100px; overflow: auto;">
                                                                    {{ $data['assessment'] }}
                                                                </div>
                                                            </div> --}}

                                                            <!-- Risk riskConfigSource -->
                                                            <div class="mb-3">
                                                                <label
                                                                    class="text-label">{{ __('risk.riskConfigSource') }}</label>
                                                                <p class="mb-1">
                                                                    @foreach ($data['riskConfigSource'] as $riskConfig)
                                                                        <span
                                                                            class="badge bg-secondary">{{ $riskConfig['name'] }}</span>
                                                                    @endforeach
                                                                </p>
                                                            </div>

                                                            <!-- Additional Notes -->
                                                            <div class="col-12 col-md-6 mb-1">
                                                                <label
                                                                    class="text-label">{{ __("locale.Notes") }}:</label>
                                                                <div id="risk_addational_notes_show">
                                                                    {!! $data['notes'] !!}
                                                                </div>
                                                            </div>

                                                            <!-- Supporting Documentation -->
                                                            <div
                                                                class="col-12 col-md-6 mb-1 supporting_documentation_container">
                                                                <label
                                                                    class="text-label">{{ __('risk.SupportingDocumentation') }}</label>
                                                                :
                                                                @forelse($data['files'] ?? [] as $file)
                                                                    <span
                                                                        class="badge bg-secondary supporting_documentation cursor-pointer"
                                                                        style="margin-bottom: 5px"
                                                                        data-id="{{ $file['id'] }}"
                                                                        data-risk-id="{{ $data['id'] }}">{{ $file['name'] }}</span>
                                                                @empty
                                                                    <span
                                                                        class="mx-2 text-danger">{{ __('locale.NONE') }}</span>
                                                                @endforelse
                                                            </div>



                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </section>
                            <!-- Basic Tabs end -->
                        </div>
                        <div class="tab-pane fade" id="pills-evalution" role="tabpanel"
                            aria-labelledby="pills-evalution-tab">

                            <div class="tab-pane" id="mitigation" aria-labelledby="mitigation-tab" role="tabpanel">
                                <div class="card row p-4" id="static-mitigation">

                                    {{-- ── Action Buttons ── --}}
                                    <div class="d-flex justify-content-end align-items-center mb-2">
                                        @if (auth()->user()->hasPermission('plan_mitigation.create'))
                                            <button id="edit-mitigation" type="button"
                                                class="btn btn-outline-primary" data-bs-toggle="modal"
                                                data-bs-target="#editMitigationModal">
                                                {{ __('locale.EditMitigation') }}
                                            </button>
                                        @endif

                                        @if ($data['mitigation']['mitigation_id'])
                                            @if ($data['mitigation']['user_accepted_mitigations'])
                                                <button id="accept-mitigation" type="button"
                                                    class="btn btn-danger ms-2 acceptOrRejectStatus" data-value='0'
                                                    data-id="{{ $data['id'] }}">
                                                    {{ __('risk.RejectMitigation') }}
                                                </button>
                                            @else
                                                <button id="reject-mitigation" type="button"
                                                    class="btn btn-green ms-2 acceptOrRejectStatus" data-value='1'
                                                    data-id="{{ $data['id'] }}">
                                                    {{ __('risk.AcceptMitigation') }}
                                                </button>
                                            @endif
                                        @endif
                                    </div>

                                    @php
                                        /*
                                        | Numeric FK — matches planning_strategies seeder:
                                        |   1 = Accepting | 2 = Mitigating | 3 = Sharing | 4 = Avoiding
                                        */
                                        $strategyId = (int) ($data['mitigation']['planning_strategy_id'] ?? 0);

                                        // Mirrors JS strategyConfig in the modal exactly
                                        $visibilityMap = [
                                            1 => [
                                                'mitigation_date',
                                                'deadline_date',
                                                'mitigation_cost',
                                                'accepting_reason',
                                                // 'mitigation_percent',
                                                'risk_treatment_plan',
                                                'security_recommendations',
                                                'supporting_documentation',
                                            ],
                                            2 => [
                                                'mitigation_date',
                                                'deadline_date',
                                                // 'planned_mitigation_date',
                                                'mitigation_effort',
                                                'mitigation_cost',
                                                'mitigation_owner',
                                                'mitigation_team',
                                                'mitigation_percent',
                                                'mitigation_controls',
                                                'risk_treatment_plan',
                                                // 'security_requirements',
                                                'security_recommendations',
                                                'supporting_documentation',
                                            ],
                                            3 => [
                                                'mitigation_date',
                                                'deadline_date',
                                                // 'planned_mitigation_date',
                                                'mitigation_cost',
                                                'mitigation_owner',
                                                'mitigation_team',
                                                // 'mitigation_percent',
                                                'risk_treatment_plan',
                                                // 'security_requirements',
                                                'security_recommendations',
                                                'supporting_documentation',
                                            ],
                                            4 => [
                                                'deadline_date',
                                                'mitigation_owner',
                                                'risk_treatment_plan',
                                                'security_recommendations',
                                                'supporting_documentation',
                                            ],
                                        ];

                                        // Fallback when no strategy saved yet
                                        $visible = $visibilityMap[$strategyId] ?? [
                                            'risk_treatment_plan',
                                            'security_recommendations',
                                            'supporting_documentation',
                                        ];

                                        // Banner meta per strategy
                                        $strategyMeta = [
                                            1 => [
                                                'icon' => '✅',
                                                'label' => __('risk.Accepting'),
                                                'color' => '#f59e0b',
                                                'badge' => 'ACCEPT',
                                            ],
                                            2 => [
                                                'icon' => '🔧',
                                                'label' => __('risk.Mitigating'),
                                                'color' => '#3b82f6',
                                                'badge' => 'MITIGATE',
                                            ],
                                            3 => [
                                                'icon' => '🤝',
                                                'label' => __('risk.sharing'),
                                                'color' => '#8b5cf6',
                                                'badge' => 'SHARE',
                                            ],
                                            4 => [
                                                'icon' => '🚫',
                                                'label' => __('risk.avoiding'),
                                                'color' => '#ef4444',
                                                'badge' => 'AVOID',
                                            ],
                                        ];
                                        $meta = $strategyMeta[$strategyId] ?? null;

                                        $pct =
                                            isset($data['mitigation']['mitigation_percent']) &&
                                            $data['mitigation']['mitigation_percent'] >= 0 &&
                                            $data['mitigation']['mitigation_percent'] <= 100
                                                ? (int) $data['mitigation']['mitigation_percent']
                                                : 0;
                                    @endphp

                                    {{-- ── Strategy Banner ── --}}
                                    @if ($meta)
                                        <div class="smv-banner mb-3"
                                            style="border-left-color:{{ $meta['color'] }};
                                                background:{{ $meta['color'] }}11;
                                                border-color:{{ $meta['color'] }}33;">
                                            <span class="smv-banner-icon">{{ $meta['icon'] }}</span>
                                            <div class="smv-banner-info">
                                                <span class="smv-banner-label" style="color:{{ $meta['color'] }}">
                                                    {{ __('risk.PlanningStrategy') }}
                                                </span>
                                                <span class="smv-banner-value">{{ $meta['label'] }}</span>
                                            </div>
                                            <span class="smv-banner-badge" style="background:{{ $meta['color'] }}">
                                                {{ $meta['badge'] }}
                                            </span>
                                        </div>
                                    @endif

                                    {{-- ══════════════════════════════════
                                        FIELD GRID
                                    ══════════════════════════════════ --}}
                                    <div class="smv-grid mb-3">

                                        {{-- Mitigation Date --}}
                                        @if (in_array('mitigation_date', $visible))
                                            <div class="smv-field">
                                                <span class="smv-field-icon">🕐</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.MitigationDate') }}</span>
                                                    <span class="smv-field-value">
                                                        {{ format_date($data['mitigation']['mitigation_date'], 'N/A') }}
                                                    </span>
                                                </div>
                                            </div>
                                        @endif

                                        {{-- Deadline Date --}}
                                        @if (in_array('deadline_date', $visible))
                                            <div class="smv-field">
                                                <span class="smv-field-icon">📅</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.DeadlineDate') }}</span>
                                                    <span class="smv-field-value">
                                                        {{ !empty($data['mitigation']['deadline_date']) ? $data['mitigation']['deadline_date'] : 'N/A' }}
                                                    </span>
                                                </div>
                                            </div>
                                        @endif

                                        {{-- Planned Mitigation Date --}}
                                        {{-- @if (in_array('planned_mitigation_date', $visible))
                                            <div class="smv-field">
                                                <span class="smv-field-icon">🗓️</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.MitigationPlanning') }}</span>
                                                    <span class="smv-field-value">
                                                        {{ !empty($data['mitigation']['planning_date']) ? format_date($data['mitigation']['planning_date'], 'N/A') : 'N/A' }}
                                                    </span>
                                                </div>
                                            </div>
                                        @endif --}}

                                        {{-- Mitigation Effort --}}
                                        @if (in_array('mitigation_effort', $visible))
                                            <div class="smv-field">
                                                <span class="smv-field-icon">💪</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.MitigationEffort') }}</span>
                                                    <span class="smv-field-value">
                                                        {{ $data['mitigation']['mitigation_effort'] ?? 'N/A' }}
                                                    </span>
                                                </div>
                                            </div>
                                        @endif

                                        {{-- Mitigation Cost --}}
                                        {{-- @if (in_array('mitigation_cost', $visible))
                                            <div class="smv-field">
                                                <span class="smv-field-icon">💰</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.MitigationCost') }}</span>
                                                    <span class="smv-field-value">
                                                        {{ $data['mitigation']['mitigation_cost'] ?? 'N/A' }}
                                                    </span>
                                                </div>
                                            </div>
                                        @endif --}}

                                        {{-- Mitigation Owner --}}
                                        @if (in_array('mitigation_owner', $visible))
                                            <div class="smv-field">
                                                <span class="smv-field-icon">👤</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.MitigationOwner') }}</span>
                                                    <span class="smv-field-value">
                                                        @if (!empty($data['mitigation']['mitigation_owner']))
                                                            {{ $data['mitigation']['mitigation_owner'] }}
                                                            @if (!empty($data['mitigation']['mitigation_owner_manager_name']))
                                                                <br>
                                                                <small class="text-muted">
                                                                    {{ $data['mitigation']['mitigation_owner_manager_name'] }}
                                                                    @if (!empty($data['mitigation']['mitigation_owner_manager_department']))
                                                                        ---
                                                                        {{ $data['mitigation']['mitigation_owner_manager_department'] }}
                                                                    @endif
                                                                </small>
                                                                <small class="text-muted">
                                                                    ({{ __('locale.DepartmentOwner') }})
                                                                    {{ $data['mitigation']['mitigation_owner_department'] }}
                                                                    @if (!empty($data['mitigation']['mitigation_owner_department']))
                                                                        ---
                                                                        {{ $data['mitigation']['mitigation_owner_department'] }}
                                                                    @endif

                                                                </small>
                                                            @endif
                                                        @else
                                                            N/A
                                                        @endif
                                                    </span>
                                                </div>
                                            </div>
                                        @endif

                                        {{-- Mitigation Team --}}
                                        @if (in_array('mitigation_team', $visible))
                                            <div class="smv-field smv-field--wide">
                                                <span class="smv-field-icon">👥</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.MitigationTeam') }}</span>
                                                    <span class="smv-field-value">
                                                        @forelse ($data['mitigation']['mitigation_team'] as $team)
                                                            <span class="smv-tag">{{ $team['name'] }}</span>
                                                        @empty
                                                            <span class="smv-none">N/A</span>
                                                        @endforelse
                                                    </span>
                                                </div>
                                            </div>
                                        @endif

                                        {{-- Mitigation Percent --}}
                                        @if (in_array('mitigation_percent', $visible))
                                            <div class="smv-field smv-field--wide">
                                                <span class="smv-field-icon">📊</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('risk.MitigationPercent') }}</span>
                                                    <div class="smv-progress-wrap">
                                                        <div class="smv-progress-bar">
                                                            <div class="smv-progress-fill"
                                                                style="width:{{ $pct }}%"></div>
                                                        </div>
                                                        <span class="smv-progress-pct">{{ $pct }}%</span>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif

                                        {{-- Mitigation Controls --}}
                                        @if (in_array('mitigation_controls', $visible))
                                            <div class="smv-field smv-field--wide">
                                                <span class="smv-field-icon">🔒</span>
                                                <div class="smv-field-body">
                                                    <span
                                                        class="smv-field-label">{{ __('locale.MitigationControls') }}</span>
                                                    <span class="smv-field-value">
                                                        @php
                                                            $controls =
                                                                $data['mitigation']['mitigation_control_names'] ?? [];
                                                        @endphp

                                                        @forelse ($controls as $control)
                                                            <span class="smv-tag smv-tag--control">
                                                                {{ is_array($control) ? $control['name'] ?? ($control['short_name'] ?? '') : trim($control) }}
                                                            </span>
                                                        @empty
                                                            <span class="smv-none">N/A</span>
                                                        @endforelse
                                                    </span>
                                                </div>
                                            </div>
                                        @endif

                                    </div>{{-- end grid --}}

                                    {{-- ══════════════════════════════════
                                        TEXT BLOCKS
                                    ══════════════════════════════════ --}}
                                    <div class="row g-3">

                                        <div class="col-12 col-md-5">

                                            @if (in_array('accepting_reason', $visible))
                                                <div class="smv-text-block">
                                                    <div class="smv-tb-header">
                                                        <span>✅</span>
                                                        <span
                                                            class="smv-tb-label">{{ __('risk.AcceptingReason') }}</span>
                                                    </div>
                                                    <div class="smv-tb-content">
                                                        {{ $data['mitigation']['accepting_reason'] ?? '' ?: '—' }}
                                                    </div>
                                                </div>
                                            @endif

                                            {{-- @if (in_array('security_requirements', $visible))
                                                <div class="smv-text-block">
                                                    <div class="smv-tb-header">
                                                        <span>🔐</span>
                                                        <span
                                                            class="smv-tb-label">{{ __('risk.SecurityRequirements') }}</span>
                                                    </div>
                                                    <div class="smv-tb-content">
                                                        {{ $data['mitigation']['security_requirements'] ?? '' ?: '—' }}
                                                    </div>
                                                </div>
                                            @endif --}}

                                            @if (in_array('security_recommendations', $visible))
                                                <div class="smv-text-block">
                                                    <div class="smv-tb-header">
                                                        <span>💡</span>
                                                        <span
                                                            class="smv-tb-label">{{ __('risk.SecurityRecommendations') }}</span>
                                                    </div>
                                                    <div class="smv-tb-content">
                                                        {{ $data['mitigation']['security_recommendations'] ?? '' ?: '—' }}
                                                    </div>
                                                </div>
                                            @endif

                                            @if (in_array('supporting_documentation', $visible))
                                                <div class="smv-text-block">
                                                    <div class="smv-tb-header">
                                                        <span>📎</span>
                                                        <span
                                                            class="smv-tb-label">{{ __('risk.SupportingDocumentation') }}</span>
                                                    </div>
                                                    <div class="smv-tb-content"
                                                        style="display:flex;flex-wrap:wrap;gap:.35rem;">
                                                        @forelse ($data['mitigation']['files'] ?? [] as $files)
                                                            <span
                                                                class="smv-tag smv-tag--file">{{ $files['name'] }}</span>
                                                        @empty
                                                            <span class="smv-none">{{ __('locale.NONE') }}</span>
                                                        @endforelse
                                                    </div>
                                                </div>
                                            @endif

                                        </div>

                                        @if (in_array('risk_treatment_plan', $visible))
                                            <div class="col-12 col-md-7">
                                                <div class="smv-text-block h-100">
                                                    <div class="smv-tb-header">
                                                        <span>📋</span>
                                                        <span
                                                            class="smv-tb-label">{{ __('risk.risk_treatment_plan') }}</span>
                                                    </div>
                                                    <div class="smv-tb-content smv-tb-content--rich"
                                                        id="risk_current_solution_show">
                                                        {!! $data['mitigation']['current_solution'] !!}
                                                    </div>
                                                </div>
                                            </div>
                                        @endif

                                    </div>

                                </div>{{-- end card --}}

                                {{-- ── Accept Mitigation Log ── --}}
                                @if (auth()->user()->hasPermission('plan_mitigation.accept'))
                                    <div class="mb-1">
                                        <div class="card mb-0">
                                            <div class="card-body p-0">
                                                <ul class="list-group list-group-flush">
                                                    @foreach ($data['mitigation']['accepted_mitigations'] as $accepted_mitigation)
                                                        <li class="list-group-item">
                                                            {{ $accepted_mitigation['name'] }}
                                                            {{ __('risk.accepted_mitigation_on') }}
                                                            {{ $accepted_mitigation['date'] }}
                                                            {{ __('risk.at') }}
                                                            {{ $accepted_mitigation['time'] }}
                                                        </li>
                                                    @endforeach
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                @endif

                                {{-- ── Risk Acceptance Approval Workflow Cycle ── --}}
                                @php
                                    $acceptanceApproval = $data['acceptanceApproval'] ?? null;
                                    $pendingAcceptanceStep = $data['pendingAcceptanceStep'] ?? null;
                                    $acceptanceCycle = $data['acceptanceCycle'] ?? [];
                                    $acceptancePending = !empty($data['acceptancePending']);
                                    $isAcceptingStrategy = (int) ($data['mitigation']['planning_strategy_id'] ?? 0) === 1
                                        || $acceptancePending
                                        || ($acceptanceApproval && $acceptanceApproval->status === 'pending');
                                    $cycleStatus = $acceptanceApproval->status ?? ($isAcceptingStrategy ? 'planned' : null);
                                @endphp
                                @if ($isAcceptingStrategy || $acceptanceApproval)
                                    <div class="mb-3" id="risk-acceptance-workflow">
                                        <div class="card mb-0 border acceptance-cycle-card">
                                            <div class="card-header d-flex flex-wrap align-items-center justify-content-between gap-2 py-2">
                                                <div>
                                                    <h5 class="mb-0">{{ __('risk.AcceptanceCycleTitle') }}</h5>
                                                    <small class="text-muted">{{ __('risk.AcceptanceCycleHint') }}</small>
                                                </div>
                                                @if ($acceptanceApproval)
                                                    @php
                                                        $statusKey = match ($acceptanceApproval->status) {
                                                            'pending' => 'AcceptancePending',
                                                            'approved' => 'AcceptanceApproved',
                                                            'rejected' => 'AcceptanceRejected',
                                                            'cancelled' => 'AcceptanceCancelled',
                                                            default => 'AcceptanceStatus',
                                                        };
                                                        $badgeClass = match ($acceptanceApproval->status) {
                                                            'pending' => 'bg-warning text-dark',
                                                            'approved' => 'bg-success',
                                                            'rejected' => 'bg-danger',
                                                            'cancelled' => 'bg-secondary',
                                                            default => 'bg-secondary',
                                                        };
                                                    @endphp
                                                    <span class="badge {{ $badgeClass }}">{{ __('risk.' . $statusKey) }}</span>
                                                @elseif (!($data['acceptanceFlowReady'] ?? false))
                                                    <span class="badge bg-secondary">{{ __('risk.FlowNotConfigured') }}</span>
                                                @else
                                                    <div class="d-flex align-items-center gap-2">
                                                        <span class="badge bg-info">{{ __('risk.CycleNotStartedYet') }}</span>
                                                        <button type="button" class="btn btn-sm btn-primary start-acceptance-cycle-btn"
                                                            data-risk-id="{{ $data['id'] }}">
                                                            <i class="fa fa-play"></i>
                                                            {{ __('risk.StartAcceptanceCycle') }}
                                                        </button>
                                                    </div>
                                                @endif
                                                @if ($acceptanceApproval && in_array($acceptanceApproval->status, ['rejected', 'cancelled', 'approved'], true) && ($data['acceptanceFlowReady'] ?? false) && $isAcceptingStrategy)
                                                    <button type="button" class="btn btn-sm btn-outline-primary start-acceptance-cycle-btn"
                                                        data-risk-id="{{ $data['id'] }}">
                                                        <i class="fa fa-redo"></i>
                                                        {{ __('risk.StartAcceptanceCycle') }}
                                                    </button>
                                                @endif
                                            </div>

                                            <div class="card-body">
                                                @if (!empty($acceptanceCycle))
                                                    @php
                                                        $approvedCount = collect($acceptanceCycle)->where('status', 'approved')->count();
                                                        $totalSteps = count($acceptanceCycle);
                                                        $currentStepData = collect($acceptanceCycle)->firstWhere('is_current', true);
                                                    @endphp

                                                    @if ($acceptanceApproval && $acceptanceApproval->status === 'pending')
                                                        <div class="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-3">
                                                            <div class="text-muted small">
                                                                {{ __('risk.ProgressOfCycle', ['done' => $approvedCount, 'total' => $totalSteps]) }}
                                                            </div>
                                                            @if ($currentStepData)
                                                                <div class="small fw-semibold text-warning">
                                                                    {{ __('risk.NowWaitingFor') }}:
                                                                    {{ $currentStepData['user_name'] ?: __('risk.NoApproverAssigned') }}
                                                                    ({{ $currentStepData['label'] }})
                                                                </div>
                                                            @endif
                                                        </div>
                                                        <div class="progress mb-3" style="height: 8px;">
                                                            <div class="progress-bar bg-success" role="progressbar"
                                                                style="width: {{ $totalSteps ? ($approvedCount / $totalSteps) * 100 : 0 }}%"
                                                                aria-valuenow="{{ $approvedCount }}"
                                                                aria-valuemin="0"
                                                                aria-valuemax="{{ $totalSteps }}"></div>
                                                        </div>
                                                    @endif

                                                    <div class="acceptance-cycle-track">
                                                        @foreach ($acceptanceCycle as $index => $step)
                                                            @php
                                                                $status = $step['status'] ?? 'planned';
                                                                $isCurrent = !empty($step['is_current']);
                                                                $canAct = !empty($step['can_act']);
                                                                $prevApproved = $index > 0 && (($acceptanceCycle[$index - 1]['status'] ?? '') === 'approved');
                                                                $statusClass = match ($status) {
                                                                    'approved' => 'is-approved',
                                                                    'rejected' => 'is-rejected',
                                                                    'pending' => 'is-current',
                                                                    'waiting' => 'is-waiting',
                                                                    'skipped' => 'is-skipped',
                                                                    default => 'is-planned',
                                                                };
                                                                $statusLabel = match ($status) {
                                                                    'approved' => __('risk.ApprovedStep'),
                                                                    'rejected' => __('risk.RejectedStep'),
                                                                    'pending' => __('risk.CurrentStep'),
                                                                    'waiting' => __('risk.AwaitingTurn'),
                                                                    'skipped' => __('risk.SkippedStep'),
                                                                    default => __('risk.PlannedStep'),
                                                                };
                                                            @endphp

                                                            <div class="acceptance-cycle-step {{ $statusClass }} {{ $isCurrent ? 'pulse-current' : '' }}">
                                                                <div class="acceptance-cycle-number">
                                                                    @if ($status === 'approved')
                                                                        <i class="fa fa-check"></i>
                                                                    @elseif ($status === 'rejected')
                                                                        <i class="fa fa-times"></i>
                                                                    @else
                                                                        {{ $step['step_order'] }}
                                                                    @endif
                                                                </div>
                                                                <div class="acceptance-cycle-body">
                                                                    <div class="acceptance-cycle-role">
                                                                        {{ __('risk.Step') }} {{ $step['step_order'] }}:
                                                                        {{ $step['department_name'] ?: $step['label'] }}
                                                                    </div>
                                                                    <div class="acceptance-cycle-approver">
                                                                        <span class="text-muted">{{ __('risk.Approver') }}:</span>
                                                                        <strong>
                                                                            {{ $step['user_name'] ?: __('risk.NoApproverAssigned') }}
                                                                        </strong>
                                                                    </div>
                                                                    <span class="acceptance-cycle-status-pill">{{ $statusLabel }}</span>

                                                                    @if ($status === 'approved')
                                                                        <div class="acceptance-approved-banner mt-2">
                                                                            <i class="fa fa-check-circle"></i>
                                                                            {{ __('risk.ApprovedBy') }}
                                                                            <strong>{{ $step['acted_by_name'] ?: $step['user_name'] }}</strong>
                                                                            @if (!empty($step['acted_at']))
                                                                                <span class="text-muted">— {{ $step['acted_at'] }}</span>
                                                                            @endif
                                                                        </div>
                                                                    @elseif ($status === 'rejected')
                                                                        <div class="acceptance-rejected-banner mt-2">
                                                                            <i class="fa fa-times-circle"></i>
                                                                            {{ __('risk.RejectedBy') }}
                                                                            <strong>{{ $step['acted_by_name'] ?: $step['user_name'] }}</strong>
                                                                            @if (!empty($step['acted_at']))
                                                                                <span class="text-muted">— {{ $step['acted_at'] }}</span>
                                                                            @endif
                                                                        </div>
                                                                    @elseif ($status === 'waiting')
                                                                        <div class="acceptance-cycle-meta mt-2">
                                                                            {{ __('risk.WaitingPreviousStep') }}
                                                                        </div>
                                                                    @elseif ($isCurrent && !$canAct)
                                                                        <div class="acceptance-cycle-meta mt-2">
                                                                            {{ __('risk.NowWaitingFor') }}:
                                                                            <strong>{{ $step['user_name'] ?: __('risk.NoApproverAssigned') }}</strong>
                                                                        </div>
                                                                    @endif

                                                                    @if (!empty($step['comments']))
                                                                        <div class="acceptance-cycle-meta">{{ $step['comments'] }}</div>
                                                                    @endif

                                                                    @if ($canAct)
                                                                        <div class="acceptance-cycle-actions mt-2">
                                                                            <div class="alert alert-warning py-2 px-2 mb-2 small">
                                                                                {{ __('risk.YourTurnToApprove') }}
                                                                            </div>
                                                                            <div class="mb-2">
                                                                                <textarea id="acceptanceFlowComments" class="form-control form-control-sm" rows="2"
                                                                                    placeholder="{{ __('locale.Comments') }}"></textarea>
                                                                            </div>
                                                                            <div class="d-flex flex-wrap gap-2">
                                                                                <button type="button" class="btn btn-sm btn-success"
                                                                                    id="approveAcceptanceBtn"
                                                                                    data-step-id="{{ $step['step_id'] }}">
                                                                                    <i class="fa fa-check"></i>
                                                                                    {{ __('risk.ConfirmThisStep') }}
                                                                                </button>
                                                                                <button type="button" class="btn btn-sm btn-outline-danger"
                                                                                    id="rejectAcceptanceBtn"
                                                                                    data-step-id="{{ $step['step_id'] }}">
                                                                                    <i class="fa fa-times"></i>
                                                                                    {{ __('risk.RejectAcceptance') }}
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    @endif
                                                                </div>
                                                            </div>

                                                            @if ($index < count($acceptanceCycle) - 1)
                                                                <div class="acceptance-cycle-arrow {{ $status === 'approved' ? 'is-done' : '' }}"
                                                                    aria-hidden="true">
                                                                    <i class="fa fa-arrow-down d-md-none"></i>
                                                                    <i class="fa fa-arrow-right d-none d-md-inline"></i>
                                                                </div>
                                                            @endif
                                                        @endforeach
                                                    </div>
                                                @elseif ($isAcceptingStrategy && !($data['acceptanceFlowReady'] ?? false))
                                                    <div class="alert alert-warning mb-0">{{ __('risk.FlowNotConfigured') }}</div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <style>
                                        .acceptance-cycle-card {
                                            border-radius: 12px;
                                            overflow: hidden;
                                        }
                                        .acceptance-cycle-track {
                                            display: flex;
                                            flex-direction: column;
                                            align-items: stretch;
                                            gap: 0.5rem;
                                        }
                                        @media (min-width: 768px) {
                                            .acceptance-cycle-track {
                                                flex-direction: row;
                                                align-items: stretch;
                                                gap: 0.75rem;
                                            }
                                        }
                                        .acceptance-cycle-step {
                                            flex: 1;
                                            border: 1px solid #e5eaf2;
                                            border-radius: 12px;
                                            padding: 1rem;
                                            background: #fafbfd;
                                            position: relative;
                                            min-width: 0;
                                        }
                                        .acceptance-cycle-number {
                                            width: 36px;
                                            height: 36px;
                                            border-radius: 50%;
                                            display: inline-flex;
                                            align-items: center;
                                            justify-content: center;
                                            font-weight: 700;
                                            margin-bottom: 0.65rem;
                                            background: #e8eef8;
                                            color: #3b4a6b;
                                        }
                                        .acceptance-cycle-role {
                                            font-weight: 700;
                                            margin-bottom: 0.35rem;
                                            color: #1f2937;
                                        }
                                        .acceptance-cycle-approver {
                                            font-size: 0.92rem;
                                            margin-bottom: 0.5rem;
                                        }
                                        .acceptance-cycle-status-pill {
                                            display: inline-block;
                                            font-size: 0.75rem;
                                            font-weight: 600;
                                            padding: 0.2rem 0.55rem;
                                            border-radius: 999px;
                                            background: #eef2f7;
                                            color: #475569;
                                        }
                                        .acceptance-cycle-meta {
                                            margin-top: 0.4rem;
                                            font-size: 0.8rem;
                                            color: #64748b;
                                        }
                                        .acceptance-approved-banner {
                                            background: #dcfce7;
                                            color: #166534;
                                            border-radius: 8px;
                                            padding: 0.45rem 0.6rem;
                                            font-size: 0.85rem;
                                        }
                                        .acceptance-rejected-banner {
                                            background: #fee2e2;
                                            color: #991b1b;
                                            border-radius: 8px;
                                            padding: 0.45rem 0.6rem;
                                            font-size: 0.85rem;
                                        }
                                        .acceptance-cycle-arrow {
                                            display: flex;
                                            align-items: center;
                                            justify-content: center;
                                            color: #94a3b8;
                                            font-size: 1.1rem;
                                            padding: 0.15rem 0;
                                        }
                                        .acceptance-cycle-arrow.is-done {
                                            color: #22c55e;
                                        }
                                        .acceptance-cycle-step.is-approved {
                                            border-color: #86efac;
                                            background: #f0fdf4;
                                        }
                                        .acceptance-cycle-step.is-approved .acceptance-cycle-number {
                                            background: #22c55e;
                                            color: #fff;
                                        }
                                        .acceptance-cycle-step.is-approved .acceptance-cycle-status-pill {
                                            background: #dcfce7;
                                            color: #166534;
                                        }
                                        .acceptance-cycle-step.is-rejected {
                                            border-color: #fca5a5;
                                            background: #fef2f2;
                                        }
                                        .acceptance-cycle-step.is-rejected .acceptance-cycle-number {
                                            background: #ef4444;
                                            color: #fff;
                                        }
                                        .acceptance-cycle-step.is-rejected .acceptance-cycle-status-pill {
                                            background: #fee2e2;
                                            color: #991b1b;
                                        }
                                        .acceptance-cycle-step.is-current {
                                            border-color: #fbbf24;
                                            background: #fffbeb;
                                            box-shadow: 0 0 0 2px rgba(251, 191, 36, 0.25);
                                        }
                                        .acceptance-cycle-step.is-current .acceptance-cycle-number {
                                            background: #f59e0b;
                                            color: #fff;
                                        }
                                        .acceptance-cycle-step.is-current .acceptance-cycle-status-pill {
                                            background: #fef3c7;
                                            color: #92400e;
                                        }
                                        .acceptance-cycle-step.is-waiting,
                                        .acceptance-cycle-step.is-planned {
                                            opacity: 0.95;
                                        }
                                        .acceptance-cycle-step.is-skipped {
                                            opacity: 0.55;
                                        }
                                        .acceptance-cycle-step.pulse-current {
                                            animation: acceptancePulse 1.8s ease-in-out infinite;
                                        }
                                        @keyframes acceptancePulse {
                                            0%, 100% { box-shadow: 0 0 0 2px rgba(251, 191, 36, 0.2); }
                                            50% { box-shadow: 0 0 0 4px rgba(251, 191, 36, 0.35); }
                                        }
                                    </style>
                                @endif

                                {{-- ── Reset Risk Mitigations ── --}}
                                <section class="d-none" id="reset-risk-mitigations-container">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="col-12 text-center">
                                                        <button id="submit-reset-risk-mitigations" type="button"
                                                            class="btn btn-primary me-1"
                                                            data-id="{{ $data['id'] }}">
                                                            {{ __('risk.ResetMitigations') }}
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="pills-review" role="tabpanel"
                            aria-labelledby="pills-review-tab">
                            <div class="row" id="static-review">
                                <!-- Reviews Accordion -->
                                <div class="accordion mb-5" id="reviewsAccordion">
                                    <!-- Last Review Section -->
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#lastReviewCollapse"
                                                aria-expanded="false">
                                                {{ __('locale.LastReview') }}
                                                <i class="fas fa-chevron-down ms-2 position-absolute end-0"></i>
                                            </button>
                                        </h2>
                                        <div id="lastReviewCollapse" class="accordion-collapse collapse"
                                            data-bs-parent="#reviewsAccordion">
                                            <div class="accordion-body">
                                                @php
                                                    $latestReview = end($data['mgmtReviews']);
                                                @endphp

                                                @if ($latestReview)
                                                    <div class="row p-2 m-4" style="background: #f2f2f2">
                                                        <div class="col-md-6 mb-1 rounded">
                                                            {{ __('locale.ReviewDate') }}: <span
                                                                class="fw-bolder">{{ $latestReview['review_date'] }}</span>
                                                        </div>
                                                        <div class="col-md-6 mb-1 rounded">
                                                            {{ __('locale.Reviewer') }}: <span
                                                                class="fw-bolder">{{ $latestReview['reviewer'] }}</span>
                                                        </div>
                                                        <div class="col-md-6 mb-1 rounded">{{ __('locale.Review') }}:
                                                            <span class="fw-bolder">
                                                                {{ !empty($latestReview['decision_id'])
                                                                    ? __('risk.ReviewOption_' . $latestReview['decision_id'])
                                                                    : $latestReview['review'] }}
                                                            </span>
                                                        </div>
                                                        @if (!empty($latestReview['comments']))
                                                            <div class="col-md-12 mb-1 rounded">
                                                                {{ __('locale.Comment') }}:
                                                                <span class="fw-bolder">{{ $latestReview['comments'] }}</span>
                                                            </div>
                                                        @endif
                                                        @if (!empty($latestReview['rejection_justification']))
                                                            <div class="col-md-12 mb-1 rounded">
                                                                {{ __('risk.RejectionJustifications') }}:
                                                                <span class="fw-bolder">{{ $latestReview['rejection_justification'] }}</span>
                                                            </div>
                                                        @endif
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>

                                    <!-- All Reviews Section -->
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button"
                                                data-bs-toggle="collapse" data-bs-target="#allReviewsCollapse"
                                                aria-expanded="false">
                                                {{ __('locale.ViewAllReview') }}
                                                <i class="fas fa-chevron-down ms-2 position-absolute end-0"></i>
                                            </button>
                                        </h2>
                                        <div id="allReviewsCollapse" class="accordion-collapse collapse">
                                            <div class="accordion-body">
                                                @foreach ($data['mgmtReviews'] as $review)
                                                    <div class="row p-2 m-4" style="background: #f2f2f2">
                                                        <div class="col-md-6 mb-1 rouded">
                                                            {{ __('locale.ReviewDate') }}:<span
                                                                class="fw-bolder">{{ $review['review_date'] }}</span>
                                                        </div>
                                                        <div class="col-md-6 mb-1 rouded">
                                                            {{ __('locale.Reviewer') }}: <span
                                                                class="fw-bolder">{{ $review['reviewer'] }}</span>
                                                        </div>
                                                        <div class="col-md-6 mb-1 rouded">{{ __('locale.Review') }}:
                                                            <span class="fw-bolder">
                                                                {{ !empty($review['decision_id'])
                                                                    ? __('risk.ReviewOption_' . $review['decision_id'])
                                                                    : $review['review'] }}
                                                            </span>
                                                        </div>
                                                        @if (!empty($review['comments']))
                                                            <div class="col-md-12 mb-1 rouded">
                                                                {{ __('locale.Comment') }}:
                                                                <span class="fw-bolder">{{ $review['comments'] }}</span>
                                                            </div>
                                                        @endif
                                                        @if (!empty($review['rejection_justification']))
                                                            <div class="col-md-12 mb-1 rouded">
                                                                {{ __('risk.RejectionJustifications') }}:
                                                                <span class="fw-bolder">{{ $review['rejection_justification'] }}</span>
                                                            </div>
                                                        @endif
                                                    </div>
                                                @endforeach
                                            </div>
                                        </div>
                                    </div>
                                </div>





                                <!-- Reset Reviews Section -->
                                <section class="d-none" id="reset-risk-reviews-container">
                                    <div class="card">
                                        <div class="card-body text-center">
                                            <button type="button" id="submit-reset-risk-reviews"
                                                class="btn btn-primary" data-id="{{ $data['id'] }}">
                                                {{ __('risk.ResetReviews') }}
                                            </button>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>

                        <div class="tab-pane fade" id="pills-comment-trail" role="tabpanel"
                            aria-labelledby="pills-comment-trail-tab">
                            <!-- start accordion -->
                            <div class="accordion mb-5" id="accordionExample">
                                <!-- Comments Section -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingOne">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseOne"
                                            aria-expanded="false" aria-controls="collapseOne">
                                            {{ __('locale.Comments') }}
                                            <i class="fas fa-chevron-down ms-2 position-absolute end-0"></i>
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse"
                                        aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <div class="input-group mb-3">
                                                <form id="add-comment-form" method="post" action="/"
                                                    class="px-0"
                                                    style="display: flex;justify-content: space-between;width: 100%;">
                                                    @csrf
                                                    <input type="hidden" name="id"
                                                        value="{{ $data['id'] }}">
                                                    <input type="text" class="form-control"
                                                        placeholder="{{ __('locale.TypeYourCommentHere') }}"
                                                        aria-label="Recipient's username" name="comment"
                                                        aria-describedby="button-addon2">
                                                    <span class="error error-comment"></span>
                                                    @if (auth()->user()->hasPermission('riskmanagement.AbleToCommentRiskManagement'))
                                                        <button class="btn btn-primary me-2" type="button"
                                                            id="submit-add-comment">{{ __('locale.Publish') }}</button>
                                                    @endif
                                                </form>
                                            </div>
                                            <div class="rounded border p-3">
                                                @foreach ($data['comments'] as $comment)
                                                    @php
                                                        $commentTime = \Carbon\Carbon::parse($comment['date']);
                                                        $timeAgo = $commentTime->diffForHumans();
                                                    @endphp

                                                    <div class="d-flex justify-content-start align-items-center mb-4">
                                                        <div class="rounded-circle rounded-p">
                                                            {{ substr($comment['user']['name'] ?? '', 0, 2) }}</div>
                                                        <p class="ms-3 mb-0">
                                                            <span
                                                                class="fw-bold text-primary">{{ $comment['user']['name'] ?? __('locale.UnknownUser') }}</span>
                                                            <span class="text-muted">{{ __('locale.AddedAComment') }}
                                                                {{ $timeAgo }}</span>
                                                        </p>
                                                    </div>
                                                    <div class="bg-custom">
                                                        <p class="mb-4 fw-bold">
                                                            {{ $comment['comment'] }}
                                                        </p>
                                                    </div>
                                                @endforeach


                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Audit Trail Section -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button"
                                            data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                                            aria-expanded="false" aria-controls="collapseTwo">
                                            {{ __('locale.AuditTrail') }}
                                            <i class="fas fa-chevron-down ms-2 position-absolute end-0"></i>
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse"
                                        aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            <!-- Review History -->
                                            @foreach ($data['logs'] as $log)
                                                <div class="d-flex justify-content-between align-items-center p-2"
                                                    style="background-color:#f2f2f2 ;">

                                                    <p>{{ $log['message'] }}</p>
                                                    <div class="d-flex flex-column">
                                                        <p class="mb-0">
                                                            {{ date('d/m/Y', strtotime($log['timestamp'])) }}
                                                        </p>
                                                        <p class="mb-0">
                                                            {{ date('g:i A T', strtotime($log['timestamp'])) }}
                                                        </p>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>







                            <!-- CloseRisks END -->

                            <!-- End Modal Structure -->


                            <!-- End Modal Structure -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- modals --}}

        @if (auth()->user()->hasPermission('riskmanagement.update'))
            <!-- Modal Structure -->
            <div class="modal fade" tabindex="-1" role="dialog" id="editRiskModal" tabindex="-1"
                aria-labelledby="editRiskModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editRiskModalLabel">
                                {{ __('locale.EditRisk') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <!-- Form Inside Modal -->
                            <form class="row px-0" id="edit-details-form" method="post"
                                action="{{ route('admin.risk_management.ajax.update') }}">
                                @csrf
                                @method('put')
                                <input type="hidden" name="id" value="{{ $data['id'] }}">

                                <!-- Risk Mapping and Threat Mapping (2 columns) -->
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('risk.RiskMapping') }}</label>
                                        <select name="risk_catalog_mapping_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($riskGroupings as $riskGrouping)
                                                <optgroup label="{{ $riskGrouping->name }}">
                                                    @foreach ($riskGrouping->RiskCatalogs as $riskCatalog)
                                                        <option value="{{ $riskCatalog->id }}"
                                                            {{ in_array($riskCatalog->id, explode(',', $data['risk_catalog_mapping'] ?? '')) ? 'selected' : '' }}>
                                                            {{ $riskCatalog->number . ' - ' . $riskCatalog->name }}
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            @endforeach
                                        </select>
                                        <span class="error error-risk_catalog_mapping_id"></span>
                                    </div>
                                    <div class="col-md-6 mb-1">
                                        {{-- Affected Assets --}}
                                        <label class="form-label">{{ __('risk.AffectedAssets') }}</label>
                                        <select name="affected_asset_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @if (count($assetGroups))
                                                <optgroup label="{{ __('risk.AssetGroups') }}">
                                                    @foreach ($assetGroups as $assetGroup)
                                                        <option value="{{ $assetGroup->id }}_group"
                                                            {{ in_array($assetGroup->id, $data['assetGroup_ids']) ? 'selected' : '' }}>
                                                            {{ $assetGroup->name }}
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            @endif
                                            <optgroup
                                                label="{{ __('locale.Standards') }} {{ __('locale.Assets') }}">
                                                @foreach ($assets as $asset)
                                                    <option value="{{ $asset->id }}_asset"
                                                        {{ in_array($asset->id, $data['asset_ids']) ? 'selected' : '' }}>
                                                        {{ $asset->name }}
                                                    </option>
                                                @endforeach
                                            </optgroup>
                                        </select>
                                        <span class="error error-affected_asset_id"></span>
                                    </div>

                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('risk.ThreatMapping') }}</label>
                                        <select name="threat_catalog_mapping_id[]"
                                            class="form-select multiple-select2" multiple="multiple">
                                            @foreach ($threatGroupings as $threatGrouping)
                                                <optgroup label="{{ $threatGrouping->name }}">
                                                    @foreach ($threatGrouping->ThreatCatalogs as $ThreatCatalog)
                                                        <option value="{{ $ThreatCatalog->id }}"
                                                            {{ in_array($ThreatCatalog->id, explode(',', $data['threat_catalog_mapping'] ?? '')) ? 'selected' : '' }}>
                                                            {{ $ThreatCatalog->number . ' - ' . $ThreatCatalog->name }}
                                                        </option>
                                                    @endforeach
                                                </optgroup>
                                            @endforeach
                                        </select>
                                        <span class="error error-threat_catalog_mapping_id"></span>
                                    </div>
                                </div>

                                <!-- Submission Date and Category (2 columns) -->
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.SubmissionDate') }}</label>
                                        <input name="submission_date"
                                            class="form-control flatpickr-date-time-compliance"
                                            value="{{ format_date($data['submission_date'], 'N/A') }}" />
                                        <span class="error error-submission_date"></span>
                                    </div>

                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('risk.Category') }}</label>
                                        <select class="select2 form-select" name="category_id[]" multiple>
                                            @foreach ($categories as $category)
                                                <option value="{{ $category->id }}"
                                                    @if (!empty($data['category_ids']) && in_array($category->id, $data['category_ids'])) selected @endif>
                                                    {{ $category->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-category_id"></span>
                                    </div>

                                </div>

                                <!-- Site Location and Additional Stakeholders (2 columns) -->
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.SiteLocation') }}</label>
                                        <select class="form-select multiple-select2" name="location_id[]"
                                            multiple="multiple">
                                            @foreach ($locations as $location)
                                                <option value="{{ $location->id }}"
                                                    {{ in_array($location->id, $data['location_ids']) ? 'selected' : '' }}>
                                                    {{ $location->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-location_id"></span>
                                    </div>

                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.AdditionalStakeholders') }}</label>
                                        <select name="additional_stakeholder_id[]"
                                            class="form-select multiple-select2" multiple="multiple">
                                            @foreach ($enabledUsers as $additionalStakeholder)
                                                <option value="{{ $additionalStakeholder->id }}"
                                                    {{ in_array($additionalStakeholder->id, $data['additionalStakeholder_ids']) ? 'selected' : '' }}>
                                                    {{ $additionalStakeholder->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-additional_stakeholder_id"></span>
                                    </div>
                                </div>

                                <!-- Owner and Owner's Manager (2 columns) -->
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.Owner') }}</label>

                                        <select class="select2 form-select" name="owner_id" id="ownerSelect">
                                            <option value="">{{ __('locale.select-option') }}</option>

                                            @foreach ($owners as $owner)
                                                @php
                                                    $managerData = $owner->manager
                                                        ? [
                                                            'id' => $owner->manager->id,
                                                            'name' => $owner->manager->name,
                                                            'department' => $owner->manager->department
                                                                ? [
                                                                    'id' => $owner->manager->department->id,
                                                                    'name' => $owner->manager->department->name,
                                                                ]
                                                                : null,
                                                        ]
                                                        : null;
                                                @endphp

                                                <option value="{{ $owner->id }}"
                                                    data-manager='@json($managerData)'
                                                    data-department="{{ $owner->department ? $owner->department->name : '' }}"
                                                    {{ ($data['owner_id'] ?? null) == $owner->id ? 'selected' : '' }}>
                                                    {{ $owner->name }}
                                                    @if ($owner->department)
                                                        ({{ $owner->department->name }})
                                                    @endif
                                                </option>
                                            @endforeach
                                        </select>

                                        <span class="error error-owner_id"></span>
                                    </div>

                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.departmentOwner') }}</label>
                                        <input type="text" disabled class="form-control" id="departmentOwner" />
                                    </div>

                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.OwnersManager') }}</label>
                                        <select class="select2 form-select" name="owner_manager_id"
                                            id="managerSelect" disabled>
                                            <option value="">{{ __('locale.select-option') }}</option>
                                        </select>
                                        <span class="error error-owners_manager_id"></span>
                                    </div>
                                </div>

                                <!-- Tags and Team (2 columns) -->
                                <div class="row">
                                    {{-- <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('risk.Tags') }}</label>
                                        <select name="tags[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($tags as $tag)
                                                <option value="{{ $tag->id }}"
                                                    {{ in_array($tag->id, $data['tag_ids']) ? 'selected' : '' }}>
                                                    {{ $tag->tag }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-tags"></span>
                                    </div> --}}

                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.Team') }}</label>
                                        <select name="team_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($teams as $team)
                                                <option value="{{ $team->id }}"
                                                    {{ in_array($team->id, $data['team_ids']) ? 'selected' : '' }}>
                                                    {{ $team->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-team_id"></span>
                                    </div>
                                </div>

                                <!-- External Reference ID -->
                                {{-- <div class="row">
                                    <div class="col-12 mb-3">
                                        <label class="form-label">{{ __('locale.ExternalReferenceId') }}</label>
                                        <input type="text" name="reference_id" class="form-control dt-post"
                                            aria-label="{{ __('locale.ExternalReferenceId') }}"
                                            value="{{ $data['reference_id'] }}" />
                                        <span class="error error-reference_id"></span>
                                    </div>
                                </div> --}}
                                <div class="col-md-6 mb-1">
                                    {{-- Additional Notes --}}
                                    <label class="form-label">{{ __('locale.Description') }}</label>
                                    <div id="risk_description" style="height:100px;">
                                        {!! $data['risk_description'] !!}
                                    </div>
                                </div>
                                <input type="hidden" name="first_edit" value="1">
                                <!-- Submit and Cancel buttons -->
                                <div class="col-12 text-center mt-2">
                                    <button id="submit-edit-details" type="button" class="btn btn-primary me-1">
                                        {{ __('locale.SaveDetails') }}
                                    </button>
                                    <button id="cancel-edit-details" type="reset" class="btn btn-danger"
                                        data-bs-dismiss="modal">
                                        {{ __('locale.Cancel') }}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <!-- CloseRisks END -->
        @if (auth()->user()->hasPermission('riskmanagement.update'))
            <!-- Modal Structure -->
            <div class="modal fade" tabindex="-1" role="dialog" id="editRiskModal2"
                aria-labelledby="editRiskModal2Label" aria-hidden="true">
                <div class="modal-dialog modal-xl">
                    <div class="modal-content" style="width: 1234px;">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editRiskModal2Label">
                                {{ __('locale.EditRisk') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <!-- Form Inside Modal -->
                            <form class="row" id="edit-details-form2" method="post"
                                action="{{ route('admin.risk_management.ajax.update') }}">
                                @csrf
                                @method('put')
                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                <div class="row">
                                    {{-- Control Regulation --}}
                                    <div class="mb-1">
                                        <label class="form-label ">{{ __('risk.ControlRegulation') }}</label>
                                        <select class="select2 form-select" name="framework_id">
                                            <option value="" selected>
                                                {{ __('locale.select-option') }}
                                            </option>
                                            @foreach ($frameworks as $framework)
                                                <option value="{{ $framework->id }}"
                                                    data-controls="{{ json_encode($framework->FrameworkControls) }}"
                                                    {{ $data['regulation'] == $framework->id ? 'selected' : '' }}>
                                                    {{ $framework->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-framework_id"></span>
                                    </div>

                                    {{-- Control Number --}}
                                    <div class="mb-1">
                                        <label class="form-label ">{{ __('risk.ControlNumber') }}</label>

                                        <select class="select2 form-select" name="control_id">
                                            <option value="" selected>
                                                {{ __('locale.select-option') }}
                                            </option>
                                            @foreach ($data['framework_controls'] as $frameworkControl)
                                                <option title="{{ $frameworkControl['description'] ?? '' }}"
                                                    value="{{ $frameworkControl['id'] }}"
                                                    {{ $data['control_id'] == $frameworkControl['id'] ? 'selected' : '' }}>
                                                    {{ $frameworkControl['short_name'] }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-control_id"></span>
                                    </div>
                                </div>
                                <!-- First Row -->
                                <div class="row">
                                    <div class="col-md-6 mb-1">
                                        {{-- Technology --}}
                                        <label class="form-label">{{ __('locale.Technology') }}</label>
                                        <select name="technology_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($technologies as $technology)
                                                <option value="{{ $technology->id }}"
                                                    {{ in_array($technology->id, $data['technology_ids']) ? 'selected' : '' }}>
                                                    {{ $technology->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-technology_id"></span>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-1">
                                    {{-- Technology --}}
                                    <label class="form-label">{{ __('locale.RiskConfigSource') }}</label>
                                    <select name="risk_config_source_id[]" class="form-select multiple-select2"
                                        multiple="multiple">
                                        @foreach ($riskConfigSources as $riskConfigSource)
                                            <option value="{{ $riskConfigSource->id }}"
                                                {{ in_array($riskConfigSource->id, $data['risk_config_source_id']) ? 'selected' : '' }}>
                                                {{ $riskConfigSource->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <span class="error error-risk_config_source_id"></span>
                                </div>

                                <!-- Second Row -->
                                <div class="row">
                                    <div class="col-md-6 mb-1">
                                        {{-- Risk Source --}}
                                        <label class="form-label">{{ __('risk.ImpactScope') }}</label>
                                        <select class="select2 form-select" name="risk_source_id">
                                            <option value="" selected>
                                                {{ __('locale.select-option') }}
                                            </option>
                                            @foreach ($riskSources as $riskSource)
                                                <option value="{{ $riskSource->id }}"
                                                    {{ $data['source_id'] == $riskSource->id ? 'selected' : '' }}>
                                                    {{ $riskSource->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-risk_source_id"></span>
                                    </div>

                                </div>

                                <!-- Third Row -->
                                <div class="row">
                                    <div class="col-md-6 mb-1">
                                        {{-- Current Likelihood --}}
                                        <label class="form-label">{{ __('risk.CurrentLikelihood') }}</label>
                                        <select class="select2 form-select" name="current_likelihood_id">
                                            <option value="" disabled hidden selected>
                                                {{ __('locale.select-option') }}
                                            </option>
                                            @foreach ($riskLikelihoods as $riskLikelihood)
                                                <option value="{{ $riskLikelihood->id }}"
                                                    {{ $data['likelihood']['id'] == $riskLikelihood->id ? 'selected' : '' }}>
                                                    {{ $riskLikelihood->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-current_likelihood_id"></span>
                                    </div>
                                    <div class="col-md-6 mb-1">
                                        {{-- Current Impact --}}
                                        <label class="form-label">{{ __('risk.CurrentImpact') }}</label>
                                        <select class="select2 form-select" name="current_impact_id">
                                            <option value="" disabled hidden selected>
                                                {{ __('locale.select-option') }}
                                            </option>
                                            @foreach ($impacts as $impact)
                                                <option value="{{ $impact->id }}"
                                                    {{ $data['impact']['id'] == $impact->id ? 'selected' : '' }}>
                                                    {{ $impact->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-current_impact_id"></span>
                                    </div>
                                </div>

                                {{-- <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.RiskDriver') }}</label>
                                        <input type="text" class="form-control"
                                            value="{{ $data['risk_driver'] ?? '' }}" name="risk_driver" />
                                        <span class="error error-risk_driver"></span>
                                    </div>
                                </div> --}}
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.potentialImpact') }}</label>
                                        <input type="text" class="form-control"
                                            value="{{ $data['potential_impact'] ?? '' }}" name="potential_impact" />
                                        <span class="error error-potential_impact"></span>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 mb-3">

                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.ExistControl') }}</label>
                                        <input type="text" class="form-control"
                                            value="{{ $data['exist_control'] ?? '' }}" name="exist_control" />
                                        <span class="error error-exist_control"></span>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6 mb-3">
                                    <div class="mb-1">
                                        <label class="form-label">
                                            {{ __('locale.effectiveness_of_current_controls') }}
                                        </label>
                                        <select class="form-control" name="effectiveness_of_current_controls">
                                            @php
                                                $effectivenessLabels = [
                                                    0 => 'لايوجد ضابط (NC - Not Controlled)',
                                                    1 => 'غير فعال (NE - Not Effective)',
                                                    2 => 'غير فعّالة إلى حد كبير (SI - Significantly Ineffective)',
                                                    3 => 'فعّالة بدرجة محدودة (PE - Partially Effective)',
                                                    4 => 'فعّالة جزئياً (ME - Mostly Effective)',
                                                    5 => 'فعّال بالكامل (FE - Fully Effective)',
                                                ];
                                                $currentValue = $data['effectiveness_of_current_controls'] ?? 0;
                                            @endphp

                                            @foreach ($effectivenessLabels as $key => $label)
                                                <option value="{{ $key }}"
                                                    {{ $key == $currentValue ? 'selected' : '' }}>
                                                    {{ $label }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-effectiveness_of_current_controls"></span>
                                    </div>
                                </div>



                                <div class="col-12 col-md-6 mb-3">

                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.Type') }}</label>
                                        <input type="text" class="form-control"
                                            value="{{ $data['type'] ?? '' }}" name="type" />
                                        <span class="error error-type"></span>
                                    </div>
                                </div>
                                <!-- Additional Notes Row -->
                                <div class="row">
                                    {{-- <div class="col-md-6 mb-1"> --}}
                                    {{-- Risk Assessment --}}
                                    {{-- <label class="form-label">{{ __('risk.ResponsiblePart') }}</label>
                                        <textarea class="form-control" name="risk_assessment" rows="3">{{ $data['assessment'] }}</textarea>
                                        <span class="error error-risk_assessment"></span>
                                    </div> --}}
                                    <div class="col-md-12 mb-1">
                                        {{-- Additional Notes --}}
                                        <label class="form-label">{{ __("locale.Notes") }}</label>
                                        <div id="risk_addational_notes" style="height:100px;">
                                            {!! $data['notes'] !!}
                                        </div>
                                    </div>
                                </div>

                                <input type="hidden" name="second_edit" value="2">

                                <!-- Submit and Cancel buttons -->
                                <div class="col-12 text-center mt-2">
                                    <button id="submit-edit-details2" type="button" class="btn btn-primary me-1">
                                        {{ __('locale.SaveDetails') }}
                                    </button>
                                    <button id="cancel-edit-details2" type="reset" class="btn btn-danger"
                                        data-bs-dismiss="modal">
                                        {{ __('locale.Cancel') }}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        <!-- Modal Structure -->
        <div class="modal fade" id="addCommentModal" tabindex="-1" aria-labelledby="addCommentModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addCommentModalLabel">
                            {{ __('locale.Comments') }}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Add Comment Form -->
                        <div id="add-comment" data-id="IDIDID" style="display: none;">
                            <form id="add-comment-form" method="post" action="/" class="px-0">
                                @csrf
                                <input type="hidden" name="id" value="{{ $data['id'] }}">
                                <textarea class="form-control" rows="3" name="comment"></textarea>
                                <span class="error error-comment"></span>

                                <div class="text-end">
                                    <button id="submit-add-comment" class="btn btn-success mt-2"
                                        type="button">{{ __('locale.Submit') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="changeRiskStatusModal" tabindex="-1"
            aria-labelledby="changeRiskStatusModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="changeRiskStatusModalLabel">
                            {{ __('locale.SetRiskStatusTo') }}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Form for changing risk status -->
                        <form class="row px-0" id="change-risk-status-form" method="post"
                            action="{{ route('admin.risk_management.ajax.update') }}">
                            @csrf
                            @method('put')
                            <input type="hidden" name="id" value="{{ $data['id'] }}">
                            <div class="col-12">
                                {{-- Close reason --}}
                                <div class="mb-1">
                                    <select class="select2 form-select" name="status">
                                        <option value="" selected>
                                            {{ __('locale.select-option') }}
                                        </option>
                                        @foreach ($statuses as $status)
                                            @if ($status->name == 'Closed')
                                                @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
                                                    <option value="{{ $status->id }}">
                                                        {{ __('risk.CloseRisk') }}
                                                    </option>
                                                @endif
                                            @else
                                                <option value="{{ $status->id }}">
                                                    {{ $status->name }}
                                                </option>
                                            @endif
                                        @endforeach
                                    </select>
                                    <span class="error error-status"></span>
                                </div>
                            </div>
                            <div class="col-12 text-center mt-2">
                                <button id="submit-change-risk-status" type="button"
                                    class="btn btn-primary me-1">{{ __('locale.Update') }}</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!-- CloseRisks start -->
        @if (auth()->user()->hasPermission('riskmanagement.AbleToCloseRisks'))
            <!-- Close Risk Modal -->
            <div class="modal fade" id="closeRiskModal" tabindex="-1" aria-labelledby="closeRiskModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="closeRiskModalLabel">
                                {{ __('risk.CloseRisk') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="close-reason-form" method="post"
                                action="{{ route('admin.risk_management.ajax.update') }}">
                                @csrf
                                @method('put')
                                <input type="hidden" name="id" value="{{ $data['id'] }}">

                                <!-- Close reason -->
                                <div class="mb-3">
                                    <label class="form-label">{{ __('locale.Reason') }}</label>
                                    <select class="select2 form-select" name="close_reason">
                                        <option value="" selected>
                                            {{ __('locale.select-option') }}
                                        </option>
                                        @foreach ($closeReasons as $closeReason)
                                            <option value="{{ $closeReason->id }}">
                                                {{ $closeReason->name }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <span class="error error-close_reason"></span>
                                </div>

                                <!-- Close-Out Information note -->
                                <div class="mb-3">
                                    <label class="form-label">{{ __('risk.CloseOutInformation') }}</label>
                                    <textarea class="form-control" name="note" rows="3"></textarea>
                                    <span class="error error-note"></span>
                                </div>

                                <div class="text-center mt-3">
                                    <button id="submit-close-reason" type="button"
                                        class="btn btn-primary me-1">{{ __('locale.Submit') }}</button>
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">{{ __('locale.Cancel') }}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        @endif

        @if (auth()->user()->hasPermission('plan_mitigation.create'))
            <!-- Modal -->
            <div class="modal fade" id="editMitigationModal" tabindex="-1"
                aria-labelledby="editMitigationModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-fullscreen">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editMitigationModalLabel">
                                {{ __('locale.EditMitigation') }}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form class="row px-0" id="edit-mitigation-form" method="post" action="/">
                                @csrf
                                <input type="hidden" name="risk_id" value="{{ $data['id'] }}">

                                <div class="col-12 col-md-6">

                                    {{-- Mitigation Date Label --}}
                                    <div class="mb-1">
                                        <label class="text-label">{{ __('risk.MitigationDate') }}</label>
                                    </div>

                                    {{-- Deadline Date --}}
                                    <div class="mb-1" data-field="deadline_date">
                                        <label class="text-label">{{ __('risk.DeadLineDate') }}</label>
                                        <input name="deadline_date"
                                            class="form-control flatpickr-date-time-compliance"
                                            value="{{ $data['mitigation']['deadline_date'] ?? '' }}" />
                                        <span class="error error-deadline_date"></span>
                                    </div>

                                    {{-- Planned Mitigation Date --}}
                                    {{-- <div class="mb-1" data-field="planned_mitigation_date">
                                        <label class="text-label">{{ __('risk.MitigationPlanning') }}</label>
                                        <input name="planned_mitigation_date"
                                            class="form-control flatpickr-date-time-compliance"
                                            value="{{ format_date($data['mitigation']['planning_date'], '') }}" />
                                        <span class="error error-planned_mitigation_date"></span>
                                    </div> --}}

                                    {{-- Planning Strategy — value="1|2|3|4" (FK to planning_strategies.id) --}}
                                    <div class="mb-1" data-field="planning_strategy">
                                        <label class="text-label">{{ __('risk.PlanningStrategy') }}</label>
                                        <select class="select2 form-select" name="planning_strategy"
                                            id="planning_strategy_select">
                                            <option value="">{{ __('locale.select-option') }}</option>
                                            <option value="1"
                                                {{ ($data['mitigation']['planning_strategy_id'] ?? '') == 1 ? 'selected' : '' }}>
                                                {{ __('risk.Accepting') }}
                                            </option>
                                            <option value="2"
                                                {{ ($data['mitigation']['planning_strategy_id'] ?? '') == 2 ? 'selected' : '' }}>
                                                {{ __('risk.Mitigating') }}
                                            </option>
                                            <option value="3"
                                                {{ ($data['mitigation']['planning_strategy_id'] ?? '') == 3 ? 'selected' : '' }}>
                                                {{ __('risk.sharing') }}
                                            </option>
                                            <option value="4"
                                                {{ ($data['mitigation']['planning_strategy_id'] ?? '') == 4 ? 'selected' : '' }}>
                                                {{ __('risk.avoiding') }}
                                            </option>
                                        </select>
                                        <span class="error error-planning_strategy"></span>
                                    </div>

                                    {{-- Accepting Reason (shown only when strategy = Accepting) --}}
                                    <div class="mb-1" data-field="accepting_reason">
                                        <label class="text-label"
                                            for="accepting_reason_input">{{ __('risk.AcceptingReason') }}</label>
                                        <textarea class="form-control" name="accepting_reason"
                                            id="accepting_reason_input" rows="3"
                                            placeholder="{{ __('risk.EnterAcceptingReason') }}">{{ $data['mitigation']['accepting_reason'] ?? '' }}</textarea>
                                        <span class="error error-accepting_reason text-danger"></span>
                                    </div>

                                    {{-- Mitigation Effort --}}
                                    <div class="mb-1" data-field="mitigation_effort">
                                        <label class="text-label">{{ __('risk.MitigationEffort') }}</label>
                                        <select class="select2 form-select" name="mitigation_effort">
                                            <option value="">{{ __('locale.select-option') }}</option>
                                            @foreach ($mitigationEfforts as $mitigationEffort)
                                                <option value="{{ $mitigationEffort->id }}"
                                                    {{ ($data['mitigation']['mitigation_effort_id'] ?? '') == $mitigationEffort->id ? 'selected' : '' }}>
                                                    {{ $mitigationEffort->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-mitigation_effort"></span>
                                    </div>

                                    {{-- Mitigation Cost --}}
                                    {{-- <div class="mb-1" data-field="mitigation_cost">
                                        <label class="text-label">{{ __('risk.MitigationCost') }}</label>
                                        <select class="select2 form-select" name="mitigation_cost">
                                            <option value="">{{ __('locale.select-option') }}</option>
                                            @foreach ($mitigationCosts as $mitigationCost)
                                                <option value="{{ $mitigationCost->id }}"
                                                    {{ ($data['mitigation']['mitigation_cost_id'] ?? '') == $mitigationCost->id ? 'selected' : '' }}>
                                                    {{ $mitigationCost->name }}
                                                    @php
                                                        $valuation_level_name = '';
                                                        if (!empty($mitigationCost->valuation_level_name)) {
                                                            $valuation_level_name =
                                                                ' (' . $mitigationCost->valuation_level_name . ')';
                                                        }
                                                        if ($mitigationCost->min_value === $mitigationCost->max_value) {
                                                            echo get_setting('currency') .
                                                                number_format($mitigationCost->min_value) .
                                                                $valuation_level_name;
                                                        } else {
                                                            echo get_setting('currency') .
                                                                number_format($mitigationCost->min_value) .
                                                                ' to ' .
                                                                get_setting('currency') .
                                                                number_format($mitigationCost->max_value) .
                                                                $valuation_level_name;
                                                        }
                                                    @endphp
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-mitigation_cost"></span>
                                    </div> --}}

                                    {{-- Mitigation Owner --}}
                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.Mitigation Owner') }}</label>

                                        <select class="select2 form-select" name="mitigation_owner_id"
                                            id="mitigationOwnerSelect">
                                            <option value="">{{ __('locale.select-option') }}</option>

                                            @foreach ($enabledUsers as $owner)
                                                @php
                                                    $managerData = $owner->manager
                                                        ? [
                                                            'id' => $owner->manager->id,
                                                            'name' => $owner->manager->name,
                                                            'department' => $owner->manager->department
                                                                ? [
                                                                    'id' => $owner->manager->department->id,
                                                                    'name' => $owner->manager->department->name,
                                                                ]
                                                                : null,
                                                        ]
                                                        : null;
                                                @endphp

                                                <option value="{{ $owner->id }}"
                                                    data-manager='@json($managerData)'
                                                    data-department="{{ $owner->department ? $owner->department->name : '' }}"
                                                    {{ ($data['mitigation']['mitigation_owner_id'] ?? null) == $owner->id ? 'selected' : '' }}>
                                                    {{ $owner->name }}
                                                </option>
                                            @endforeach
                                        </select>

                                        <span class="error error-mitigation_owner_id"></span>
                                    </div>

                                    <div class="col-12 col-md-6 mb-3">
                                        <label class="form-label">{{ __('locale.departmentOwner') }}</label>
                                        <input type="text" disabled class="form-control"
                                            id="departmentMitigationOwner" />
                                    </div>

                                    <div class="mb-1">
                                        <label class="form-label">{{ __('locale.MitigationOwnersManager') }}</label>

                                        <select class="select2 form-select" name="mitigation_owner_manager_id"
                                            id="mitigationManagerSelect" disabled>
                                            <option value="">{{ __('locale.select-option') }}</option>
                                        </select>

                                        <span class="error error-mitigation_owner_manager_id"></span>
                                    </div>

                                    {{-- Mitigation Team --}}
                                    <div class="mb-1" data-field="mitigation_team">
                                        <label class="text-label">{{ __('risk.MitigationTeam') }}</label>
                                        <select name="mitigation_team_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($teams as $team)
                                                <option value="{{ $team->id }}"
                                                    {{ in_array($team->id, $data['mitigation']['team_ids'] ?? []) ? 'selected' : '' }}>
                                                    {{ $team->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                        <span class="error error-mitigation_team_id"></span>
                                    </div>

                                    {{-- Mitigation Percent --}}
                                    <div class="mb-1" data-field="mitigation_percent">
                                        <label class="text-label">{{ __('risk.MitigationPercent') }}</label>
                                        <input type="number" min="0" max="100" class="form-control"
                                            name="mitigation_percent"
                                            value="{{ $data['mitigation']['mitigation_percent'] ?? '' }}">
                                        <span class="error error-mitigation_percent"></span>
                                    </div>

                                    {{-- Mitigation Controls --}}
                                    <div class="mb-1" data-field="mitigation_controls">
                                        <label class="text-label">{{ __('locale.MitigationControls') }}</label>
                                        <select name="mitigation_control_id[]" class="form-select multiple-select2"
                                            multiple="multiple">
                                            @foreach ($frameworks as $framework)
                                                @foreach ($framework->FrameworkControls as $control)
                                                    <option value="{{ $control->id }}"
                                                        title="{{ $control->description }}"
                                                        {{ in_array($control->id, $data['mitigation']['mitigation_control_ids'] ?? []) ? 'selected' : '' }}>
                                                        {{ $control->short_name }}
                                                    </option>
                                                @endforeach
                                            @endforeach
                                        </select>
                                        <span class="error error-mitigation_control_id"></span>
                                    </div>

                                </div>{{-- end col-md-6 left --}}

                                <div class="col-12 col-md-6">

                                    {{-- Risk Treatment Plan --}}
                                    <div class="mb-1" data-field="risk_treatment_plan">
                                        <label class="text-label">{{ __('risk.risk_treatment_plan') }}</label>
                                        <div id="risk_current_solution">
                                            {!! $data['mitigation']['current_solution'] !!}
                                        </div>
                                    </div>

                                    {{-- Security Requirements --}}
                                    {{-- <div class="mb-1" data-field="security_requirements">
                                        <label class="text-label">{{ __('risk.SecurityRequirements') }}</label>
                                        <textarea class="form-control" name="security_requirements" rows="3">{{ $data['mitigation']['security_requirements'] }}</textarea>
                                        <span class="error error-security_requirements"></span>
                                    </div> --}}

                                    {{-- Security Recommendations --}}
                                    <div class="mb-1" data-field="security_recommendations">
                                        <label class="text-label">{{ __('risk.SecurityRecommendations') }}</label>
                                        <textarea class="form-control" name="security_recommendations" rows="3">{{ $data['mitigation']['security_recommendations'] }}</textarea>
                                        <span class="error error-security_recommendations"></span>
                                    </div>

                                    {{-- Supporting Documentation --}}
                                    <div class="mb-1 supporting_documentation_container"
                                        data-field="supporting_documentation">
                                        <label class="text-label">{{ __('risk.SupportingDocumentation') }}</label>
                                        <input type="file" multiple name="supporting_documentation[]"
                                            class="form-control dt-post"
                                            aria-label="{{ __('risk.SupportingDocumentation') }}" />
                                        <span class="error error-supporting_documentation"></span>
                                        @forelse($data['mitigation']['files'] ?? [] as $file)
                                            <div class="mitigation-files">
                                                <span
                                                    class="badge bg-secondary supporting_documentation cursor-pointer"
                                                    data-id="{{ $file['id'] }}"
                                                    data-risk-id="{{ $data['id'] }}">{{ $file['name'] }}</span>
                                                <span
                                                    class="text-danger delete_supporting_documentation cursor-pointer"
                                                    data-id="{{ $file['id'] }}"
                                                    data-risk-id="{{ $data['id'] }}">
                                                    <i data-feather="x"></i>
                                                </span>
                                            </div>
                                        @empty
                                            <span class="mx-2 text-danger">{{ __('locale.NONE') }}</span>
                                        @endforelse
                                    </div>

                                </div>{{-- end col-md-6 right --}}

                                <div class="col-12 text-center mt-2">
                                    <button id="submit-edit-mitigation" type="button"
                                        class="btn btn-primary me-1">
                                        {{ __('locale.SaveMitigation') }}
                                    </button>
                                    <button id="cancel-edit-mitigation" type="reset" class="btn btn-danger"
                                        data-bs-dismiss="modal">
                                        {{ __('locale.Cancel') }}
                                    </button>
                                </div>

                            </form>
                        </div>{{-- end modal-body --}}
                    </div>
                </div>
            </div>
        @endif

        <!-- Download File Form -->
        <form class="d-none" id="download-file-form" method="post"
            action="{{ route('admin.risk_management.ajax.download_file') }}">
            @csrf
            <input type="hidden" name="id">
            <input type="hidden" name="risk_id">
        </form>

        <!-- end tab -->

        <!-- Add Review Form -->
        <div class="modal fade" id="addReviewModal" tabindex="-1" aria-labelledby="addReviewModalLabel"
            aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addReviewModalLabel">{{ __('locale.AddReview') }}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"
                            aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row" id="add-review-form" method="post" action="/">
                            @csrf
                            <input type="hidden" name="risk_id" value="{{ $data['id'] }}">

                            <div class="col-12 col-md-6">
                                <!-- Basic Review Information -->
                                <div class="mb-1">
                                    <label class="text-label">{{ __('locale.ReviewDate') }}</label>:
                                    {{ date(get_default_date_format()) }}
                                </div>
                                <div class="mb-1">
                                    <label class="text-label">{{ __('locale.Reviewer') }}</label>:
                                    {{ auth()->user()->name }}
                                </div>

                                <!-- Review Selection Fields -->
                                <div class="mb-1">
                                    <label class="text-label">{{ __('locale.Review') }}</label>
                                    <select class="select2 form-select" name="review" id="showRiskReviewSelect">
                                        <option value="" selected disabled>
                                            {{ __('locale.select-option') }}
                                        </option>
                                        @foreach ($reviews as $reviewOption)
                                            <option value="{{ $reviewOption->id }}">
                                                {{ __('risk.ReviewOption_' . $reviewOption->id) }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <span class="error error-review"></span>
                                </div>

                                <!-- Comments -->
                                <div class="mb-1" id="show-review-comment-container">
                                    <label class="text-label">{{ __('locale.Comment') }}</label>
                                    <textarea class="form-control" name="comments" rows="3"></textarea>
                                    <span class="error error-comments"></span>
                                </div>

                                <!-- Rejection Justifications -->
                                <div class="mb-1 d-none" id="show-rejection-justification-container">
                                    <label class="text-label">{{ __('risk.RejectionJustifications') }}</label>
                                    <textarea class="form-control" name="rejection_justification" rows="3"
                                        placeholder="{{ __('risk.WriteRejectionJustifications') }}"></textarea>
                                    <span class="error error-rejection_justification"></span>
                                </div>
                            </div>

                            <!-- Next Review Date Section -->
                            <div class="col-12 col-md-6 px-lg-5">
                                <div class="mb-1">
                                    <p>{{ __('locale.BasedOnTheCurrentRiskScore') }}
                                        {{ $data['get_next_review_default'] }}
                                    </p>
                                    <p>{{ __('locale.WouldYouLikeToUseADifferentDate') }}</p>
                                    <label class="text-label">{{ __('locale.NextReviewDate') }}</label>
                                    <input name="next_review_date"
                                        class="form-control flatpickr-date-time-compliance"
                                        value="{{ $data['get_next_review_default'] }}" />
                                    <span class="error error-next_review_date"></span>
                                </div>
                            </div>

                            <!-- Form Actions -->
                            <div class="col-12 text-center mt-2">
                                <button type="button" id="submit-add-review" class="btn btn-primary me-1">
                                    {{ __('locale.SubmitReview') }}
                                </button>
                                <button type="reset" id="cancel-add-review" class="btn btn-danger"
                                    data-bs-dismiss="modal">
                                    {{ __('locale.Cancel') }}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('vendor-script')
    <script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
    <script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
    <script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
    <script src="{{ asset('vendors/js/extensions/moment.min.js') }}"></script>
    <script src="{{ asset('js/scripts/highcharts.js') }}"></script>
    <script>
        const lang = [],
            URLs = [],
            assets = [];
        lang['confirmDelete'] = "{{ __('locale.ConfirmDelete') }}";
        lang['cancel'] = "{{ __('locale.Cancel') }}";
        lang['success'] = "{{ __('locale.Success') }}";
        lang['error'] = "{{ __('locale.Error') }}";
        lang['confirmDeleteFileMessage'] = "{{ __('locale.AreYouSureToDeleteThisFile') }}";
        lang['revert'] = "{{ __('locale.YouWontBeAbleToRevertThis') }}";
        lang['confirmAction'] = "{{ __('locale.ConfirmAction') }}";
        lang['confirmMitigationMessage'] = "{{ __('locale.AreYouSureToConfirmThisMitigationAction') }}";
        lang['confirmResetMitigationsMessage'] = "{{ __('risk.ConfirmResetMitigations') }}";
        lang['acceptingReasonRequired'] = "{{ __('risk.AcceptingReasonRequired') }}";
        lang['yes'] = "{{ __('locale.Yes') }}";
        lang['no'] = "{{ __('locale.No') }}";
        URLs['updateSubject'] = "{{ route('admin.risk_management.ajax.update_subject') }}";
        URLs['updateRiskScoring'] = "{{ route('admin.risk_management.ajax.update_risk_scoring') }}";
        URLs['addComment'] = "{{ route('admin.risk_management.ajax.add_comment') }}";
        URLs['getRiskLevels'] = "{{ route('admin.risk_management.ajax.get_risk_levels') }}";
        URLs['residualScoringHistory'] =
            "{{ route('admin.risk_management.ajax.residual_scoring_history', $data['id']) }}";
        URLs['getScoringHistories'] = "{{ route('admin.risk_management.ajax.get_scoring_histories', $data['id']) }}";
        URLs['updateDetails'] = "{{ route('admin.risk_management.ajax.update') }}";
        URLs['deleteFile'] = "{{ route('admin.risk_management.ajax.delete_file') }}";
        URLs['acceptRejectMitigation'] = "{{ route('admin.risk_management.ajax.accept_reject_mitigation') }}";
        URLs['updateRiskMitigation'] = "{{ route('admin.risk_management.ajax.update_risk_mitigation') }}";
        URLs['acceptance_flow_act'] = "{{ route('admin.risk_management.ajax.acceptance_flow.act') }}";
        URLs['acceptance_flow_start'] = "{{ route('admin.risk_management.ajax.acceptance_flow.start') }}";
        URLs['addRiskReview'] = "{{ route('admin.risk_management.ajax.add_risk_review') }}";
        URLs['riskCloseReason'] = "{{ route('admin.risk_management.ajax.risk_close_reason') }}";
        URLs['riskReopen'] = "{{ route('admin.risk_management.ajax.risk_reopen') }}";
        URLs['riskChangeStatus'] = "{{ route('admin.risk_management.ajax.risk_Change_Status') }}";
        URLs['resetRiskMitigations'] = "{{ route('admin.risk_management.ajax.reset_risk_mitigations') }}";
        URLs['resetRiskReviews'] = "{{ route('admin.risk_management.ajax.reset_risk_reviews') }}";


        const dataFormat = "{{ get_default_date_format() }}";


        Highcharts.setOptions({
            global: {
                timezone: "{{ get_setting('default_timezone') }}"
            }
        });
        assets['showLoading'] = "{{ asset('SR_images/progress.gif') }}";
    </script>
    <script src="{{ asset('ajax-files/risk_management/edit.js') }}"></script>
    <script>
        (function () {
            function actOnAcceptanceFlow(decision, stepId) {
                if (!stepId) return;
                $.ajax({
                    url: URLs['acceptance_flow_act'],
                    type: 'POST',
                    data: {
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        step_id: stepId,
                        decision: decision,
                        comments: $('#acceptanceFlowComments').val() || null,
                    },
                    success: function (res) {
                        if (res.status) {
                            makeAlert('success', res.message, lang['success'] || 'Success');
                            if (res.reload) {
                                window.location.reload();
                            }
                        } else {
                            makeAlert('error', res.message || lang['error'], lang['error'] || 'Error');
                        }
                    },
                    error: function (xhr) {
                        const msg = (xhr.responseJSON && xhr.responseJSON.message) || lang['error'] || 'Error';
                        makeAlert('error', msg, lang['error'] || 'Error');
                    }
                });
            }

            $(document).on('click', '#approveAcceptanceBtn', function () {
                actOnAcceptanceFlow('approved', $(this).data('step-id'));
            });

            $(document).on('click', '#rejectAcceptanceBtn', function () {
                if (typeof Swal !== 'undefined') {
                    Swal.fire({
                        title: '{{ __("risk.RejectAcceptance") }}',
                        text: lang['revert'] || '',
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonText: '{{ __("risk.RejectAcceptance") }}',
                        cancelButtonText: '{{ __("locale.Cancel") }}',
                    }).then(function (result) {
                        if (result.isConfirmed) {
                            actOnAcceptanceFlow('rejected', $('#rejectAcceptanceBtn').data('step-id'));
                        }
                    });
                } else if (confirm('{{ __("risk.RejectAcceptance") }}')) {
                    actOnAcceptanceFlow('rejected', $('#rejectAcceptanceBtn').data('step-id'));
                }
            });

            $(document).on('click', '.start-acceptance-cycle-btn', function () {
                const riskId = $(this).data('risk-id');
                const $btn = $(this);
                $btn.prop('disabled', true);
                $.ajax({
                    url: URLs['acceptance_flow_start'],
                    type: 'POST',
                    data: {
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        risk_id: riskId,
                    },
                    success: function (res) {
                        if (res.status) {
                            makeAlert('success', res.message, lang['success'] || 'Success');
                            if (res.reload) {
                                window.location.reload();
                            }
                        } else {
                            $btn.prop('disabled', false);
                            makeAlert('error', res.message || lang['error'], lang['error'] || 'Error');
                        }
                    },
                    error: function (xhr) {
                        $btn.prop('disabled', false);
                        const msg = (xhr.responseJSON && xhr.responseJSON.message) || lang['error'] || 'Error';
                        makeAlert('error', msg, lang['error'] || 'Error');
                    }
                });
            });
        })();
    </script>
    <script>
        document.querySelectorAll('.accordion-button').forEach(button => {
            button.addEventListener('click', function() {
                const icon = this.querySelector('i');
                if (this.classList.contains('collapsed')) {
                    icon.style.transform = "rotate(180deg)";
                } else {
                    icon.style.transform = "rotate(0deg)";
                }
            });
        });
        document.addEventListener('DOMContentLoaded', function() {
            const collapseOne = document.getElementById('collapseOne');
            const chevronIcon = document.getElementById('chevronIcon');

            collapseOne.addEventListener('show.bs.collapse', function() {
                // Rotate the icon down when the accordion is expanded
                chevronIcon.style.transform = 'rotate(0deg)';
            });

            collapseOne.addEventListener('hide.bs.collapse', function() {
                // Rotate the icon up when the accordion is collapsed
                chevronIcon.style.transform = 'rotate(180deg)';
            });
        });
        $(document).on('input', 'input[name="mitigation_percent"]', function() {
            const value = parseInt($(this).val(), 10);
            if (value > 100) {
                $(this).val(100); // Restrict the value to 100
                $('.error-mitigation_percent').text('Percentage cannot exceed 100.');
            } else {
                $('.error-mitigation_percent').text(''); // Clear error message
            }
        });

        $(document).ready(function() {
            // Trigger the alert for the active tab when the page loads
            var activeTab = $('#pills-tab .active').attr('id'); // Get the ID of the active tab

            // Hide all options by default
            $('#risk-actions option').hide();
            $('#risk-actions .step-default-option').prop('selected', true);

            // Display options based on the active tab
            if (activeTab === "pills-home-tab") { // Show options for Risk Identification
                $('#risk-actions .step-1-option').show();
            }
            if (activeTab === "pills-analysis-tab") {
                $('#risk-actions .step-2-option').show(); // Risk analysis options
            }
            if (activeTab === "pills-evalution-tab") {
                // Show options for Risk Evaluation
                $('#risk-actions .step-3-option').show(); // Reset Mitigations option
            }
            if (activeTab === "pills-review-tab") {
                // Show options for Risk Review
                $('#risk-actions .step-4-option').show(); // Review options
            }

            // Handle tab switching
            $('#pills-tab button').on('shown.bs.tab', function(e) {
                var activeTab = $(e.target).attr('id'); // Get the ID of the active tab
                $('#risk-actions .step-default-option').prop('selected', true);

                // Hide all options by default
                $('#risk-actions option').hide();

                // Display options based on the active tab
                if (activeTab === "pills-home-tab") { // Show options for Risk Identification
                    $('#risk-actions .step-1-option').show();
                }
                if (activeTab === "pills-analysis-tab") {
                    $('#risk-actions .step-2-option').show(); // Risk analysis options
                }
                if (activeTab === "pills-evalution-tab") {
                    // Show options for Risk Evaluation
                    $('#risk-actions .step-3-option').show(); // Reset Mitigations option
                }
                if (activeTab === "pills-review-tab") {
                    // Show options for Risk Review
                    $('#risk-actions .step-4-option').show(); // Review options
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {

            // ================= OWNER =================

            function setManagerFromOwner(ownerOption) {
                const manager = ownerOption.data('manager');
                const department = ownerOption.data('department');

                // Owner department (correct)
                $('#departmentOwner').val(department || '');

                // Reset manager select
                $('#managerSelect')
                    .empty()
                    .append(`<option value="">{{ __('locale.select-option') }}</option>`);

                if (manager) {
                    let managerText = manager.name;

                    if (manager.department && manager.department.name) {
                        managerText += ` -- ${manager.department.name}`;
                    }

                    $('#managerSelect')
                        .append(`<option value="${manager.id}" selected>${managerText}</option>`)
                        .trigger('change');
                }
            }

            // change event
            $('#ownerSelect').on('change select2:select', function() {
                setManagerFromOwner($(this).find(':selected'));
            });

            // edit mode
            const initialOwner = $('#ownerSelect').find(':selected');
            if (initialOwner.val()) {
                setManagerFromOwner(initialOwner);
            }


            // ================= MITIGATION =================

            function setMitigationManagerFromOwner(ownerOption) {
                const manager = ownerOption.data('manager');
                const department = ownerOption.data('department');

                // Owner department (correct)
                $('#departmentMitigationOwner').val(department || '');

                // Reset mitigation manager select
                $('#mitigationManagerSelect')
                    .empty()
                    .append(`<option value="">{{ __('locale.select-option') }}</option>`);

                if (manager) {
                    let managerText = manager.name;

                    if (manager.department && manager.department.name) {
                        managerText += ` -- ${manager.department.name}`;
                    }

                    $('#mitigationManagerSelect')
                        .append(`<option value="${manager.id}" selected>${managerText}</option>`)
                        .trigger('change');
                }
            }

            // change event
            $('#mitigationOwnerSelect').on('change select2:select', function() {
                setMitigationManagerFromOwner($(this).find(':selected'));
            });

            // edit mode
            const initialMitigationOwner = $('#mitigationOwnerSelect').find(':selected');
            if (initialMitigationOwner.val()) {
                setMitigationManagerFromOwner(initialMitigationOwner);
            }
        });
    </script>

    {{-- ============================================================
         Planning Strategy — Show / Hide Fields
    ============================================================ --}}
    <script>
        (function() {

            // ----------------------------------------------------------------
            // Visibility matrix — numeric string keys '1'..'4'
            // ----------------------------------------------------------------
            var strategyConfig = {
                '': {
                    show: ['risk_treatment_plan', 'security_recommendations', 'supporting_documentation'],
                    hide: ['deadline_date','mitigation_effort',
                        'mitigation_cost', 'mitigation_owner', 'mitigation_team',
                        'mitigation_percent', 'mitigation_controls',
                        'accepting_reason'
                    ]
                },
                '1': { // Accepting
                    show: ['deadline_date', 'mitigation_cost', 'accepting_reason',
                        'risk_treatment_plan', 'security_recommendations',
                        'supporting_documentation'
                    ],
                    hide: ['mitigation_effort', 'mitigation_owner',
                        'mitigation_team', 'mitigation_percent', 'mitigation_controls'                    ]
                },
                '2': { // Mitigating — all fields visible
                    show: ['deadline_date', 'mitigation_effort',
                        'mitigation_cost', 'mitigation_owner', 'mitigation_team',
                        'mitigation_percent', 'mitigation_controls', 'risk_treatment_plan',
                        'security_recommendations',
                        'supporting_documentation'
                    ],
                    hide: ['accepting_reason']
                },
                '3': { // Sharing
                    show: ['deadline_date', 'mitigation_cost',
                        'mitigation_owner', 'mitigation_team', 'risk_treatment_plan',
                         'security_recommendations',
                        'supporting_documentation'
                    ],
                    hide: ['mitigation_effort', 'mitigation_percent', 'mitigation_controls',
                        'accepting_reason'
                    ]
                },
                '4': { // Avoiding
                    show: ['deadline_date', 'mitigation_owner', 'risk_treatment_plan',
                        'security_recommendations', 'supporting_documentation'
                    ],
                    hide: [ 'mitigation_effort', 'mitigation_cost',
                        'mitigation_team', 'mitigation_percent', 'mitigation_controls',
                        'accepting_reason'
                    ]
                }
            };

            // ----------------------------------------------------------------
            // Clear DOM values when a field wrapper is hidden
            // (keeps UI clean + ensures FormData picks up empty values)
            // ----------------------------------------------------------------
            function clearFieldValues(fieldWrapper) {
                // Plain text / number inputs
                fieldWrapper.querySelectorAll('input:not([type="hidden"]):not([type="file"])').forEach(function(el) {
                    el.value = '';
                });
                // Textareas
                fieldWrapper.querySelectorAll('textarea').forEach(function(el) {
                    el.value = '';
                });
                // Single selects
                fieldWrapper.querySelectorAll('select:not([multiple])').forEach(function(sel) {
                    sel.value = '';
                    if (typeof $ !== 'undefined' && $(sel).data('select2')) {
                        $(sel).val('').trigger('change.select2');
                    }
                });
                // Multi selects
                fieldWrapper.querySelectorAll('select[multiple]').forEach(function(sel) {
                    Array.from(sel.options).forEach(function(opt) {
                        opt.selected = false;
                    });
                    if (typeof $ !== 'undefined' && $(sel).data('select2')) {
                        $(sel).val([]).trigger('change.select2');
                    }
                });
            }

            // ----------------------------------------------------------------
            // Apply show/hide — instant hide, staggered fade-in for show
            // ----------------------------------------------------------------
            function applyStrategy(strategyId, animate) {
                var key = String(strategyId).trim();
                var config = strategyConfig[key] || strategyConfig[''];
                var doAnimate = (animate === true);

                // HIDE immediately + clear
                config.hide.forEach(function(field) {
                    var el = document.querySelector('#editMitigationModal [data-field="' + field + '"]');
                    if (!el || field === 'planning_strategy') return;
                    clearFieldValues(el);
                    if (doAnimate) {
                        el.style.transition = 'opacity 0.15s ease';
                        el.style.opacity = '0';
                        setTimeout(function() {
                            el.style.display = 'none';
                            el.style.opacity = el.style.transition = '';
                        }, 150);
                    } else {
                        el.style.display = 'none';
                        el.style.opacity = el.style.transition = '';
                    }
                });

                // SHOW with stagger
                config.show.forEach(function(field, i) {
                    var el = document.querySelector('#editMitigationModal [data-field="' + field + '"]');
                    if (!el || field === 'planning_strategy') return;
                    if (doAnimate) {
                        var delay = i * 25;
                        el.style.display = '';
                        el.style.opacity = '0';
                        el.style.transform = 'translateY(-3px)';
                        el.style.transition = 'opacity 0.18s ease ' + delay + 'ms, transform 0.18s ease ' +
                            delay + 'ms';
                        setTimeout(function() {
                            el.style.opacity = '1';
                            el.style.transform = 'translateY(0)';
                        }, 20);
                        setTimeout(function() {
                            el.style.transition = el.style.transform = '';
                        }, 20 + delay + 200);
                    } else {
                        el.style.display = '';
                        el.style.opacity = el.style.transition = el.style.transform = '';
                    }
                });
            }

            // ----------------------------------------------------------------
            // Wire up the select
            // ----------------------------------------------------------------
            function initStrategyListener() {
                var select = document.getElementById('planning_strategy_select');
                if (!select) return;
                // No animation on first load — no flicker
                applyStrategy(select.value, false);
                select.addEventListener('change', function() {
                    applyStrategy(this.value, true);
                });
                if (typeof $ !== 'undefined') {
                    $(select).off('change.strategy').on('change.strategy', function() {
                        applyStrategy(this.value, true);
                    });
                }
            }

            var modalEl = document.getElementById('editMitigationModal');
            if (modalEl) {
                modalEl.addEventListener('shown.bs.modal', function() {
                    initStrategyListener();
                });
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', initStrategyListener);
            } else {
                initStrategyListener();
            }

        })();
    </script>
    <!-- end accordion -->
@endsection
