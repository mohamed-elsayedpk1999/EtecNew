<div class="risk-stats-section">
    <div class="risk-stats-header">
        <h5>{{ __('risk.MyRiskStatistics') }} — {{ $riskInfo['user_name'] ?? auth()->user()->name }}</h5>
        <span class="risk-stats-badge">
            {{ ($riskInfo['scoped_to_user'] ?? true) ? __('risk.ScopedToYourRisks') : __('risk.AllRisksVisible') }}
        </span>
    </div>

    <div class="row g-3 mb-3">
        <div class="col-12 col-md-6 col-lg-3">
            <div class="card risk-stat-card risk-stat-overview">
                <div class="card-body">
                    @if (auth()->user()->hasPermission('riskmanagement.Risks and Assets') ||
                            auth()->user()->hasPermission('riskmanagement.Risks and Controls'))
                        <a class="pe-1 dropdown-toggle hide-arrow text-muted" data-bs-toggle="dropdown"
                            aria-expanded="false" style="position: absolute; top: 10px; right: 10px;">
                            <i data-feather="more-vertical" class="font-small-4"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            @if (auth()->user()->hasPermission('riskmanagement.Risks and Assets'))
                                <li>
                                    <button class="dropdown-item open-modal" data-id="RiskByAsset"
                                        onclick="navigateToRiskByAssetReport()">
                                        {{ __('locale.risk_by_asset') }}
                                    </button>
                                </li>
                            @endif
                            @if (auth()->user()->hasPermission('riskmanagement.Risks and Controls'))
                                <li>
                                    <button class="dropdown-item open-modal" data-id="RiskByControl"
                                        onclick="navigateToRiskByControlReport(0)">
                                        {{ __('locale.risk_by_control') }}
                                    </button>
                                </li>
                            @endif
                        </ul>
                    @endif
                    <div class="stat-row">
                        <div class="stat-icon"><i data-feather="layers"></i></div>
                        <div>
                            <div class="stat-value">{{ $riskInfo['overview'] ?? 0 }}</div>
                            <div class="stat-label">{{ __('locale.overview_risks') }}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3">
            <div class="card risk-stat-card risk-stat-closed">
                <div class="card-body">
                    <div class="stat-row">
                        <div class="stat-icon"><i data-feather="check-circle"></i></div>
                        <div>
                            <div class="stat-value">{{ $riskInfo['closedRisk']['count'] ?? 0 }}</div>
                            <div class="stat-label">{{ __('locale.closed_risks') }}</div>
                        </div>
                    </div>
                    <span class="stat-percent">{{ $riskInfo['closedRisk']['percentage'] ?? 0 }}%</span>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3">
            <div class="card risk-stat-card risk-stat-open">
                <div class="card-body">
                    <div class="stat-row">
                        <div class="stat-icon"><i data-feather="alert-circle"></i></div>
                        <div>
                            <div class="stat-value">{{ $riskInfo['openRisk']['count'] ?? 0 }}</div>
                            <div class="stat-label">{{ __('locale.open_risks') }}</div>
                        </div>
                    </div>
                    <span class="stat-percent">{{ $riskInfo['openRisk']['percentage'] ?? 0 }}%</span>
                </div>
            </div>
        </div>

        <div class="col-12 col-md-6 col-lg-3">
            <div class="card risk-stat-card risk-stat-mitigated">
                <div class="card-body">
                    <div class="stat-row">
                        <div class="stat-icon"><i data-feather="shield"></i></div>
                        <div>
                            <div class="stat-value">{{ $riskInfo['MitigatedRisk']['count'] ?? 0 }}</div>
                            <div class="stat-label">{{ __('locale.mitigated_risks') }}</div>
                        </div>
                    </div>
                    <span class="stat-percent">{{ $riskInfo['MitigatedRisk']['percentage'] ?? 0 }}%</span>
                </div>
            </div>
        </div>
    </div>

    <div class="risk-stats-header mt-2">
        <h5>{{ __('risk.YourRiskInvolvement') }}</h5>
    </div>

    @php
        $involvementStyles = [
            'as_owner' => ['icon' => 'user', 'color' => '#4f5bd5', 'bg' => '#eef2ff'],
            'as_stakeholder' => ['icon' => 'users', 'color' => '#0d8ea8', 'bg' => '#e8f7fa'],
            'as_mitigation_owner' => ['icon' => 'shield', 'color' => '#2e9b57', 'bg' => '#e8f7ee'],
            'as_team' => ['icon' => 'briefcase', 'color' => '#c07a14', 'bg' => '#fdf4e8'],
            'as_submitter' => ['icon' => 'send', 'color' => '#6b5bc6', 'bg' => '#f1effb'],
        ];
    @endphp

    <div class="row g-3">
        @foreach ($riskInfo['involvement'] ?? [] as $key => $item)
            @php $style = $involvementStyles[$key] ?? ['icon' => 'activity', 'color' => '#6e7b91', 'bg' => '#f4f6f8']; @endphp
            <div class="col-12 col-md-6 col-lg-4 col-xl">
                <div class="card risk-involvement-card h-100">
                    <div class="card-body">
                        <div class="involvement-icon" style="background: {{ $style['bg'] }}; color: {{ $style['color'] }};">
                            <i data-feather="{{ $style['icon'] }}"></i>
                        </div>
                        <div class="involvement-value">{{ $item['count'] ?? 0 }}</div>
                        <div class="involvement-label">{{ $item['label'] ?? '' }}</div>
                        <div class="involvement-bar">
                            <span style="width: {{ min(100, $item['percentage'] ?? 0) }}%; background: {{ $style['color'] }};"></span>
                        </div>
                        <span class="involvement-percent">{{ $item['percentage'] ?? 0 }}%</span>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
