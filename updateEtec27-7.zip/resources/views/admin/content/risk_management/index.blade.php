@extends('admin/layouts/contentLayoutMaster')

@section('title', __('risk.Submit Risk'))

@section('vendor-style')
    <link rel="stylesheet" href="{{ asset('fonts/fontawesome-6.2.1/css/all.min.css') }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/toastr.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/dataTables.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/responsive.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/pickers/flatpickr/flatpickr.min.css')) }}">

    <link rel="stylesheet" href="{{ asset(mix('vendors/css/tables/datatable/buttons.bootstrap5.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/forms/select/select2.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/animate/animate.min.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('vendors/css/extensions/sweetalert2.min.css')) }}">
@endsection
<style>
    #risk_addational_notes_submit {
        height: 93px;

    }

    .ql-spanblock:after {
        content: "<sb/>";
    }

    .spanblock {
        background-color: #f2f2f2;
        border: 1px solid #CCC;
        line-height: 19px;
        padding: 6px 10px;
        border-radius: 3px;
        margin: 15px 0;
    }

    .tab {
        display: none;
    }

    .tab:first-of-type {
        display: block;
        /* Show the first step by default */
    }

    .basic-wizard .stepper-horizontal {
        overflow: auto !important;
    }

    .wizard-fields {
        padding: 10px;
    }

    .risk-stats-section {
        margin-bottom: 1.5rem;
        padding: 0 0.25rem;
    }

    .risk-stats-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 0.75rem;
        margin-bottom: 1rem;
    }

    .risk-stats-header h5 {
        margin: 0;
        font-weight: 600;
        color: #3b3f5c;
    }

    .risk-stats-badge {
        font-size: 0.78rem;
        padding: 0.35rem 0.85rem;
        border-radius: 6px;
        background: #f4f6f8;
        color: #5a6a85;
        font-weight: 500;
        border: 1px solid #e8ecf1;
    }

    .risk-stat-card {
        border: 1px solid #eef1f5;
        border-radius: 12px;
        background: #fff;
        box-shadow: 0 2px 8px rgba(58, 70, 93, 0.06);
        transition: box-shadow 0.2s ease, border-color 0.2s ease;
        height: 100%;
        margin-bottom: 0;
    }

    .risk-stat-card:hover {
        box-shadow: 0 4px 14px rgba(58, 70, 93, 0.1);
        border-color: #dfe5ec;
    }

    .risk-stat-card .card-body {
        padding: 1.25rem 1.35rem;
        position: relative;
    }

    .risk-stat-card .stat-row {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .risk-stat-card .stat-icon {
        width: 52px;
        height: 52px;
        min-width: 52px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
    }

    .risk-stat-card .stat-value {
        font-size: 1.75rem;
        font-weight: 700;
        line-height: 1.1;
        color: #2f3349;
        margin-bottom: 0.15rem;
    }

    .risk-stat-card .stat-label {
        font-size: 0.875rem;
        color: #6e7b91;
        margin-bottom: 0;
    }

    .risk-stat-card .stat-percent {
        font-size: 0.78rem;
        font-weight: 600;
        display: inline-block;
        margin-top: 0.65rem;
        padding: 0.2rem 0.55rem;
        border-radius: 6px;
    }

    .risk-stat-overview .stat-icon {
        background: #eef2ff;
        color: #4f5bd5;
    }

    .risk-stat-overview .stat-percent {
        background: #eef2ff;
        color: #4f5bd5;
    }

    .risk-stat-closed .stat-icon {
        background: #e8f7ee;
        color: #2e9b57;
    }

    .risk-stat-closed .stat-percent {
        background: #e8f7ee;
        color: #2e9b57;
    }

    .risk-stat-open .stat-icon {
        background: #fff0f0;
        color: #d64545;
    }

    .risk-stat-open .stat-percent {
        background: #fff0f0;
        color: #d64545;
    }

    .risk-stat-mitigated .stat-icon {
        background: #edf5ff;
        color: #3b82c4;
    }

    .risk-stat-mitigated .stat-percent {
        background: #edf5ff;
        color: #3b82c4;
    }

    .risk-involvement-card {
        border: 1px solid #eef1f5;
        border-radius: 12px;
        background: #fff;
        box-shadow: 0 2px 8px rgba(58, 70, 93, 0.05);
        height: 100%;
        transition: box-shadow 0.2s ease, border-color 0.2s ease;
    }

    .risk-involvement-card:hover {
        box-shadow: 0 4px 14px rgba(58, 70, 93, 0.09);
        border-color: #dfe5ec;
    }

    .risk-involvement-card .card-body {
        padding: 1.1rem 1.2rem;
    }

    .risk-involvement-card .involvement-icon {
        width: 42px;
        height: 42px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 0.85rem;
        font-size: 1rem;
    }

    .risk-involvement-card .involvement-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #2f3349;
        margin-bottom: 0.15rem;
    }

    .risk-involvement-card .involvement-label {
        font-size: 0.84rem;
        color: #6e7b91;
        margin-bottom: 0.5rem;
        min-height: 2.4em;
    }

    .risk-involvement-card .involvement-bar {
        height: 5px;
        border-radius: 999px;
        background: #edf1f5;
        overflow: hidden;
    }

    .risk-involvement-card .involvement-bar span {
        display: block;
        height: 100%;
        border-radius: 999px;
    }

    .risk-involvement-card .involvement-percent {
        font-size: 0.78rem;
        color: #8a96a8;
        margin-top: 0.35rem;
        display: inline-block;
    }
</style>

@section('page-style')
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-toastr.css')) }}">
    <link rel="stylesheet" href="{{ asset(mix('css/base/plugins/extensions/ext-component-sweet-alerts.css')) }}">
@endsection

@section('content')
    <div class="content-header row">
        <div class="content-header-left col-12 mb-2">

            <div class="row breadcrumbs-top  widget-grid">
                <div class="col-12">
                    <div class="page-title mt-2">
                        <div class="row">
                            <div class="col-md-6 ps-0">
                                @if (@isset($breadcrumbs))
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="{{ route('admin.dashboard') }}"
                                                style="display: flex;">
                                                <svg class="stroke-icon">
                                                    <use href="{{ asset('fonts/icons/icon-sprite.svg#stroke-home') }}">
                                                    </use>
                                                </svg></a></li>
                                        @foreach ($breadcrumbs as $breadcrumb)
                                            <li class="breadcrumb-item">
                                                @if (isset($breadcrumb['link']))
                                                    <a
                                                        href="{{ $breadcrumb['link'] == 'javascript:void(0)' ? $breadcrumb['link'] : url($breadcrumb['link']) }}">
                                                @endif
                                                {{ $breadcrumb['name'] }}
                                                @if (isset($breadcrumb['link']))
                                                    </a>
                                                @endif
                                            </li>
                                        @endforeach
                                    </ol>
                                @endisset
                        </div>
                        <div class="col-md-6 pe-0" style="text-align: end;">

                            <div class="action-content">

                                @if (auth()->user()->hasPermission('riskmanagement.create'))
                                    <button class=" btn btn-primary " type="button" data-bs-toggle="modal"
                                        data-bs-target="#add-new-risk">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                    <a href="{{ route('admin.risk_management.notificationsSettingsRisk') }}"
                                        class=" btn btn-primary " target="_self">
                                        <i class="fa fa-regular fa-bell"></i>
                                    </a>
                                @endif
                                @if (auth()->user()->hasPermission('riskmanagement.configuration') ||
                                        auth()->user()->hasPermission('classic_risk_formula.list'))
                                    <div class="btn-group dropdown dropdown-icon-wrapper ">
                                        <button type="button"
                                            class="btn btn-primary dropdown-toggle dropdown-toggle-split"
                                            data-bs-toggle="dropdown" aria-expanded="false"
                                            style="border-radius: 8px !important;
                                        width: 40px;
                                        text-align: center;
                                        color: #FFF !important;
                                        height: 28px;
                                        line-height: 19px;">
                                            <i class="fa fa-solid fa-gear"></i>
                                        </button>
                                        <div class="dropdown-menu dropdown-menu-end export-types">
                                            @if (auth()->user()->hasPermission('classic_risk_formula.list'))
                                                <span class="dropdown-item" data-type="excel">
                                                    <i class="fa fa-solid fa-gear"></i>
                                                    <span class="px-1 text-start">
                                                        <a href="{{ route('admin.configure.riskmodels.show') }}">
                                                            {{ __('locale.ClassicRiskFormula') }}
                                                        </a>
                                                    </span>
                                                </span>
                                            @endif
                                            @if (auth()->user()->hasPermission('riskmanagement.configuration'))
                                                <span class="dropdown-item" data-type="excel">
                                                    <i class="fa fa-solid fa-gear"></i>
                                                    <span class="px-1 text-start">
                                                        <a
                                                            href="{{ route('admin.risk_management.configuretion') }}">{{ __('locale.configuretion') }}</a>
                                                    </span>
                                                </span>
                                                <span class="dropdown-item" role="button" data-bs-toggle="modal"
                                                    data-bs-target="#riskAcceptanceFlowModal"
                                                    id="openAcceptanceFlowConfigBtn">
                                                    <i class="fa fa-project-diagram"></i>
                                                    <span class="px-1 text-start">
                                                        {{ __('risk.AcceptanceFlowConfig') }}
                                                    </span>
                                                </span>
                                            @endif
                                        </div>

                                    </div>
                                @endif
                                <x-export-import name="{{ __('risk.Risk') }}"
                                    createPermissionKey='vulnerability_management.create'
                                    exportPermissionKey='riskmanagement.export'
                                    exportRouteKey='admin.risk_management.ajax.export'
                                    importRouteKey='admin.risk_management.import' />

                                @if (auth()->user()->hasPermission('riskmanagement.Risk Dashboard'))
                                    <a class="btn btn-primary"
                                        href="{{ route('admin.risk_management.ajax.statistics.risk') }}"> <i
                                            class="fa-solid fa-file-invoice"></i></a>
                                @endif
                                @if (auth()->user()->hasPermission('riskmanagement.export'))

                                    <a title="export pdf" href="#" id="exportAsPdfButton"
                                        class="dt-button btn btn-primary " onclick="exportAsPdf()">
                                        <i class="fas fa-file-pdf"></i> <!-- Replace with your desired icon class -->
                                    </a>
                                @endif

                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="quill-service-content" class="d-none"></div>

</div>

<div class="card">
    <div class="card-header mb-3">
        <div class="head-label">
            <h4 class="card-title">{{ __('locale.Risk Management') }}
        </div>
    </div>


    @include('admin.content.risk_management._risk_stats_section')




</div>

{{-- Risk Acceptance Flow Config Modal --}}
@if (auth()->user()->hasPermission('riskmanagement.configuration'))
    <div class="modal fade" id="riskAcceptanceFlowModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">{{ __('risk.AcceptanceFlowConfigTitle') }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-muted mb-3">{{ __('risk.AcceptanceWorkflow') }}</p>
                    <div id="acceptanceFlowStepsContainer" class="d-flex flex-column gap-3"></div>
                    <div class="alert alert-warning mt-3 d-none" id="acceptanceFlowConfigWarning">
                        {{ __('risk.FlowNotConfigured') }}
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('locale.Close') }}</button>
                    <button type="button" class="btn btn-primary" id="saveAcceptanceFlowConfigBtn">
                        {{ __('risk.SaveFlowConfig') }}
                    </button>
                </div>
            </div>
        </div>
    </div>
@endif

<style>
    .acceptance-flow-step-card {
        border: 1px solid #e8edf5;
        border-radius: 12px;
        padding: 1rem 1.1rem;
        background: #fff;
        position: relative;
    }
    .acceptance-flow-step-card .step-badge {
        width: 34px;
        height: 34px;
        border-radius: 50%;
        background: #eef2ff;
        color: #4f5bd5;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        margin-inline-end: 0.75rem;
    }
    .acceptance-flow-arrow {
        text-align: center;
        color: #94a3b8;
        font-size: 1.2rem;
        line-height: 1;
    }
</style>

<!-- Advanced Search -->
<x-submit-risk-search id="advanced-search-datatable" createModalID="add-new-risk" :statuses="$statuses" />
<!--/ Advanced Search -->

<!-- Create Form -->
@if (auth()->user()->hasPermission('riskmanagement.create'))
    <x-submit-risk-form id="add-new-risk" title="{{ __('risk.AddANewRisk') }}" :riskGroupings="$riskGroupings" :threatGroupings="$threatGroupings"
        :locations="$locations" :frameworks="$frameworks" :assets="$assets" :assetGroups="$assetGroups" :categories="$categories" :technologies="$technologies"
        :teams="$teams" :enabledUsers="$enabledUsers" :riskSources="$riskSources" :riskScoringMethods="$riskScoringMethods" :riskLikelihoods="$riskLikelihoods" :impacts="$impacts"
        :tags="$tags" :owners="$owners" :reviewers="$reviewers" :projects="$projects" :mitigationEfforts="$mitigationEfforts"
        :mitigationCosts="$mitigationCosts" :planningStrategies="$planningStrategies" :reviews="$reviews" :nextSteps="$nextSteps" :riskConfigSources="$riskConfigSources" />
@endif



<!--/ Create Form -->

<!-- Update Form -->
{{-- <x-submit-risk-form id="edit-risk" title="{{ __('locale.EditRisk') }}" :riskGroupings = "$riskGroupings" :threatGroupings = "$threatGroupings" :locations = "$locations" :frameworks = "$frameworks" :categories = "$categories" :technologies = "$technologies" :teams = "$teams" :enabledUsers = "$enabledUsers" :riskSources = "$riskSources" :riskScoringMethods = "$riskScoringMethods" :riskLikelihoods = "$riskLikelihoods" :impacts = "$impacts" :tags = "$tags" /> --}}
<!--/ Update Form -->

@endsection

@section('vendor-script')
<script src="{{ asset(mix('vendors/js/tables/datatable/jquery.dataTables.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.bootstrap5.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/dataTables.responsive.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/responsive.bootstrap5.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/buttons.print.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/tables/datatable/datatables.buttons.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/forms/select/select2.full.min.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/sweetalert2.all.min.js')) }}"></script>
@endsection

@section('page-script')
<script src="{{ asset(mix('js/scripts/forms/form-select2.js')) }}"></script>
<script src="{{ asset(mix('vendors/js/extensions/toastr.min.js')) }}"></script>
<script src="{{ asset('cdn/ckeditor.js') }}"></script>
<script src="{{ asset(mix('vendors/js/pickers/flatpickr/flatpickr.min.js')) }}"></script>

{{-- Add Verification translation --}}
<script>
    let URLs = [],
        lang = [];
    lang['confirmDelete'] = "{{ __('locale.ConfirmDelete') }}";
    lang['cancel'] = "{{ __('locale.Cancel') }}";
    lang['View'] = "{{ __('locale.View') }}";
    lang['Delete'] = "{{ __('locale.Delete') }}";
    lang['success'] = "{{ __('locale.Success') }}";
    lang['error'] = "{{ __('locale.Error') }}";
    lang['confirmDeleteMessage'] = "{{ __('locale.AreYouSureToDeleteThisRecord') }}";
    lang['revert'] = "{{ __('locale.YouWontBeAbleToRevertThis') }}";
    lang['DetailsOfItem'] = "{{ __('locale.DetailsOfItem', ['item' => __('locale.risk')]) }}";
    permission = [];
    permission['show'] = {{ auth()->user()->hasPermission('riskmanagement.list') ? 1 : 0 }};
    permission['delete'] = {{ auth()->user()->hasPermission('riskmanagement.delete') ? 1 : 0 }};
    URLs['ajax_list'] = "{{ route('admin.risk_management.ajax.index') }}";
    URLs['show'] = "{{ route('admin.risk_management.show', ':id') }}";
    URLs['create'] = "{{ route('admin.risk_management.ajax.store') }}";
    URLs['delete'] = "{{ route('admin.risk_management.ajax.destroy', ':id') }}";
    URLs['acceptance_flow_get'] = "{{ route('admin.risk_management.ajax.acceptance_flow_config.get') }}";
    URLs['acceptance_flow_save'] = "{{ route('admin.risk_management.ajax.acceptance_flow_config.save') }}";
</script>
<script src="{{ asset('ajax-files/risk_management/index.js') }}"></script>
<script>
    (function () {
        function escapeHtml(text) {
            return $('<div>').text(text || '').html();
        }

        function buildUserOptions(users, selectedUserId, departmentId) {
            let userOptions = `<option value="">{{ __('risk.SelectApprover') }}</option>`;
            users.forEach(function (user) {
                if (departmentId && user.department_id && String(user.department_id) !== String(departmentId)) {
                    // Prefer same-department users first by skipping others in filtered list;
                    // keep all users available if no department filter match needed.
                }
                const selected = String(selectedUserId || '') === String(user.id) ? 'selected' : '';
                const deptMark = departmentId && String(user.department_id) === String(departmentId) ? ' ★' : '';
                userOptions += `<option value="${user.id}" ${selected} data-department-id="${user.department_id || ''}">${escapeHtml(user.name)}${deptMark}</option>`;
            });
            return userOptions;
        }

        function renderAcceptanceFlowSteps(steps, users, departments) {
            const container = $('#acceptanceFlowStepsContainer');
            container.empty();

            steps.forEach(function (step, index) {
                let departmentOptions = `<option value="">{{ __('risk.SelectDepartment') }}</option>`;
                departments.forEach(function (dept) {
                    const selected = String(step.department_id || '') === String(dept.id) ? 'selected' : '';
                    departmentOptions += `<option value="${dept.id}" data-manager-id="${dept.manager_id || ''}" ${selected}>${escapeHtml(dept.name)}</option>`;
                });

                const selectedDept = departments.find(function (d) {
                    return String(d.id) === String(step.department_id || '');
                });
                const label = selectedDept
                    ? selectedDept.name
                    : (step.label || step.label_ar || step.label_en || ('Step ' + step.step_order));

                const useOwnerChecked = step.use_risk_owner ? 'checked' : '';

                if (index > 0) {
                    container.append('<div class="acceptance-flow-arrow"><i class="fa fa-arrow-down"></i></div>');
                }

                container.append(`
                    <div class="acceptance-flow-step-card" data-step-order="${step.step_order}">
                        <div class="d-flex align-items-center mb-2">
                            <span class="step-badge">${step.step_order}</span>
                            <div>
                                <strong class="flow-step-label-text">${escapeHtml(label)}</strong>
                                <div class="text-muted small">{{ __('risk.DepartmentLabelHint') }}</div>
                            </div>
                        </div>
                        <input type="hidden" class="flow-step-key" value="${step.step_key}">
                        <div class="mb-2">
                            <label class="form-label mb-1">{{ __('risk.SelectDepartment') }}</label>
                            <select class="form-select flow-department-select select2">
                                ${departmentOptions}
                            </select>
                        </div>
                        <div class="form-check mb-2 ${step.step_key === 'risk_owner' ? '' : 'd-none'}">
                            <input class="form-check-input flow-use-owner" type="checkbox" ${useOwnerChecked}
                                id="flowUseOwner${step.step_order}">
                            <label class="form-check-label" for="flowUseOwner${step.step_order}">
                                {{ __('risk.UseRiskOwner') }}
                            </label>
                        </div>
                        <div class="mb-0 flow-manager-box ${step.use_risk_owner ? 'd-none' : ''}">
                            <label class="form-label mb-1">{{ __('risk.DepartmentManager') }}</label>
                            <input type="text" class="form-control flow-manager-name" readonly
                                value="${escapeHtml((selectedDept && selectedDept.manager_name) ? selectedDept.manager_name : '')}"
                                placeholder="{{ __('risk.ApproverFromDepartment') }}">
                            <input type="hidden" class="flow-user-select-value"
                                value="${step.use_risk_owner ? '' : (step.user_id || (selectedDept && selectedDept.manager_id) || '')}">
                            <div class="text-muted small mt-1">{{ __('risk.ApproverFromDepartment') }}</div>
                        </div>
                    </div>
                `);
            });

            if ($.fn.select2) {
                container.find('.select2').select2({
                    dropdownParent: $('#riskAcceptanceFlowModal'),
                    width: '100%'
                });
            }
        }

        $('#riskAcceptanceFlowModal').on('show.bs.modal', function () {
            $.get(URLs['acceptance_flow_get'], function (res) {
                if (!res.status) {
                    makeAlert('error', res.message || lang['error'], lang['error']);
                    return;
                }
                window._acceptanceFlowUsers = res.users || [];
                window._acceptanceFlowDepartments = res.departments || [];
                renderAcceptanceFlowSteps(res.steps || [], res.users || [], res.departments || []);
                $('#acceptanceFlowConfigWarning').toggleClass('d-none', !!res.ready);
            }).fail(function (xhr) {
                const msg = (xhr.responseJSON && xhr.responseJSON.message) || lang['error'];
                makeAlert('error', msg, lang['error']);
            });
        });

        $(document).on('change', '.flow-use-owner', function () {
            const card = $(this).closest('.acceptance-flow-step-card');
            if ($(this).is(':checked')) {
                card.find('.flow-manager-box').addClass('d-none');
                card.find('.flow-user-select-value').val('');
            } else {
                card.find('.flow-manager-box').removeClass('d-none');
                card.find('.flow-department-select').trigger('change');
            }
        });

        $(document).on('change', '.flow-department-select', function () {
            const card = $(this).closest('.acceptance-flow-step-card');
            const selectedOption = $(this).find('option:selected');
            const deptName = selectedOption.text() || '';
            const managerId = selectedOption.data('manager-id') || '';
            const departments = window._acceptanceFlowDepartments || [];
            const dept = departments.find(function (d) {
                return String(d.id) === String($(this).val());
            }.bind(this));

            card.find('.flow-step-label-text').text(deptName || ('Step ' + card.data('step-order')));
            card.find('.flow-manager-name').val((dept && dept.manager_name) ? dept.manager_name : '');
            if (!card.find('.flow-use-owner').is(':checked')) {
                card.find('.flow-user-select-value').val(managerId || (dept && dept.manager_id) || '');
            }
        });

        $('#saveAcceptanceFlowConfigBtn').on('click', function () {
            const steps = [];
            let missingDepartment = null;
            $('#acceptanceFlowStepsContainer .acceptance-flow-step-card').each(function () {
                const card = $(this);
                const departmentId = card.find('.flow-department-select').val() || null;
                if (!departmentId && !missingDepartment) {
                    missingDepartment = card.data('step-order');
                }
                steps.push({
                    step_order: card.data('step-order'),
                    step_key: card.find('.flow-step-key').val(),
                    department_id: departmentId,
                    use_risk_owner: card.find('.flow-use-owner').is(':checked') ? 1 : 0,
                    user_id: card.find('.flow-user-select-value').val() || null,
                });
            });

            if (missingDepartment) {
                makeAlert('error', "{{ __('risk.SelectDepartmentForStep', ['step' => ':step']) }}".replace(':step', missingDepartment), lang['error']);
                return;
            }

            $.ajax({
                url: URLs['acceptance_flow_save'],
                type: 'POST',
                data: {
                    _token: $('meta[name="csrf-token"]').attr('content'),
                    steps: steps,
                },
                success: function (res) {
                    if (res.status) {
                        makeAlert('success', res.message, lang['success']);
                        $('#acceptanceFlowConfigWarning').toggleClass('d-none', !!res.ready);
                        $('#riskAcceptanceFlowModal').modal('hide');
                    } else {
                        makeAlert('error', res.message || lang['error'], lang['error']);
                    }
                },
                error: function (xhr) {
                    const msg = (xhr.responseJSON && xhr.responseJSON.message) || lang['error'];
                    makeAlert('error', msg, lang['error']);
                }
            });
        });
    })();
</script>
<script>
    function navigateToRiskByAssetReport() {
        // Construct the URL with query parameters for RiskByAsset
        var url = '{{ route('admin.reporting.GetRiskByAsset') }}' + '?type=2&asset=0&risk=0';

        // Navigate to the constructed URL
        window.location.href = url;
    }

    function navigateToRiskByControlReport(type) {
        // Construct the URL with the framework ID and type
        var url = '{{ route('admin.reporting.GetRiskByControl') }}' + '?type=' + type;

        // Navigate to the constructed URL
        window.location.href = url;
    }

    // Initialize flatpickr on the specified input field
    document.addEventListener('DOMContentLoaded', function() {
        flatpickr(".flatpickr-date-time-compliance", {
            enableTime: true, // Enable time selection if you want to pick both date and time
            dateFormat: "Y-m-d H:i", // Format to display the selected date (e.g., 2024-11-18 15:30)
            minDate: "today", // Optional: Disable past dates
        });
    });
</script>
<script>
    $(document).ready(function() {
        let currentStep = 0; // Track current step
        const steps = $(".tab"); // All steps
        const totalSteps = steps.length;
        const form = $("#wizard-form"); // Form reference

        // Function to style step circles dynamically based on the current step
        function styleStepCircles() {
            const activeColor = '#4CAF50'; // Green for active step
            const inactiveColor = '#CCCCCC'; // Light gray for inactive steps
            const activeTextColor = 'white'; // White text color for active circle
            const inactiveTextColor = '#555555'; // Dark gray text color for inactive circles

            const totalSteps = $(".step").length;

            for (let i = 0; i < totalSteps; i++) {
                const stepCircle = $(`.stepper-${i + 1} .step-circle`);
                const stepText = $(`.stepper-${i + 1} .step-title`);

                if (i === currentStep) {
                    stepCircle.css('background-color', activeColor);
                    stepCircle.css('color', activeTextColor);
                    stepText.css('color', activeColor);
                } else {
                    stepCircle.css('background-color', inactiveColor);
                    stepCircle.css('color', inactiveTextColor);
                    stepText.css('color', inactiveTextColor);
                }
            }
        }

        // Function to hide all steps and show the current one
        function showStep(step) {
            currentStep = step;
            styleStepCircles();

            steps.hide();
            $(steps[step]).show();

            if (step === 0) {
                $("#backbtn").hide();
            } else {
                $("#backbtn").show();
            }

            if (step === totalSteps - 1) {
                $("#nextbtn").text("Submit");
            } else {
                $("#nextbtn").text("Next");
            }
        }

        function validateStep() {
            const currentTab = $(steps[currentStep]);

            const invalidFields = currentTab.find(":input").filter(function() {
                return !this.validity.valid;
            });

            if (invalidFields.length > 0) {
                invalidFields.each(function() {
                    $(this).addClass('is-invalid');
                });
                return false;
            }

            return true;
        }

        function nextStep() {
            if (validateStep()) {
                if (currentStep === totalSteps - 1) {
                    form.submit();
                } else {
                    currentStep++;
                    showStep(currentStep);
                }
            }
        }

        function backStep() {
            if (currentStep > 0) {
                currentStep--;
                showStep(currentStep);
            }
        }

        $(document).on("click", "#nextbtn", function(event) {
            nextStep();
        });

        $("#backbtn").on("click", function() {
            backStep();
        });

        // Initially show the first step
        showStep(currentStep);

        // Reset to the first step when the modal is closed and clear validation errors
        $('.wizardModal').on('hidden.bs.modal', function() {
            currentStep = 0; // Reset current step
            showStep(currentStep); // Show the first step

            // Clear any validation errors
            $("input").removeClass('is-invalid'); // Remove invalid class from all inputs
        });

        // Remove validation error when the user starts typing
        $("input").on("input", function() {
            $(this).removeClass('is-invalid'); // Remove invalid class as user types
        });
    });


    $(document).ready(function() {
        $('#planMitigationOption').on('change', function() {
            if ($(this).val() === 'PlanAMitigation') {
                $('#planMitigationInputs').slideDown(); // Show inputs with animation
            } else {
                $('#planMitigationInputs').slideUp(); // Hide inputs with animation
            }
        });
    });
    $(document).ready(function() {
        $('#performReviewOption').on('change', function() {
            if ($(this).val() === 'PerformAReview') {
                $('#planReviewInputs').slideDown();
            } else {
                $('#planReviewInputs').slideUp();
                $('#rejection-justification-container').addClass('d-none');
                $('#review-comment-container').removeClass('d-none');
                $('#next-review-date-container').removeClass('d-none');
            }
        });

        // Review = 2 => Reject Risk: show rejection justifications
        $(document).on('change select2:select', '#riskReviewSelect, select[name="review"]', function() {
            const isReject = String($(this).val()) === '2';
            if (isReject) {
                $('#rejection-justification-container').removeClass('d-none');
                $('#review-comment-container').addClass('d-none');
                $('[name="comments"]').val('');
            } else {
                $('#rejection-justification-container').addClass('d-none');
                $('#review-comment-container').removeClass('d-none');
                $('[name="rejection_justification"]').val('');
            }
        });
    });
    $(document).on('input', 'input[name="mitigation_percent"]', function() {
        const value = parseInt($(this).val(), 10);
        if (value > 100) {
            $(this).val(100); // Restrict the value to 100
            $('.error-mitigation_percent').text('Percentage cannot exceed 100.');
        } else {
            $('.error-mitigation_percent').text(''); // Clear error message
        }
    });
    $(document).ready(function() {

        // ================= OWNER =================

        function setManagerFromOwner(ownerOption) {
            const manager = ownerOption.data('manager');
            const department = ownerOption.data('department');

            // Owner department (correct)
            $('#departmentOwner').val(department || '');

            // Reset manager select
            $('#managerSelect')
                .empty()
                .append(`<option value="">{{ __('locale.select-option') }}</option>`);

            if (manager) {
                let managerText = manager.name;

                if (manager.department && manager.department.name) {
                    managerText += ` -- ${manager.department.name}`;
                }

                $('#managerSelect')
                    .append(`<option value="${manager.id}" selected>${managerText}</option>`)
                    .trigger('change');
            }
        }

        // change event
        $('#ownerSelect').on('change select2:select', function() {
            setManagerFromOwner($(this).find(':selected'));
        });

        // edit mode
        const initialOwner = $('#ownerSelect').find(':selected');
        if (initialOwner.val()) {
            setManagerFromOwner(initialOwner);
        }


        // ================= MITIGATION =================

        function setMitigationManagerFromOwner(ownerOption) {
            const manager = ownerOption.data('manager');
            const department = ownerOption.data('department');

            // Owner department (correct)
            $('#departmentMitigationOwner').val(department || '');

            // Reset mitigation manager select
            $('#mitigationManagerSelect')
                .empty()
                .append(`<option value="">{{ __('locale.select-option') }}</option>`);

            if (manager) {
                let managerText = manager.name;

                if (manager.department && manager.department.name) {
                    managerText += ` -- ${manager.department.name}`;
                }

                $('#mitigationManagerSelect')
                    .append(`<option value="${manager.id}" selected>${managerText}</option>`)
                    .trigger('change');
            }
        }

        // change event
        $('#mitigationOwnerSelect').on('change select2:select', function() {
            setMitigationManagerFromOwner($(this).find(':selected'));
        });

        // edit mode
        const initialMitigationOwner = $('#mitigationOwnerSelect').find(':selected');
        if (initialMitigationOwner.val()) {
            setMitigationManagerFromOwner(initialMitigationOwner);
        }
    });
</script>
<script>
    (function() {

        var wizardStrategyConfig = {
            '': {
                show: ['risk_treatment_plan', 'security_recommendations', 'supporting_documentation'],
                hide: ['deadline_date', 'planned_mitigation_date', 'mitigation_effort',
                    'mitigation_cost', 'mitigation_owner', 'mitigation_team',
                    'mitigation_percent', 'mitigation_controls', 'security_requirements'
                ]
            },
            '1': { // Accepting
                show: ['deadline_date', 'mitigation_cost', 'risk_treatment_plan',
                    'security_recommendations', 'supporting_documentation'
                ],
                hide: ['planned_mitigation_date', 'mitigation_effort', 'mitigation_owner',
                    'mitigation_team', 'mitigation_percent', 'mitigation_controls',
                    'security_requirements'
                ]
            },
            '2': { // Mitigating — all fields
                show: ['deadline_date', 'planned_mitigation_date', 'mitigation_effort',
                    'mitigation_cost', 'mitigation_owner', 'mitigation_team',
                    'mitigation_percent', 'mitigation_controls', 'risk_treatment_plan',
                    'security_requirements', 'security_recommendations'
                ],
                hide: []
            },
            '3': { // Sharing
                show: ['deadline_date', 'planned_mitigation_date', 'mitigation_cost',
                    'mitigation_owner', 'mitigation_team', 'risk_treatment_plan',
                    'security_requirements', 'security_recommendations'
                ],
                hide: ['mitigation_effort', 'mitigation_percent', 'mitigation_controls']
            },
            '4': { // Avoiding
                show: ['deadline_date', 'mitigation_owner', 'risk_treatment_plan',
                    'security_recommendations'
                ],
                hide: ['planned_mitigation_date', 'mitigation_effort', 'mitigation_cost',
                    'mitigation_team', 'mitigation_percent', 'mitigation_controls',
                    'security_requirements'
                ]
            }
        };

        // Clear all input values inside a hidden col wrapper
        function wizardClearField(wrapper) {
            wrapper.querySelectorAll('input:not([type="hidden"]):not([type="file"])').forEach(function(el) {
                el.value = '';
            });
            wrapper.querySelectorAll('textarea').forEach(function(el) {
                el.value = '';
            });
            wrapper.querySelectorAll('select:not([multiple])').forEach(function(sel) {
                sel.value = '';
                if (typeof $ !== 'undefined' && $(sel).data('select2')) {
                    $(sel).val('').trigger('change.select2');
                }
            });
            wrapper.querySelectorAll('select[multiple]').forEach(function(sel) {
                Array.from(sel.options).forEach(function(opt) {
                    opt.selected = false;
                });
                if (typeof $ !== 'undefined' && $(sel).data('select2')) {
                    $(sel).val([]).trigger('change.select2');
                }
            });
        }

        // Apply show/hide scoped to #step3-content
        function wizardApplyStrategy(strategyId, animate) {
            var key = String(strategyId).trim();
            var config = wizardStrategyConfig[key] || wizardStrategyConfig[''];
            var doAnimate = (animate === true);
            var scope = document.getElementById('step3-content');
            if (!scope) return;

            // HIDE immediately + clear values
            config.hide.forEach(function(field) {
                var el = scope.querySelector('[data-wfield="' + field + '"]');
                if (!el) return;
                wizardClearField(el);
                if (doAnimate) {
                    el.style.transition = 'opacity 0.15s ease';
                    el.style.opacity = '0';
                    setTimeout(function() {
                        el.style.display = 'none';
                        el.style.opacity = el.style.transition = '';
                    }, 150);
                } else {
                    el.style.display = 'none';
                    el.style.opacity = el.style.transition = '';
                }
            });

            // SHOW with stagger
            config.show.forEach(function(field, i) {
                var el = scope.querySelector('[data-wfield="' + field + '"]');
                if (!el) return;
                if (doAnimate) {
                    var delay = i * 25;
                    el.style.display = '';
                    el.style.opacity = '0';
                    el.style.transform = 'translateY(-3px)';
                    el.style.transition = 'opacity 0.18s ease ' + delay + 'ms, transform 0.18s ease ' +
                        delay + 'ms';
                    setTimeout(function() {
                        el.style.opacity = '1';
                        el.style.transform = 'translateY(0)';
                    }, 20);
                    setTimeout(function() {
                        el.style.transition = el.style.transform = '';
                    }, 20 + delay + 200);
                } else {
                    el.style.display = '';
                    el.style.opacity = el.style.transition = el.style.transform = '';
                }
            });
        }

        function initWizardStrategyListener() {
            var select = document.getElementById('wizard_planning_strategy_select');
            if (!select) return;
            wizardApplyStrategy(select.value, false);
            select.addEventListener('change', function() {
                wizardApplyStrategy(this.value, true);
            });
            if (typeof $ !== 'undefined') {
                $(select).off('change.wizardStrategy').on('change.wizardStrategy', function() {
                    wizardApplyStrategy(this.value, true);
                });
            }
        }

        function initMitigationOptionListener() {
            var optionSelect = document.getElementById('planMitigationOption');
            var inputsDiv = document.getElementById('planMitigationInputs');
            if (!optionSelect || !inputsDiv) return;
            optionSelect.addEventListener('change', function() {
                if (this.value === 'PlanAMitigation') {
                    inputsDiv.style.display = '';
                    var stratSel = document.getElementById('wizard_planning_strategy_select');
                    if (stratSel) wizardApplyStrategy(stratSel.value, false);
                } else {
                    inputsDiv.style.display = 'none';
                }
            });
        }

        function init() {
            initMitigationOptionListener();
            initWizardStrategyListener();
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            init();
        }

    })();
</script>
@endsection
