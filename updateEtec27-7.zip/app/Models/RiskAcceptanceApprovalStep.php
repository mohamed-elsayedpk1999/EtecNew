<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskAcceptanceApprovalStep extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $appends = ['label'];

    protected $casts = [
        'acted_at' => 'datetime',
    ];

    public function approval()
    {
        return $this->belongsTo(RiskAcceptanceApproval::class, 'risk_acceptance_approval_id');
    }

    public function assignedUser()
    {
        return $this->belongsTo(User::class, 'assigned_user_id');
    }

    public function actedBy()
    {
        return $this->belongsTo(User::class, 'acted_by');
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    public function getLabelAttribute(): string
    {
        if ($this->relationLoaded('department') && $this->department) {
            return $this->department->name;
        }

        if ($this->department_id) {
            $name = optional($this->department()->first())->name;
            if ($name) {
                return $name;
            }
        }

        return app()->getLocale() === 'ar'
            ? ($this->label_ar ?: $this->label_en)
            : ($this->label_en ?: $this->label_ar);
    }

    public function isPendingFor(int $userId): bool
    {
        return $this->status === 'pending' && (int) $this->assigned_user_id === $userId;
    }
}
