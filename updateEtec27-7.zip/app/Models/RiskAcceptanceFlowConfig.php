<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskAcceptanceFlowConfig extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $appends = ['label'];

    protected $casts = [
        'use_risk_owner' => 'boolean',
        'is_active' => 'boolean',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function department()
    {
        return $this->belongsTo(Department::class, 'department_id');
    }

    public function getLabelAttribute(): string
    {
        if ($this->relationLoaded('department') && $this->department) {
            return $this->department->name;
        }

        if ($this->department_id) {
            $name = optional($this->department()->first())->name;
            if ($name) {
                return $name;
            }
        }

        return app()->getLocale() === 'ar'
            ? ($this->label_ar ?: $this->label_en)
            : ($this->label_en ?: $this->label_ar);
    }
}
