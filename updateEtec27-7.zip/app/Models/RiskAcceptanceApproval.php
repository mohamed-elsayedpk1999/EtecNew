<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RiskAcceptanceApproval extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'completed_at' => 'datetime',
    ];

    public function risk()
    {
        return $this->belongsTo(Risk::class);
    }

    public function mitigation()
    {
        return $this->belongsTo(Mitigation::class);
    }

    public function startedBy()
    {
        return $this->belongsTo(User::class, 'started_by');
    }

    public function steps()
    {
        return $this->hasMany(RiskAcceptanceApprovalStep::class)->orderBy('step_order');
    }

    public function currentStepRecord()
    {
        return $this->hasOne(RiskAcceptanceApprovalStep::class)
            ->where('step_order', $this->current_step);
    }

    public function isPending(): bool
    {
        return $this->status === 'pending';
    }
}
