<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ControlObjective extends Model
{
    use HasFactory;

    public $guarded = [];
    protected $casts = [
        'description' => 'array',
    ];

    public function getDescriptionAttribute($value)
    {
        $locale = app()->getLocale();

        // Array cast may already have decoded JSON before the accessor runs
        if (is_array($value)) {
            return $value[$locale] ?? $value['en'] ?? '';
        }

        if (! is_string($value) || $value === '') {
            return '';
        }

        $decoded = json_decode($value, true);

        // Expected format: {"en":"...","ar":"..."}
        if (is_array($decoded)) {
            return $decoded[$locale] ?? $decoded['en'] ?? '';
        }

        // Legacy / imported rows stored as a JSON string: "plain text"
        if (is_string($decoded)) {
            return $decoded;
        }

        // Plain text fallback
        return $value;
    }
    
    public function controls()
    {
        return $this->belongsToMany(FrameworkControl::class, 'controls_control_objectives', 'objective_id', 'control_id')->withPivot('id');
    }

    public function controlObjectives()
    {
        return $this->hasMany(ControlControlObjective::class, 'objective_id');
    }

    public function evidences()
    {
        return $this->hasManyThrough(Evidence::class, ControlControlObjective::class, 'objective_id', 'control_control_objective_id', 'id', 'id');
    }
    
    public function hasRelations()
    {
        $relations = [
            'Linked Controls' => $this->controls()->count(),
        ];

        // Filter out empty relations
        return array_filter($relations, fn($count) => $count > 0);
    }
}