<?php

namespace App\Services;

use App\Models\Risk;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class RiskDeletionService
{
    /**
     * Delete a risk and all related data.
     */
    public function delete(Risk $risk): void
    {
        $riskId = $risk->id;

        $mitigationIds = DB::table('mitigations')
            ->where('risk_id', $riskId)
            ->pluck('id');

        if ($risk->mitigation_id) {
            $mitigationIds = $mitigationIds->push($risk->mitigation_id)->unique()->values();
        }

        // Break circular FK: risks.mitigation_id -> mitigations.id
        DB::table('risks')
            ->where('id', $riskId)
            ->update(['mitigation_id' => null]);

         Storage::deleteDirectory("risk/{$riskId}");

        foreach ($mitigationIds as $mitigationId) {
            Storage::deleteDirectory("risk_mitigation/{$mitigationId}");
        }

        DB::table('framework_control_test_results_to_risks')
            ->where('risk_id', $riskId)
            ->delete();

        if ($mitigationIds->isNotEmpty()) {
            DB::table('validation_files')
                ->whereIn('mitigation_id', $mitigationIds)
                ->delete();

            DB::table('mitigation_to_controls')
                ->whereIn('mitigation_id', $mitigationIds)
                ->delete();

            DB::table('mitigation_to_teams')
                ->whereIn('mitigation_id', $mitigationIds)
                ->delete();
        }

        DB::table('files')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('comments')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('closures')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('mgmt_reviews')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('mitigation_accept_users')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('residual_risk_scoring_histories')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('risk_scoring_histories')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('risk_scoring_contributing_impacts')
            ->where('risk_scoring_id', $riskId)
            ->delete();

        DB::table('risk_scorings')
            ->where('id', $riskId)
            ->delete();

        DB::table('risk_to_locations')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('risk_to_teams')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('risk_to_technologies')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('risk_to_additional_stakeholders')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('risks_to_assets')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('risks_to_asset_groups')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('incident_risks')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('exception_risk')
            ->where('risk_id', $riskId)
            ->delete();

        DB::table('taggables')
            ->where('taggable_type', Risk::class)
            ->where('taggable_id', $riskId)
            ->delete();

        if ($mitigationIds->isNotEmpty()) {
            DB::table('mitigations')
                ->whereIn('id', $mitigationIds)
                ->delete();
        }

        DB::table('risks')
            ->where('id', $riskId)
            ->delete();
    }
}
