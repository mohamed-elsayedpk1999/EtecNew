<?php

namespace App\Services;

use App\Events\RiskAcceptanceStepPending;
use App\Models\Risk;
use App\Models\RiskAcceptanceApproval;
use App\Models\RiskAcceptanceApprovalStep;
use App\Models\RiskAcceptanceFlowConfig;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;

class RiskAcceptanceWorkflowService
{
    public const ACCEPTING_STRATEGY_ID = 1;

    /**
     * Default ordered steps used for configuration UI.
     */
    public function defaultSteps(): array
    {
        return [
            [
                'step_order' => 1,
                'step_key' => 'grc_manager',
                'label_en' => 'Governance, Risk & Compliance Manager',
                'label_ar' => 'مدير إدارة الحوكمة والمخاطر والالتزام',
                'use_risk_owner' => false,
            ],
            [
                'step_order' => 2,
                'step_key' => 'risk_owner',
                'label_en' => 'Risk Owner',
                'label_ar' => 'مالك الخطر',
                'use_risk_owner' => true,
            ],
            [
                'step_order' => 3,
                'step_key' => 'cybersecurity_gm',
                'label_en' => 'Cybersecurity General Manager',
                'label_ar' => 'المدير العام للأمن السيبراني',
                'use_risk_owner' => false,
            ],
        ];
    }

    public function getConfig()
    {
        $configs = RiskAcceptanceFlowConfig::with('department:id,name,manager_id', 'user:id,name')
            ->orderBy('step_order')
            ->get();
        if ($configs->isEmpty()) {
            foreach ($this->defaultSteps() as $step) {
                RiskAcceptanceFlowConfig::create(array_merge($step, [
                    'user_id' => null,
                    'department_id' => null,
                    'is_active' => true,
                ]));
            }
            $configs = RiskAcceptanceFlowConfig::with('department:id,name,manager_id', 'user:id,name')
                ->orderBy('step_order')
                ->get();
        }

        return $configs;
    }

    public function saveConfig(array $steps): void
    {
        DB::transaction(function () use ($steps) {
            foreach ($steps as $step) {
                $order = (int) ($step['step_order'] ?? 0);
                if ($order < 1) {
                    continue;
                }

                $config = RiskAcceptanceFlowConfig::firstOrNew(['step_order' => $order]);
                $defaults = collect($this->defaultSteps())->firstWhere('step_order', $order) ?? [];

                $useRiskOwner = (bool) ($step['use_risk_owner'] ?? ($defaults['use_risk_owner'] ?? false));
                $departmentId = !empty($step['department_id']) ? (int) $step['department_id'] : null;
                $department = $departmentId
                    ? \App\Models\Department::select('id', 'name', 'manager_id')->find($departmentId)
                    : null;
                $departmentName = $department->name ?? null;

                // Prefer department manager as the action person
                $userId = null;
                if (!$useRiskOwner) {
                    $userId = $department->manager_id
                        ?? ($step['user_id'] ?: null);
                }

                $config->fill([
                    'step_key' => $step['step_key'] ?? ($defaults['step_key'] ?? ('step_' . $order)),
                    'department_id' => $departmentId,
                    'label_en' => $departmentName ?: ($step['label_en'] ?? ($defaults['label_en'] ?? ('Step ' . $order))),
                    'label_ar' => $departmentName ?: ($step['label_ar'] ?? ($defaults['label_ar'] ?? ('خطوة ' . $order))),
                    'use_risk_owner' => $useRiskOwner,
                    'user_id' => $useRiskOwner ? null : $userId,
                    'is_active' => true,
                ]);
                $config->save();
            }
        });
    }

    public function isConfigReady(): bool
    {
        $configs = $this->getConfig()->loadMissing('department:id,name,manager_id');
        foreach ($configs as $config) {
            if (!$config->department_id) {
                return false;
            }
            if ($config->use_risk_owner) {
                continue;
            }
            $managerId = optional($config->department)->manager_id;
            if (!$managerId && !$config->user_id) {
                return false;
            }
        }

        return $configs->count() >= 3;
    }

    /**
     * Resolve who must act on a configured step.
     * Priority: risk owner (if flagged) → department manager → configured user → first department employee.
     */
    public function resolveAssignee(RiskAcceptanceFlowConfig $config, Risk $risk): ?int
    {
        if ($config->use_risk_owner) {
            return $risk->owner_id ?: null;
        }

        $config->loadMissing('department');
        if ($config->department && $config->department->manager_id) {
            return (int) $config->department->manager_id;
        }

        if ($config->user_id) {
            return (int) $config->user_id;
        }

        if ($config->department_id) {
            return \App\Models\User::where('department_id', $config->department_id)
                ->where('enabled', 1)
                ->orderBy('id')
                ->value('id');
        }

        return null;
    }

    public function startForRisk(Risk $risk, $mitigation = null, ?int $startedBy = null, ?string $acceptingReason = null): ?RiskAcceptanceApproval
    {
        if (!$this->isConfigReady()) {
            return null;
        }

        $configs = $this->getConfig()->loadMissing('department:id,name,manager_id');

        // Owner is required only when a step is configured to use risk owner
        $needsOwner = $configs->contains(fn ($c) => (bool) $c->use_risk_owner);
        if ($needsOwner && !$risk->owner_id) {
            throw new InvalidArgumentException(__('risk.AcceptanceFlowRiskOwnerRequired'));
        }

        // Cancel any previous pending acceptance for this risk
        RiskAcceptanceApproval::where('risk_id', $risk->id)
            ->where('status', 'pending')
            ->update([
                'status' => 'cancelled',
                'completed_at' => now(),
            ]);

        return DB::transaction(function () use ($risk, $mitigation, $startedBy, $configs, $acceptingReason) {
            $actorId = $startedBy ?? auth()->id() ?? $configs->first()->user_id;

            $approval = RiskAcceptanceApproval::create([
                'risk_id' => $risk->id,
                'mitigation_id' => $mitigation->id ?? $risk->mitigation_id,
                'status' => 'pending',
                'accepting_reason' => $acceptingReason,
                'current_step' => 1,
                'started_by' => $actorId,
            ]);

            foreach ($configs as $config) {
                $assignedUserId = $this->resolveAssignee($config, $risk);

                if (!$assignedUserId) {
                    throw new InvalidArgumentException(__('risk.AcceptanceFlowNoApproverForDepartment', [
                        'step' => $config->label,
                    ]));
                }

                $departmentName = optional($config->department)->name
                    ?: ($config->label_ar ?: $config->label_en);

                RiskAcceptanceApprovalStep::create([
                    'risk_acceptance_approval_id' => $approval->id,
                    'step_order' => $config->step_order,
                    'step_key' => $config->step_key,
                    'department_id' => $config->department_id,
                    'label_en' => $departmentName,
                    'label_ar' => $departmentName,
                    'assigned_user_id' => $assignedUserId,
                    'status' => $config->step_order === 1 ? 'pending' : 'waiting',
                ]);
            }

            $approval = $approval->fresh(['steps.assignedUser', 'steps.department', 'risk']);
            $firstStep = $approval->steps->firstWhere('step_order', 1);

            // Notify after commit so a mail/log failure never rolls back the cycle
            DB::afterCommit(function () use ($approval, $firstStep, $risk, $actorId) {
                if ($firstStep) {
                    try {
                        event(new RiskAcceptanceStepPending($approval, $firstStep));
                    } catch (\Throwable $e) {
                        \Log::error('Risk acceptance notify failed: ' . $e->getMessage());
                    }
                }

                try {
                    write_log(
                        $risk->id,
                        $actorId,
                        __('risk.AcceptanceFlowStartedForRisk', ['id' => $risk->id + 1000])
                    );
                } catch (\Throwable $e) {
                    \Log::error('Risk acceptance write_log failed: ' . $e->getMessage());
                }
            });

            return $approval;
        });
    }

    public function cancelPendingForRisk(int $riskId, ?string $reason = null): void
    {
        $pending = RiskAcceptanceApproval::where('risk_id', $riskId)
            ->where('status', 'pending')
            ->get();

        foreach ($pending as $approval) {
            $approval->update([
                'status' => 'cancelled',
                'completed_at' => now(),
            ]);
            $approval->steps()
                ->whereIn('status', ['pending', 'waiting'])
                ->update(['status' => 'skipped']);

            write_log(
                $riskId,
                auth()->id(),
                $reason ?: __('risk.AcceptanceFlowCancelledForRisk', ['id' => $riskId + 1000])
            );
        }
    }

    public function actOnStep(RiskAcceptanceApprovalStep $step, string $decision, ?string $comments = null, ?int $actorId = null): RiskAcceptanceApproval
    {
        $actorId = $actorId ?? auth()->id();
        $decision = strtolower($decision);

        if (!in_array($decision, ['approved', 'rejected'], true)) {
            throw new InvalidArgumentException('Invalid decision');
        }

        $approval = $step->approval()->with('steps')->first();
        if (!$approval || !$approval->isPending()) {
            throw new InvalidArgumentException(__('risk.AcceptanceFlowNotPending'));
        }

        if ($step->status !== 'pending') {
            throw new InvalidArgumentException(__('risk.AcceptanceFlowStepNotPending'));
        }

        if ((int) $step->assigned_user_id !== (int) $actorId) {
            throw new InvalidArgumentException(__('risk.AcceptanceFlowUnauthorizedApprover'));
        }

        return DB::transaction(function () use ($step, $decision, $comments, $actorId, $approval) {
            $actorId = $actorId ?: ($step->assigned_user_id ?: 1);

            $step->update([
                'status' => $decision,
                'acted_by' => $actorId,
                'acted_at' => now(),
                'comments' => $comments,
            ]);

            if ($decision === 'rejected') {
                $approval->update([
                    'status' => 'rejected',
                    'completed_at' => now(),
                ]);
                $approval->steps()
                    ->whereIn('status', ['pending', 'waiting'])
                    ->update(['status' => 'skipped']);

                DB::afterCommit(function () use ($approval, $actorId, $step) {
                    try {
                        write_log(
                            $approval->risk_id,
                            $actorId,
                            __('risk.AcceptanceFlowRejectedAtStep', [
                                'id' => $approval->risk_id + 1000,
                                'step' => $step->label,
                            ])
                        );
                    } catch (\Throwable $e) {
                        \Log::error('Risk acceptance write_log failed: ' . $e->getMessage());
                    }
                });

                return $approval->fresh(['steps.assignedUser', 'risk']);
            }

            $nextStep = $approval->steps()
                ->where('step_order', '>', $step->step_order)
                ->orderBy('step_order')
                ->first();

            if ($nextStep) {
                $nextStep->update(['status' => 'pending']);
                $approval->update(['current_step' => $nextStep->step_order]);
                $approval->load('steps.assignedUser', 'risk');
                $freshNext = $nextStep->fresh('assignedUser');

                DB::afterCommit(function () use ($approval, $freshNext, $actorId, $step) {
                    try {
                        event(new RiskAcceptanceStepPending($approval, $freshNext));
                    } catch (\Throwable $e) {
                        \Log::error('Risk acceptance notify failed: ' . $e->getMessage());
                    }
                    try {
                        write_log(
                            $approval->risk_id,
                            $actorId,
                            __('risk.AcceptanceFlowStepApproved', [
                                'id' => $approval->risk_id + 1000,
                                'step' => $step->label,
                            ])
                        );
                    } catch (\Throwable $e) {
                        \Log::error('Risk acceptance write_log failed: ' . $e->getMessage());
                    }
                });
            } else {
                $approval->update([
                    'status' => 'approved',
                    'completed_at' => now(),
                ]);

                // Only now set mitigation planning strategy to Accepting
                $this->applyAcceptedStrategyToMitigation($approval);

                DB::afterCommit(function () use ($approval, $actorId) {
                    try {
                        write_log(
                            $approval->risk_id,
                            $actorId,
                            __('risk.AcceptanceFlowCompleted', ['id' => $approval->risk_id + 1000])
                        );
                    } catch (\Throwable $e) {
                        \Log::error('Risk acceptance write_log failed: ' . $e->getMessage());
                    }
                });
            }

            return $approval->fresh(['steps.assignedUser', 'risk']);
        });
    }

    /**
     * Persist Accepting strategy on mitigation only after full approval cycle.
     */
    public function applyAcceptedStrategyToMitigation(RiskAcceptanceApproval $approval): void
    {
        $mitigationId = $approval->mitigation_id;
        if (!$mitigationId) {
            $risk = Risk::find($approval->risk_id);
            $mitigationId = $risk->mitigation_id ?? null;
        }

        if (!$mitigationId) {
            return;
        }

        \App\Models\Mitigation::where('id', $mitigationId)->update([
            'planning_strategy' => self::ACCEPTING_STRATEGY_ID,
            'accepting_reason' => $approval->accepting_reason,
            'last_update' => date('Y-m-d H:i:s'),
        ]);
    }

    public function latestForRisk(int $riskId): ?RiskAcceptanceApproval
    {
        return RiskAcceptanceApproval::with(['steps.assignedUser', 'steps.actedBy', 'steps.department', 'startedBy'])
            ->where('risk_id', $riskId)
            ->latest('id')
            ->first();
    }

    public function pendingStepForUser(int $riskId, int $userId): ?RiskAcceptanceApprovalStep
    {
        $approval = RiskAcceptanceApproval::where('risk_id', $riskId)
            ->where('status', 'pending')
            ->latest('id')
            ->first();

        if (!$approval) {
            return null;
        }

        return $approval->steps()
            ->where('status', 'pending')
            ->where('assigned_user_id', $userId)
            ->first();
    }

    /**
     * Resolved cycle for display on risk page (config or live approval steps).
     * Always ordered by step_order so UI shows 1 → 2 → 3.
     */
    public function resolveCycleForRisk(Risk $risk, ?RiskAcceptanceApproval $approval = null): array
    {
        if ($approval) {
            $approval->loadMissing('steps.assignedUser', 'steps.actedBy', 'steps.department');
            if ($approval->steps->isNotEmpty()) {
                return $approval->steps->sortBy('step_order')->values()->map(function (RiskAcceptanceApprovalStep $step) {
                    return [
                        'step_order' => (int) $step->step_order,
                        'step_key' => $step->step_key,
                        'label' => $step->label,
                        'department_id' => $step->department_id,
                        'department_name' => optional($step->department)->name,
                        'user_id' => $step->assigned_user_id,
                        'user_name' => optional($step->assignedUser)->name,
                        'status' => $step->status,
                        'acted_by_name' => optional($step->actedBy)->name,
                        'acted_at' => $step->acted_at?->format('Y-m-d H:i'),
                        'comments' => $step->comments,
                        'step_id' => $step->id,
                        'is_current' => $step->status === 'pending',
                        'can_act' => $step->status === 'pending' && (int) $step->assigned_user_id === (int) auth()->id(),
                    ];
                })->all();
            }
        }

        $configs = $this->getConfig()->loadMissing('department:id,name,manager_id', 'user:id,name');
        $owner = $risk->relationLoaded('owner') ? $risk->owner : $risk->owner()->first();

        return $configs->map(function (RiskAcceptanceFlowConfig $config) use ($owner, $risk) {
            $userId = $this->resolveAssignee($config, $risk);
            $userName = null;
            if ($userId) {
                $userName = \App\Models\User::where('id', $userId)->value('name');
            }

            return [
                'step_order' => (int) $config->step_order,
                'step_key' => $config->step_key,
                'label' => $config->label,
                'department_id' => $config->department_id,
                'department_name' => optional($config->department)->name,
                'user_id' => $userId,
                'user_name' => $userName,
                'status' => 'planned',
                'acted_by_name' => null,
                'acted_at' => null,
                'comments' => null,
                'step_id' => null,
                'is_current' => false,
                'can_act' => false,
            ];
        })->all();
    }
}
