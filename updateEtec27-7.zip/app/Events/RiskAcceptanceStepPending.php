<?php

namespace App\Events;

use App\Models\RiskAcceptanceApproval;
use App\Models\RiskAcceptanceApprovalStep;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class RiskAcceptanceStepPending
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public RiskAcceptanceApproval $approval;
    public RiskAcceptanceApprovalStep $step;

    public function __construct(RiskAcceptanceApproval $approval, RiskAcceptanceApprovalStep $step)
    {
        $this->approval = $approval;
        $this->step = $step;
    }

    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
