<?php

namespace App\Listeners;

use App\Events\RiskAcceptanceStepPending;
use App\Http\Traits\NotificationHandlingTrait;
use App\Models\Action;
use App\Models\MailSetting;
use App\Models\NotificationRole;
use App\Models\SystemNotificationSetting;
use App\Models\User;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Notific;

class RiskAcceptanceStepPendingListener
{
    use NotificationHandlingTrait;

    public function handle(RiskAcceptanceStepPending $event)
    {
        $this->ensureNotificationSettingsExist();

        $action = Action::where('name', 'Risk_Acceptance_Approval')->first();
        if (!$action) {
            Log::warning('Risk acceptance notification skipped: action Risk_Acceptance_Approval missing');
            return;
        }

        $approval = $event->approval->loadMissing('risk.owner');
        $step = $event->step->loadMissing('assignedUser');
        $risk = $approval->risk;

        if (!$risk || !$step->assigned_user_id) {
            Log::warning('Risk acceptance notification skipped: missing risk or assigned user', [
                'approval_id' => $approval->id ?? null,
                'step_id' => $step->id ?? null,
            ]);
            return;
        }

        $roles = [
            'Acceptance_Approver' => [$step->assigned_user_id],
            'creator' => array_filter([$risk->owner_id]),
        ];

        $link = ['link' => route('admin.risk_management.show', ['id' => $risk->id])];

        $payload = $step;
        $payload->Risk_Name = $risk->subject ?? '';
        $payload->Risk_ID = ($risk->id + 1000);
        $payload->Acceptance_Step = $step->label;
        $payload->Acceptance_Approver = optional($step->assignedUser)->name;
        $payload->Owner = optional($risk->owner)->name;
        $payload->subject = $risk->subject ?? '';

        try {
            $this->sendNotificationForAction(
                $action->id,
                null,
                $link,
                $payload,
                $roles,
                null,
                $risk->id,
                'RiskAcceptance',
                null
            );
        } catch (\Throwable $e) {
            Log::error('Risk acceptance notification settings send failed: ' . $e->getMessage());
        }

        // Always notify the assigned approver directly (platform + email fallback)
        $this->notifyAssignedApproverDirectly($step->assigned_user_id, $payload, $link['link']);
    }

    protected function notifyAssignedApproverDirectly(int $userId, $payload, string $link): void
    {
        $message = __('risk.AcceptanceNotificationMessage', [
            'risk' => $payload->Risk_Name,
            'id' => $payload->Risk_ID,
            'step' => $payload->Acceptance_Step,
        ]);

        try {
            Notific::notify($userId, $message, 'notification', ['link' => $link]);
        } catch (\Throwable $e) {
            Log::error('Risk acceptance platform notify failed: ' . $e->getMessage());
        }

        try {
            $user = User::find($userId);
            if ($user && filter_var($user->email, FILTER_VALIDATE_EMAIL)) {
                $subject = __('risk.AcceptanceNotificationSubject', [
                    'id' => $payload->Risk_ID,
                ]);
                Mail::raw(
                    strip_tags($message) . "\n\n" . $link,
                    function ($mail) use ($user, $subject) {
                        $mail->to($user->email)->subject($subject);
                    }
                );
            }
        } catch (\Throwable $e) {
            Log::error('Risk acceptance mail notify failed: ' . $e->getMessage());
        }
    }

    protected function ensureNotificationSettingsExist(): void
    {
        $action = Action::firstOrCreate(
            ['id' => 162],
            ['name' => 'Risk_Acceptance_Approval']
        );

        $system = SystemNotificationSetting::firstOrCreate(
            ['action_id' => $action->id],
            [
                'message' => '<p>Your approval is required for risk "{Risk_Name}" (#{Risk_ID}) at step: {Acceptance_Step}</p>',
                'status' => 1,
            ]
        );

        if (!(int) $system->status) {
            $system->update(['status' => 1]);
        }

        if (!$system->roles()->where('role', 'Acceptance_Approver')->exists()) {
            $system->roles()->save(new NotificationRole(['role' => 'Acceptance_Approver']));
        }

        $mail = MailSetting::firstOrCreate(
            ['action_id' => $action->id],
            [
                'subject' => 'Risk acceptance approval required #{Risk_ID}',
                'body' => '<p>Your approval is required for risk "{Risk_Name}" (#{Risk_ID}) at step: {Acceptance_Step}</p><p>Approver: {Acceptance_Approver}</p>',
                'status' => 1,
            ]
        );

        if (!(int) $mail->status) {
            $mail->update(['status' => 1]);
        }

        if (!$mail->roles()->where('role', 'Acceptance_Approver')->exists()) {
            $mail->roles()->save(new NotificationRole(['role' => 'Acceptance_Approver']));
        }
    }
}
